@file jpaas console ui 2.0
@author zhaozhixin@baidu.com
@date 2015-06-10

环境依赖:
    nodejs/npm

部署指南:
    1 全局安装http-server
        npm install -g http-server
    2 全局安装fis (压缩, MD5戳)
        npm install -g fis
    3 导入依赖
        sudo ssh install.sh
开发指南:
    1 开启调试服务器
        npm run server 或者 npm run server-backend
    2 开启watch (react编译, 依赖提取, 文件合并)
        npm run start  (把src下的资源实时build到dist目录下)
    3 部署到发布目录
        npm run build (本地发布目录为output/)
    4 验证发布目录代码
        cd output/
        npm run server

项目主要使用的框架:
    react
    react-bootstrap
    react-reflux
    react-router
    jquery

    框架封装在dist/lib/lib.js  手动加载进html(不通过require的方式引入的好处是Lib方便缓存, 更新通常只变动app.js 不变动lib.js)

项目结构:
    src/           开发目录, 平时的开发工作在这里进行, 通过工具构建到dist, 再构建到output
    dist/          测试目录, 存放编译好的代码, 供本地调试使用
    output/        生产目录, 构建好的代码在这里
    node_modules/  项目依赖
    fis-conf.js    fis配置文件, fis的build策略在里面定义
    package.json   npm描述文件
    index.html     测试环境的项目入口文件, 生产的入口文件在output/ 下
    install.sh     编译命令