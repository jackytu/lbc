#!/bin/sh
curl -O http://10.107.26.32:8000/jpaasui/dist.tar.gz
tar xzf dist.tar.gz && rm dist.tar.gz
npm --proxy http://10.242.104.36:8123 install fis
npm --proxy http://10.242.104.36:8123 install && npm run start-one && npm run build