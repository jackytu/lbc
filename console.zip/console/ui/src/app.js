/**
 * @file 应用总入口
 * @author zhaozhixin@baidu.com
 */
var intro = require('./utils/intro');
/* common */
var HeaderComponents = require('./common/header.jsx');
var SidebarComponents = require('./common/sidebar.jsx');
var ControlComponents = require('./common/control.jsx');


/* pages */
var SpaceComponents = require('./space/space.jsx');
var AppComponents = require('./app/app.jsx');
var OrgComponents = require('./org/org.jsx');
var ConfComponents = require('./conf/conf.jsx');
var AutopushComponents = require('./autopush/autopush.jsx');
var DashboardComponents = require('./dashboard/dashboard.jsx');
var MonitorComponents = require('./monitor/monitor.jsx');

var app = window.React.createClass({
    contextTypes: {
        router: window.React.PropTypes.func
    },
    render: function () {
        var appId = this.props.urlstate.params.appid || localStorage.getItem('APPID');
        if (appId) {
            localStorage.setItem('APPID', appId);
        }
        else {
            appId = localStorage.getItem('APPID');
        }
        var name = this.context.router.getCurrentRoutes()[1].name.split('|');
        return (
            <div className="wrapper">
                <HeaderComponents pageName={name[1]} urlstate={this.props.urlstate} />
                <SidebarComponents pageName={name[0]} appId={appId}/>
                <div className="content-wrapper">
                    <div className="shade"><img src="dist/img/loading-spin.svg" /></div>
                    <ReactRouter.RouteHandler urlstate={this.props.urlstate} />
                </div>
                <ControlComponents urlstate={this.props.urlstate} />
                <div className="mycallout"></div>
            </div>
        );
    }
});

var routes = (
    <ReactRouter.Route name="app" handler={app}>
        <ReactRouter.Route name="dashboard|dashboard" path="/home"  handler={AppComponents} />
        <ReactRouter.Route name="appManager|APP管理" path="/app/:appid" handler={AppComponents} />
        <ReactRouter.Route name="monitorManager|监控管理" path="/monitor/:appid" handler={MonitorComponents} />
        <ReactRouter.Route name="spaceManager|空间管理" path="/space/:spaceid" handler={SpaceComponents} />
        <ReactRouter.Route name="orgManager|产品线管理" path="/org/:orgid" handler={OrgComponents} />
        <ReactRouter.Route name="confManager|配置管理" path="/conf/:appid" handler={ConfComponents} />
        <ReactRouter.Route name="autopushManager|变更管理" path="/autopush/:appid" handler={AutopushComponents} />
        <ReactRouter.Redirect from="/*" to="/home" />
    </ReactRouter.Route>
);
window.ReactRouter.run(routes, function (Handler, state) {
    $('.mycallout').fadeOut();
    window.React.render(<Handler urlstate={state}/>, document.getElementById('JpaasApp'));
});

setTimeout(function () {
    if (!localStorage.getItem(intro.common.key)) {
        intro.common.start();
        localStorage.setItem(intro.common.key, true);
    }
}, 1000);

$('body').delegate('.content-wrapper', 'click', function () {
    $('.control-sidebar').removeClass('control-sidebar-open');
});
$('body').delegate('.sidebar-toggle', 'click', function () {
    var $app = $('.jpaas-app');
    $app.toggleClass('sidebar-collapse');
    if ($app.hasClass('sidebar-collapse')) {
        localStorage.setItem('SIDBAR_MINI', false);
    }
    else {
        localStorage.setItem('SIDBAR_MINI', true);
    }
});
$('body').delegate('.btn-control-sidebar', 'click', function () {
    $('.control-sidebar').toggleClass('control-sidebar-open');
    return false;
});
/*if(localStorage.getItem('SIDBAR_MINI') === 'true') {
    $('.jpaas-app').removeClass('sidebar-collapse');
}*/
var timer = null;
$(window).bind('resize', function () {
    clearTimeout(timer);
    timer = setTimeout(function () {
        resizeSidebar();
    }, 300);
});
function resizeSidebar() {
    var width = $(document).width();
    if (width < 900) {
        $('.jpaas-app').addClass('sidebar-collapse');
    }
    else {
        //$(".jpaas-app").removeClass('sidebar-collapse');
    }
}

