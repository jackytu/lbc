/**
 * @file 配置详情模板
 * @author zhaozhixin@baidu.com
 */
var ConfStore = require('./conf.store');
var ConfAction = require('./conf.action');
var AppStore = require('../app/app.store');
var AppAction = require('../app/app.action');
var EditorForm = require('../utils/editorForm');

var isAdd = true;
module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.appInfo, 'app'), window.Reflux.connect(ConfStore, 'conf')],
    getInitialState: function () {
        return {
            showHighLevel: false,
            isEdit: false
        };
    },
    componentWillMount: function () {
        ConfAction.load({
            appId: this.props.urlstate.params.appid
        });
    },
    handleSubmit: function (dataStr, data) {
        var app = this.state.app;
        if (!app) {
            return;
        }
        data.appId = app.id;
        data.appName = app.name;
        if (isAdd) {
            ConfAction.add(data);
        }
        else {
            ConfAction.edit(data);
        }
        return false;
    },
    handleEditClick: function () {
        this.setState({
            isEdit: true
        });
    },
    handleToggleHighLevel: function () {
        this.setState({
            showHighLevel: !this.state.showHighLevel
        });
    },
    componentWillReceiveProps: function (props) {
        ConfAction.load({
            appId: props.urlstate.params.appid
        });
    },
    render: function () {
        var conf = this.state.conf;
        var isEdit = !conf || this.state.isEdit ? 'true' : 'false';
        isAdd = conf ? false : true;
        conf = conf || {};
        var memory = (conf.memory || 0) + ' MB';
        var highLevelConfig = this.state.showHighLevel ? '' : 'none';
        var btnHighCls = this.state.showHighLevel ? 'btn-box-tool fa fa-chevron-up' : 'btn-box-tool fa fa-chevron-down';
        return (
            <div>
                <section className="content-header">
                    <h4>配置管理</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-header">
                            <h3 className="box-title">基础配置</h3>
                            <i onClick={this.handleToggleHighLevel.bind(this)}
                                title="高级配置" className={btnHighCls}></i>
                            <i onClick={this.handleEditClick.bind(this)}
                                title="编辑" className="btn-box-tool fa fa-edit"></i>
                        </div>
                        <div className="box-body">
                            <EditorForm.form submit={this.handleSubmit}>
                                <div className="form-group">
                                    <label>域名</label>
                                    <EditorForm.item editor={isEdit} max="100" val={conf.uris}
                                        input={<input type="text" name="uris"
                                        className="form-control" placeholder="多个域名使用逗号分隔" />} />
                                </div>
                                <div className="form-group">
                                    <label>是否需要BNS</label>
                                    <EditorForm.item editor={isEdit} dval={conf.bns === 1 ? '需要' : '不需要'}
                                        val={conf.bns}
                                        input={
                                            <div>
                                                <label className="checkbox-inline">
                                                    <input type="radio" name="bns" value="1" /> 需要
                                                </label>
                                                <label className="checkbox-inline">
                                                    <input type="radio" name="bns" value="0" /> 不需要
                                                </label>
                                            </div>
                                        } />
                                </div>
                                <div className="form-group">
                                    <label>内存</label>
                                    <EditorForm.item editor={isEdit} require dval={memory} val={conf.memory}
                                        input={<input type="text" name="memory"
                                        className="form-control" placeholder="单位为MB" />} />
                                </div>
                                <div className="form-group">
                                    <label>单集群实例</label>
                                    <EditorForm.item editor={isEdit} require val={conf.instances}
                                        input={<input type="text" name="instances"
                                        className="form-control" placeholder="单个集群实例个数" />} />
                                </div>
                                <div style={{display: highLevelConfig}}>
                                    <div className="form-group">
                                        <label>是否需要智能BNS</label>
                                        <EditorForm.item editor={isEdit} dval={conf.smart === 1 ? '需要' : '不需要'}
                                            val={conf.smart}
                                            input={
                                                <div>
                                                    <label className="checkbox-inline">
                                                        <input type="radio" name="smart" value="1" /> 需要
                                                    </label>
                                                    <label className="checkbox-inline">
                                                        <input type="radio" name="smart" value="0" /> 不需要
                                                    </label>
                                                </div>
                                            } />
                                    </div>
                                    <div className="form-group">
                                        <label>自动检查</label>
                                        <EditorForm.item editor={isEdit} dval={conf.check === 1 ? '需要' : '不需要'}
                                            val={conf.check}
                                            input={
                                                <div>
                                                    <label className="checkbox-inline">
                                                        <input type="radio" name="check" value="1" /> 需要
                                                    </label>
                                                    <label className="checkbox-inline">
                                                        <input type="radio" name="check" value="0" /> 不需要
                                                    </label>
                                                </div>
                                            } />
                                    </div>
                                    <div className="form-group">
                                        <label>健康检查页</label>
                                        <EditorForm.item editor={isEdit} val={conf.healthPage}
                                            input={<input type="text" name="healthPage"
                                            className="form-control" placeholder="健康检查URL" />} />
                                    </div>
                                    <div className="form-group">
                                        <label>健康检查匹配返回</label>
                                        <EditorForm.item editor={isEdit} val={conf.healthRet}
                                            input={<input type="text" name="healthRet"
                                            className="form-control" placeholder="健康检查页面匹配的返回内容" />} />
                                    </div>
                                    <div className="form-group">
                                        <label>集群</label>
                                        <EditorForm.item editor={isEdit} val={conf.target}
                                            input={<input type="text" name="target"
                                            className="form-control" placeholder="多个集群使用逗号分割" />} />
                                    </div>
                                    <div className="form-group">
                                        <label>流量预案</label>
                                        <EditorForm.item editor={isEdit} val={conf.strategy}
                                            input={<input type="text" name="strategy"
                                            className="form-control" placeholder="流量预案" />} />
                                    </div>
                                    <div className="form-group">
                                        <label>关闭延迟</label>
                                        <EditorForm.item editor={isEdit} val={conf.delay}
                                            input={<input type="text" name="delay"
                                            className="form-control" placeholder="关闭延迟" />} />
                                    </div>
                                </div>
                                <div style={{display: isEdit === 'true' ? '' : 'none'}} className="form-group">
                                    <button type="submit" className="btn btn-sm btn-primary">确定</button>
                                </div>
                            </EditorForm.form>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
});
