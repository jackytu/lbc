/**
 * @file 配置管理 action
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    load: {children: ['success']},
    add: {children: ['success']},
    edit: {children: ['success']}
});
Action.load.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/appregistry/' + data.appId,
        cache: true
    }, function (payload) {
        self.success(payload, data);
    });
});
Action.add.listen(function (data) {
    var self = this;
    data = data || {};
    utils.ajax({
        url: config.xuserApi + '/api/appregistry/add',
        shade: true,
        type: 'post',
        data: {
            id: data.appId,
            name: data.appName,
            memory: parseInt(data.memory || 0, 10),
            instances: parseInt(data.instances || 1, 10),
            uris: data.uris,
            target: data.target,
            bns: parseInt(data.bns || 0, 10),
            strategy: data.strategy,
            delay: parseInt(data.delay || 0, 10),
            smart: parseInt(data.smart || 0, 10),
            check: parseInt(data.check || 0, 10),
            healthPage: data.healthPage,
            healthRet: data.healthRet
        }
    }, function (payload) {
        self.success(payload, data);
    });
});
Action.edit.listen(function (data) {
    var self = this;
    data = data || {};
    utils.ajax({
        url: config.xuserApi + '/api/appregistry/edit',
        shade: true,
        type: 'post',
        data: {
            id: data.appId,
            name: data.appName,
            memory: parseInt(data.memory || 0, 10),
            instances: parseInt(data.instances || 1, 10),
            uris: data.uris,
            target: data.target,
            bns: parseInt(data.bns || 0, 10),
            strategy: data.strategy,
            delay: parseInt(data.delay || 0, 10),
            smart: parseInt(data.smart || 0, 10),
            check: parseInt(data.check || 0, 10),
            healthPage: data.healthPage,
            healthRet: data.healthRet
        }
    }, function (payload) {
        self.success(payload, data);
    });
});
module.exports = Action;
