/**
 * @file 配置管理 store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./conf.action');

module.exports = window.Reflux.createStore({
    listenables: Action,
    onLoadSuccess: function (payload) {
        this.trigger(payload);
    },
    onAddSuccess: function (payload, data) {
        Action.load(data);
    },
    onEditSuccess: function (payload, data) {
        Action.load(data);
    }
});