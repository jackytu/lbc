/**
 * @file app视图
 * @author zhaozhixin@baidu.com
 * @dete 2015-07-03
 */

var AppStore = require('./app.store');
var AppAction = require('./app.action');
/**
 * 基础信息
 */
var BaseInfo = window.React.createClass({
    render: function () {
        var base = this.props.base || {};
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">基础信息</h3>
                </div>
                <div className="box-body">
                    <table className="table table-striped">
                        <tr>
                            <th>ID</th>
                            <th>名称</th>
                            <th>PV</th>
                            <th>QPS</th>
                            <th>SLA</th>
                            <th>语言</th>
                            <th>框架</th>
                            <th>模块路径</th>
                        </tr>
                        <tr>
                            <td>{base.id}</td>
                            <td>{base.name}</td>
                            <td>{base.pv}</td>
                            <td>{base.qps}</td>
                            <td>{base.sla} %</td>
                            <td>{base.language}</td>
                            <td>{base.framework}</td>
                            <td>{base.svn}</td>
                        </tr>
                    </table>
                </div>
            </div>
        )
    }
});
/**
 * 运行中实例信息
 */
var Running = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.runIns, 'ins')],
    componentWillReceiveProps: function (props) {
        var base = props.base || {};
        AppAction.loadRunIns({
            appName: props.app.name,
            clusters: base.clusters
        });
    },
    render: function () {
        var ins = this.state.ins || [];
        var self = this;
        return (
            <div className="box box-primary">
                <ItemList base={self.props.base} ins={ins} status='running'/>
            </div>
        )
    }
});
var Stopped = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.stopIns, 'ins')],
    componentWillReceiveProps: function (props) {
        var base = props.base || {};
        AppAction.loadStopIns({
            appName: props.app.name,
            clusters: base.clusters
        });
    },
    render: function () {
        var ins = this.state.ins || [];
        var self = this;
        return (
            <div className="box box-primary">
                <ItemList base={self.props.base} ins={ins} status='stopped'/>
            </div>
        )
    }
});

var Crashed = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.crashIns, 'ins')],
    componentWillReceiveProps: function (props) {
        var base = props.base || {};
        AppAction.loadCrashIns({
            appName: props.app.name,
            clusters: base.clusters
        });
    },
    render: function () {
        var ins = this.state.ins || [];
        var self = this;
        return (
            <div className="box box-primary">
                <ItemList base={self.props.base} ins={ins} status='crashed'/>
            </div>
        )
    }
});
var Version = window.React.createClass({
    getInitialState: function () {
        return {
            showInstance: false
        };
    },
    toggleInstance: function () {
        this.setState({
            showInstance: !this.state.showInstance
        });
    },
    render: function () {
        var self = this;
        var version = this.props.version;
        var uris = version.uris && version.uris.split(',') || [];
        var bns = version.bns && version.bns.split(',') || [];
        return (
            <div style={{'border-color': self.state.showInstance ? '#3C8DBC' : '#DDD'}} className="my-table my-td row">
                <div className="col col-sm-3 col-md-2">
                    {version.version}
                </div>
                <div className="col col-sm-3 col-md-2">
                    {
                        uris.map(function (uri) {
                            var link = 'http://' + uri;
                            return (
                                <div><a href={link} target="_blank">{uri}</a></div>
                            )
                        })
                    }
                </div>
                <div className="col col-sm-6 col-md-4">
                    {
                        bns.map(function (b) {
                            return (
                                <div>{b}</div>
                            )
                        })
                    }
                </div>
                <div className="col col-sm-3 col-md-1">{version.num}</div>
                <div className="col col-sm-3 col-md-1">{version.memQuota} MB</div>
                <div className="col col-sm-3 col-md-1">{version.diskQuota/1024} GB</div>
                <div className="col col-sm-3 col-md-1" onClick={self.toggleInstance}>
                    {self.state.showInstance ? <a  className="btn btn-sm btn-default">隐藏</a> : <a  className="btn btn-sm btn-primary">查看</a>}
                </div>
                <div style={{'display': self.state.showInstance ? '' : 'none'}} className="col col-xs-12 my-td-active">
                    {
                        version.instances.map(function (data) {
                            return (
                                <Instance status={self.props.status} version={version} ins={data} />
                            )
                        })
                    }
                </div>
            </div>
        )
    }
});
var Cluster = window.React.createClass({
    handleSelect: function (evnet, page) {
        var ins = this.props.instance || {};
        var clusters = this.props.base.clusters;
        for (var i = 0; i < clusters.length; i++) {
            if (clusters[i].shortname === ins.data.cluster) {
                clusters[i].page = page.eventKey || 1;
                break;
            }
        }
        AppAction.loadStopIns({
            appName: ins.data.appName,
            clusters: clusters
        });
    },
    render: function () {
        var self = this;
        var ins = this.props.instance || {};
        var data = ins.data || {};
        var payload = ins.payload || {};
        var versions = payload.versions || [];
        var items = Math.ceil(payload.count/data.size);
        var pagination = self.props.status !== 'running'
                ? <ReactBootstrap.Pagination
                    prev={true}
                    next={true}
                    first={true}
                    last={true}
                    ellipsis={true}
                    items={items}
                    maxButtons={items > 5 ? 5 : items}
                    activePage={data.page || 1}
                    onSelect={this.handleSelect} />
                : '';
        return (
            <div className="box-body">
                <div className="form-group">
                    集群 <span className="badge bg-green">{payload.cluster}</span>
                </div>
                <div className="col col-xs-12">
                    <div className="my-table my-th row">
                        <div className="col col-sm-3 col-md-2">APP名称_版本</div>
                        <div className="col col-sm-3 col-md-2">URI</div>
                        <div className="col col-sm-6 col-md-4">BNS</div>
                        <div className="col col-sm-3 col-md-1">实例数</div>
                        <div className="col col-sm-3 col-md-1">内存配额</div>
                        <div className="col col-sm-3 col-md-1">硬盘配额</div>
                        <div className="col col-sm-3 col-md-1">实例信息</div>
                    </div>
                    {
                        versions.map(function (version) {                   
                            return (
                                <Version status={self.props.status} version={version} />  
                            )
                        })
                    }
                </div>
                {pagination}                           
            </div>
        )
    }
})
var ItemList = window.React.createClass({
    render: function () {
        var ins = this.props.ins;
        var self = this;
        return (
            <div>
            {
                ins.map(function (i) {
                    return (
                        <Cluster base={self.props.base} status={self.props.status} instance={i} />
                    )
                })
            }
            </div>
        )
    }
});

/**
 * 实例信息
 */
var Instance = window.React.createClass({
    getInitialState: function () {
        return {
            showDetail: false
        };
    },
    handleToggleDetail: function () {
        this.setState({
            showDetail: !this.state.showDetail
        });
    },
    getTags: function (mem, disk, cpu) {
        var result = [];
        if (mem > 80) {
            result.push('内存使用超过80%');
        }
        else if (mem > 50) {
            result.push('内存使用超过50%');
        }
        if (disk > 80) {
            result.push('硬盘使用超过80%');
        }
        else if (disk > 50) {
            result.push('硬盘使用超过50%');
        }
        if (cpu > 80) {
            result.push('CPU使用超过80%');
        }
        else if (cpu > 50) {
            result.push('CPU使用超过50%');
        }
        for (var i = 0; i < result.length; i++) {
            result[i] = <span className="box-item-col"><span className='badge bg-yellow'>{result[i]}</span></span>;
        }
        return result;
    },
    render: function () {
        var ins = this.props.ins || {};
        var version = this.props.version;
        var memPercent = ins.memUsage/version.memQuota*100;
        var diskPercent = ins.diskUsage/version.diskQuota*100;
        var cpuPercent = ins.cpuUsage > 100 ? 100 : ins.cpuUsage;
        var showDetail = this.state.showDetail ? '' : 'none';
        var showInstance = this.state.showDetail && this.props.status === 'running' ? '' : 'none';
        var tags = '';
        var boxClass = 'box box-success';
        var statusClass = 'badge bg-green';
        var stopTime = '';
        if (this.props.status !== 'running') {
            boxClass = 'box box-warning';
            statusClass = 'badge bg-yellow';
            
        } else {
            tags = this.getTags(memPercent, diskPercent, cpuPercent);
        }
        if (this.props.status === 'stopped') {
            stopTime = [<div className="box-item">停止时间: 
                            <span className="box-item-col">{ins.stopTime}</span>
                        </div>];
        }
        if (this.props.status === 'crashed') {
            stopTime = [<div className="box-item">crash时间: 
                            <span className="box-item-col">{ins.crashTime}</span>
                        </div>];
        }
        diskPercent = diskPercent > 100 ? 100 : diskPercent;
        memPercent = memPercent > 100 ? 100 : memPercent;
        return (
            <div className="col-xs-12">
                <div className={boxClass}>
                    <div onClick={this.handleToggleDetail} className="box-header with-border cursor">
                        <div>
                        {ins.hostname}
                        {this.state.showDetail ? <span className="fa fr fa-chevron-up"></span> :
    <span className="fa fr fa-chevron-down"></span>}
                        </div>
                    </div>
                    <div style={{'display': showDetail}} className="box-body">
                        <h5>物理机</h5>
                        <div>
                        <div className="box-item">机器名:
                            <span className="box-item-col">{ins.hostname}</span>
                        </div>
                        <div className="box-item">IP:
                            <span className="box-item-col">{ins.host}</span>
                        </div>
                        <div className="box-item">PORT:
                            <span className="box-item-col">{ins.port ? ins.port.join(', '): ''}</span>
                        </div>
                        </div>
                    </div>
                    <div style={{'display': showDetail}} className="box-body">
                        <h5>Container</h5>
                        <div className="box-item">PORT(K:V):
                            <span className="box-item-col">{ins.portKV ? ins.portKV.join(', ') : ''}</span>
                        </div>
                        <div className="box-item">SSH ID:
                            <span className="box-item-col">
                                <a href="" target="_blank">{ins.sshId}</a>
                            </span>
                        </div>
                    </div>
                    <div style={{'display': showInstance}} className="box-body">
                        <h5>实例状态</h5>
                        <div className="box-item">
                            <div className="progress-group">
                                <span className="progress-text">内存使用</span>
                                <span className="progress-number"><b>{ins.memUsage}</b>/{version.memQuota} MB</span>
                                <div className="progress sm">
                                    <div style={{'width': memPercent + '%'}} className="progress-bar progress-bar-aqua"></div>
                                </div>
                            </div>
                        </div>
                        <div className="box-item">
                            <div className="progress-group">
                                <span className="progress-text">CPU使用</span>
                                <span className="progress-number">{ins.cpuUsage}%</span>
                                <div className="progress sm">
                                    <div style={{'width': cpuPercent + '%'}} className="progress-bar progress-bar-aqua"></div>
                                </div>
                            </div>
                        </div>
                        <div className="box-item">
                            <div className="progress-group">
                                <span className="progress-text">硬盘使用</span>
                                <span className="progress-number"><b>{ins.diskUsage}</b>/{version.diskQuota} MB</span>
                                <div className="progress sm">
                                    <div style={{'width': diskPercent + '%'}} className="progress-bar progress-bar-aqua"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="box-body">
                        <div className="box-item">
                            启动时间: 
                            <span className="box-item-col">{ins.startTime}</span>
                        </div>
                        {stopTime}
                        <div className="box-item">状态:
                            <span className="box-item-col"><span className={statusClass}>{ins.status}</span></span>
                            {tags}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
});
module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.appInfo, 'app'), window.Reflux.connect(AppStore.baseInfo, 'base')],
    componentWillMount: function () {
        var appid = this.props.urlstate.params.appid || window.globalConfig.defaultAppId;
        AppAction.loadBaseInfo({
            appId: appid
        });
    },
    componentWillReceiveProps: function (props) {
        var appid = this.props.urlstate.params.appid || window.globalConfig.defaultAppId;
        AppAction.loadBaseInfo({
            appId: appid
        });
    },
    render: function () {
        var app = this.state.app || {};
        var base = this.state.base || {};
        return (
            <div>
                <section className="content-header">
                    <h4>APP管理 - {app.name}</h4>
                </section>
                <div className="col col-xs-12">
                    <BaseInfo base={base} app={app} />
                    <ReactBootstrap.TabbedArea defaultActiveKey={1} animation={false}>
                        <ReactBootstrap.TabPane eventKey={1} tab='运行中版本'>
                            <Running base={base} app={app} />
                        </ReactBootstrap.TabPane>
                        <ReactBootstrap.TabPane eventKey={2} tab='Crash版本'>
                            <Crashed base={base} app={app} />
                        </ReactBootstrap.TabPane>
                        <ReactBootstrap.TabPane eventKey={3} tab='历史版本'>
                            <Stopped base={base} app={app} />
                        </ReactBootstrap.TabPane>
                    </ReactBootstrap.TabbedArea>
                </div>
            </div>
        );
    }
});