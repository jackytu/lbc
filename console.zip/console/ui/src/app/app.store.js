/**
 * @file app 视图
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./app.action');

var baseInfoStore = window.Reflux.createStore({
    listenables: Action,
    onLoadBaseInfoSuccess: function (payload) {
        this.trigger(payload);
    }
});

var appInfoStore = window.Reflux.createStore({
    listenables: Action,
    onApploadSuccess: function (payload) {
        this.trigger(payload);
    }
});

var runInsStore = window.Reflux.createStore({
    listenables: Action,
    onLoadRunInsSuccess: function (payload) {
        this.trigger(payload);
    }
});

var stopInsStore = window.Reflux.createStore({
    listenables: Action,
    onLoadStopInsSuccess: function (payload) {
        this.trigger(payload);
    }
});

var crashInsStore = window.Reflux.createStore({
    listenables: Action,
    onLoadCrashInsSuccess: function (payload) {
        this.trigger(payload);
    }
});
module.exports = {
    baseInfo: baseInfoStore,
    appInfo: appInfoStore,
    runIns: runInsStore,
    stopIns: stopInsStore,
    crashIns: crashInsStore
};
