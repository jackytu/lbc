/**
 * @file app action
 * @author zhaozhixin@baidu.com
 * @dete 2015-07-03
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    loadBaseInfo: {children: ['success', 'failed']},
    loadRunIns: {children: ['success', 'failed']},
    loadStopIns: {children: ['success', 'failed']},
    loadCrashIns: {children: ['success', 'failed']},
    appload: {children: ['success', 'failed']}
});
Action.appload.listen(function (data) {
    var self = this;
    if (!data.appId) {
        return;
    }

    utils.ajax({
        url: config.xuserApi + '/api/apps/' + data.appId,
        cache: true
    }, function (payload) {
        payload = payload || [];
        self.success(payload, data);
    });
});

Action.loadCrashIns.listen(function (data) {
    var self = this;
    if (!data.appName) {
        return;
    }
    var clusters = data.clusters || [];
    var results = [];
    var deferreds = [];
    for (var i = 0; i < clusters.length; i++) {
        (function (cluster) {
            var params = {
                appName: data.appName,
                status: 'CRASHED',
                cluster: cluster.shortname,
                page: cluster.page || 1,
                size: cluster.size || 3
            };
            deferreds.push(utils.ajax({
                url: config.xuserApi + '/api/apps/instance/status',
                data: params,
                cache: true
            }, function (payload) {
                payload = payload || [];
                results.push({
                    payload: payload,
                    data: params
                });
                if (results.length === deferreds.length) {
                    results.sort();
                    self.success(results);
                }
            }));
        }(clusters[i]));
    }
    $.when.apply(this, deferreds);
});

Action.loadStopIns.listen(function (data) {
    var self = this;
    if (!data.appName) {
        return;
    }
    var clusters = data.clusters || [];
    var results = [];
    var deferreds = [];
    for (var i = 0; i < clusters.length; i++) {
        (function (cluster) {
            var params = {
                appName: data.appName,
                status: 'STOPPED',
                cluster: cluster.shortname,
                page: cluster.page || 1,
                size: cluster.size || 3
            };
            deferreds.push(utils.ajax({
                url: config.xuserApi + '/api/apps/instance/status',
                data: params,
                cache: true
            }, function (payload) {
                payload = payload || [];
                results.push({
                    payload: payload,
                    data: params
                });
                if (results.length === deferreds.length) {
                    results.sort();
                    self.success(results);
                }
            }));
        }(clusters[i]));
    }
    $.when.apply(this, deferreds);
});

Action.loadBaseInfo.listen(function (data) {
    var self = this;
    if (!data.appId) {
        return;
    }
    utils.ajax({
        url: config.xuserApi + '/api/apps/' + data.appId + '/baseinfo',
        cache: true
    }, function (payload) {
        payload = payload || {};
        self.success(payload, data);
    });
});

Action.loadRunIns.listen(function (data) {
    var self = this;
    if (!data.appName) {
        return;
    }
    var clusters = data.clusters || [];
    var results = [];
    var deferreds = [];
    for (var i = 0; i < clusters.length; i++) {
        (function (cluster) {
            var params = {
                appName: data.appName,
                status: 'RUNNING',
                cluster: cluster.shortname,
                clustername: cluster.name
            };
            deferreds.push(utils.ajax({
                url: config.xuserApi + '/api/apps/instance',
                data: params,
                cache: true
            }, function (payload) {
                payload = payload || [];
                results.push({
                    payload: payload,
                    data: params
                });
                if (results.length === deferreds.length) {
                    self.success(results);
                }
            }));
        }(clusters[i]));
    }
    $.when.apply(this, deferreds);
});

module.exports = Action;
