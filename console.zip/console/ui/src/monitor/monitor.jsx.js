/**
 * @file 监控模板
 * @author zhaozhixin@baidu.com
 */

var AppStore = require('../app/app.store');
var AppAction = require('../app/app.action');
var ConfStore = require('../conf/conf.store');
var ConfAction = require('../conf/conf.action');
module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.appInfo, 'app'), window.Reflux.connect(ConfStore, 'conf')],
    componentWillMount: function () {
        ConfAction.load({
            appId: this.props.urlstate.params.appid
        });
    },
    componentWillReceiveProps: function (props) {
        ConfAction.load({
            appId: props.urlstate.params.appid
        });
    },
    render: function () {
        var app = this.state.app || {};
        var conf = this.state.conf || {};
        var url = 'http://mt.noah.baidu.com/view/index.php?r=service/detail&service='
            + app.name + '-' + app.spaceName + '-' + app.orgName + '.JPaaS.all&from=JPaaS&domain=' + conf.uris;
        return (
            <div>
                <section className="content-header">
                    <h4>监控管理</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-header">
                            <div className="monitorhelp">
                                <span className="monitor-title">监控3.0(Argus)-技术支持: </span>
                                <span>&nbsp;&nbsp;群号 1380919</span>
                                <a target="_blank" href="http://t.cn/RhsJl7i">监控报警排查FAQ</a>
                                <a target="_blank" href="http://t.cn/RhFMJei">Argus wiki上搜答案</a>
                                <a target="_blank" href="http://t.cn/RhFMIWc">今日值班同学</a>
                            </div>
                        </div>
                        <div className="box-body">
                            <iframe className="monitor-frame"
                                scrolling="auto"
                                framebroder="0"
                                src={url}></iframe>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
});
