/**
 * @file space store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./space.action');

var imagesStore = window.Reflux.createStore({
    listenables: Action,
    getInitialState: function () {
        return {
            privateTab: true,
            images: []
        };
    },
    onLoadImagesLoaded: function (payload) {
        // this.images = payload;
        this.trigger(payload);
    }
});


module.exports = imagesStore;
