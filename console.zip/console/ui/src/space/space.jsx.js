/**
 * @file space react template
 * @author zhaozhixin@baidu.com
 */
var EditorForm = require('../utils/editorForm');
var SpaceStore = require('./space.store');
var ImagesStore = require('./space-images.store');
var SpaceAction = require('./space.action');
var UserDropDown = require('../utils/dropdown').ChooseUser;
var ModulePathDropDown = require('../utils/dropdown').ChooseModulePath;
// APP修改
var AppEdit = window.React.createClass({
    handleSubmit: function (str, data) {
        data = $.extend({
            org: this.props.space.orgId,
            space: this.props.space.id
        }, data);
        if (this.props.type === 'add') {
            SpaceAction.addApp(data);
        }
        else {
            data.name = this.props.app.name;
            data.id = this.props.app.id;
            SpaceAction.editApp(data);
        }
    },
    render: function () {
        var type = this.props.type || 'init';
        var app = this.props.app || {};
        var appName;
        if (type === 'edit') {
            appName = [<div className="form-edit-text">{app.name}</div>,
                <input value={app.name} type="hidden" name="name" />];
        }
        else if (type === 'add') {
            appName = [
                <EditorForm.item
                    editor="true"
                    require
                    min="2"
                    max="20"
                    val=""
                    valid="^(([A-Za-z0-9][-A-Za-z0-9]+[A-Za-z0-9])|([A-Za-z0-9]{1,2}))$"
                    validText="只可包含：字母、数字、减号，如：OurApp-01"
                    input={
                        <input type="text" name="name" className="form-control"
                            placeholder="只可包含：字母、数字、减号, 如：OurApp-01" />
                } />
            ];
        }
        return (
            <div className="inline-edit-wrap row" style={{display: type === 'init' ? 'none' : 'block'}}>
                <EditorForm.form className="col col-lg-7 col-md-8 col-sm-10 col-xs-12" submit={this.handleSubmit}>
                        <div className="form-group row">
                            <label className="col col-xs-12">语言 <i className="must-ico">must</i></label>
                            <div className="col col-xs-6">
                                <EditorForm.item editor="true" min="5" max="10" val={app.language}
                                    input={
                                        <select className="form-control" name="language">
                                            <option value="java">java</option>
                                            <option value="c">c/c++</option>
                                            <option value="python">python</option>
                                            <option value="php">php</option>
                                            <option value="ruby">ruby</option>
                                            <option value="nodejs">nodejs</option>
                                            <option value="go">go</option>
                                            <option value="other">其它</option>
                                        </select>
                                    } />
                            </div>
                        </div>
                        <div className="form-group">
                            <label ref="def">APP名称 <i className="must-ico">must</i></label>
                            {appName}
                        </div>
                        <div className="form-group">
                            <label>模块路径 <i className="must-ico">must</i></label>
                            <EditorForm.item
                                editor="true"
                                require
                                min="2"
                                max="80"
                                val={app.svn}
                                input={
                                    <ModulePathDropDown value={app.svn} name="svn" placeholder="请根据联想词选择模块路径" />
                                } />
                        </div>
                        <div className="form-group">
                            <label>框架</label>
                            {app.framework}
                            <EditorForm.item editor="true" max="30" val={app.framework}
                                input={
                                    <input type="text" name="framework" className="form-control" placeholder="使用的框架" />
                                } />
                        </div>

                        <div className="form-group">
                            <button type="submit" className="btn btn-sm btn-primary">确定</button>
                        </div>
                </EditorForm.form>
            </div>
        );
    }
});
// 管理员列表
var UserList = window.React.createClass({
    handleDelUser: function (user, event) {
        var cf = window.confirm('确定要删除用户 ' + user.name + '(' + user.username + ')' + ' 吗?');
        if (!cf) {
            return;
        }
        var data = $.extend({
            spaceId: this.props.space.id,
            role: this.props.role
        }, user);
        SpaceAction.delUser(data);
    },
    render: function () {
        var users = this.props.users;
        var self = this;
        return (
            <div className="form-group">
                <label ref="def">{this.props.title}</label>
                <div>
                    {
                        users.map(function (user) {
                            var hi = 'baidu://message/?id=' + user.hi;
                            var mail = 'mailto:' + user.username;
                            var title = user.name + '(' + user.username + '), hi: ' + user.hi + ', tel: ' + user.mobile;
                            return <label title={title} className="label label-default user-label">
                                {user.name}<a href={hi} className="fa fa-comment-o"></a>
                                <a href={mail} className="fa fa-envelope"></a>
                                <i ref='btnDisabled' onClick={self.handleDelUser.bind(this, user)}
                                    className="fa fa-close"></i>
                            </label>;
                        })
                    }
                </div>
            </div>
        );
    }
});
// APP列表
var AppList = window.React.createClass({
    getInitialState: function () {
        return {
            currentApp: false,
            appEditType: 'init'
        };
    },
    handleEditClick: function (type, app) {
        app = app || false;
        this.setState({
            currentApp: app,
            appEditType: type
        });
    },
    componentWillReceiveProps: function (props) {
        this.setState({
            appEditType: props.type
        });
    },
    handleDelClick: function (app) {
        var cf = window.confirm('确定要删除APP ' + app.name + ' 吗?');
        if (!cf) {
            return;
        }
        app.appId = app.id;
        SpaceAction.delApp(app);
    },
    render: function () {
        var self = this;
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">APP信息</h3>
                    <i onClick={this.handleEditClick.bind(this, 'add')} className="btn-box-tool fa fa-plus"></i>
                </div>
                <div className="box-body">
                    <div className="form-group">
                        <AppEdit type={this.state.appEditType} space={this.props.space} app={this.state.currentApp} />
                        <table className="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>APP名称</th>
                                    <th>语言</th>
                                    <th>框架</th>
                                    <th>模块路径</th>
                                    <th>操作</th>
                                </tr>
                                {
                                    this.props.apps.map(function (app) {
                                        var appUrl = '#/app/' + app.id;
                                        return <tr>
                                            <td><a href={appUrl}>{app.name} ({app.id})</a></td>
                                            <td>{app.language}</td>
                                            <td>{app.framework}</td>
                                            <td>{app.svn}</td>
                                            <td>
                                                <button onClick={self.handleEditClick.bind(this, 'edit', app)}
                                                    type="button" className="btn btn-xs btn-default">修改</button>
                                                <button onClick={self.handleDelClick.bind(this, app)}
                                                    type="button" className="btn btn-xs btn-default">删除</button>
                                            </td>
                                        </tr>;
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
});
// Image
var Image = window.React.createClass({
    mixins: [],
    handleImageClick: function (str, data) {
        this.setState({
            showTip: this.state.showTip ? false : true
        });
    },
    getInitialState: function () {
        return {
            showTip: false
        };
    },
    render: function () {
        var self = this;
        var image = this.props.image;
        return <tr>
            <td onClick={this.handleImageClick} className='cursor'>
                <p>{'' + image.name + ''}</p>
                <p className = {this.state.showTip ? '' : 'hidden'}>
                    <span>拉取方法</span>
                </p>
                <pre className = {this.state.showTip ? '' : 'hidden'}>
                docker pull dockers.baidu.com/{image.name}:latest
                </pre>
            </td>
        </tr>;
    }
});

// Images列表
var ImagesList = window.React.createClass({
    mixins: [window.Reflux.connect(ImagesStore, 'images')],
    handleTabClick: function (str, data) {
        this.setState({
            privateTab: this.state.privateTab ? false : true
        });
    },
    render: function () {
        var self = this;
        self.state.images.public = self.state.images.public || [];
        self.state.images.private = self.state.images.private || [];
        var publicImages = self.state.images.public.results || [{name: '暂未发现数据'}];
        var privateImages = self.state.images.private.results || [{name: '暂未发现数据'}];
        if (typeof this.state.privateTab === 'undefined') {
            this.state.privateTab = true;
        }
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">Images信息</h3>
                    <i className="btn-box-tool fa fa-plus"></i>
                </div>
                <div className="box-body">
                    <ul className="nav nav-tabs">
                      <li role="presentation" className={this.state.privateTab ? 'active' : ''}
                          onClick={this.handleTabClick} >
                          <a href="javascript:">Private Images</a>
                      </li>
                      <li role="presentation" className={this.state.privateTab ? '' : 'active'}
                          onClick={this.handleTabClick} >
                          <a href="javascript:">Public Images</a>
                      </li>
                    </ul>
                    <div className={this.state.privateTab ? 'form-group private-images image-tab' : 'hidden'}>
                        <table className="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Images名称</th>
                                </tr>
                                {
                                    privateImages.map(function (image) {
                                        return  <Image image={image} />;
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                    <div className={this.state.privateTab ? 'hidden' : 'form-group public-images image-tab'}>
                        <table className="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Image名称</th>
                                </tr>
                                {
                                    publicImages.map(function (image) {
                                        return   <Image image={image} />;
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
});

var UserAdd = window.React.createClass({
    handleSubmit: function (str, data) {
        data = $.extend({
            spaceId: this.props.space.id
        }, data);
        data.username = data.user;
        SpaceAction.addUser(data);
    },
    render: function () {
        var showAdd = this.props.show ? 'block' : 'none';
        return (
            <div className="inline-edit-wrap" style={{display: showAdd}}>
                <EditorForm.form submit={this.handleSubmit}>
                        <div className="form-group">
                            <label ref="def">权限类型</label>
                            <EditorForm.item editor="true"
                                input={
                                    <select className="form-control" name="role">
                                        <option value="op">管理员</option>
                                        <option value="rd">开发者</option>
                                    </select>
                            } />
                        </div>
                        <div className="form-group">
                            <label>邮箱前缀</label>
                            <EditorForm.item
                                require
                                name="username"
                                editor="true"
                                validText="邮箱前缀请勿包含特殊字符, 也不包含@baidu.com"
                                val=""
                                max="20"
                                maxText="最大20个字符"
                                valid="^[a-zA-Z0-9_\-\.]+$"
                                input={
                                    <UserDropDown name="user" placeholder="邮箱前缀" />
                                } />
                        </div>
                        <div className="form-group">
                            <button type="submit" className="btn btn-sm btn-primary">确定</button>
                        </div>
                </EditorForm.form>
            </div>
        );
    }
});
// 用户信息
var UserInfo = window.React.createClass({
    getInitialState: function () {
        return {
            showAddForm: false
        };
    },
    handleAddClick: function (str, data) {
        this.setState({
            showAddForm: true
        });
    },
    render: function () {
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">人员信息</h3>
                    <i onClick={this.handleAddClick} className="btn-box-tool fa fa-user-plus"></i>
                </div>
                <UserAdd space={this.props.space} show={this.state.showAddForm} />
                <div className="box-body">
                    <div className="col col-xs-12">
                        <UserList space={this.props.space} role="op" title="管理员" users={this.props.ops} />
                    </div>
                    <div className="col col-xs-12">
                        <UserList space={this.props.space} role="rd" title="开发者" users={this.props.rds} />
                    </div>
                </div>
            </div>
        );
    }
});
module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(SpaceStore, 'space')],
    handleEditClick: function () {
        this.setState({
            isEditorMode: 'true'
        });
    },
    handleSubmit: function (str, data) {
        alert('功能正在开发, 敬请期待');
    },
    render: function () {
        var space = this.state.space;
        var apps = space.apps || [];
        var editorSwitch = this.state.isEditorMode === 'true' ? 'block' : 'none';
        var ops = space.ops || [];
        var rds = space.rds || [];
        return (
            <div>
                <section className="content-header">
                    <h4>空间管理</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-header">
                            <h3 className="box-title">基本信息</h3>
                        </div>
                        <EditorForm.form submit={this.handleSubmit}>
                            <div className="box-body">
                                <div className="form-group">
                                    <label ref="def">空间名称</label>
                                    <div className="form-edit-text">{space.name}</div>
                                </div>
                            </div>
                            <div style={{display: editorSwitch}} className="box-footer">
                                <button type="submit" className="btn btn-sm btn-primary">保存</button>
                            </div>
                        </EditorForm.form>
                    </div>
                    <AppList space={space} apps={apps} />
                    <ImagesList />
                    <UserInfo space={space} ops={ops} rds={rds} />
                </div>

            </div>
        );
    }
});




