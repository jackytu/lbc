/**
 * @file space store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./space.action');


var spaceStore = window.Reflux.createStore({
    listenables: Action,
    getInitialState: function () {
        return {
            isEditorMode: 'false',
            space: []
        };
    },
    onLoadSuccess: function (payload, data) {
        this.trigger(payload);
        Action.loadImages(data);
    },
    onDelUserSuccess: function (payload, data) {
        Action.load(data);
    },
    onAddUserSuccess: function (payload, data) {
        Action.load(data);
    },
    onAddAppSuccess: function (payload, data) {
        Action.load(data);
    },
    onDelAppSuccess: function (payload, data) {
        Action.load(data);
    },
    onEditAppSuccess: function (payload, data) {
        Action.load(data);
    }
});



module.exports = spaceStore;
