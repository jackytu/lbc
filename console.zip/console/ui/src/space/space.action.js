/**
 * @file space action
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    load: {children: ['success']},
    delUser: {children: ['success']},
    addUser: {children: ['success']},
    addApp: {children: ['success']},
    delApp: {children: ['success']},
    editApp: {children: ['success']},
    loadImages: {children: ['loaded']}
});
Action.load.listen(function (data) {
    if (data.space && !data.spaceId) {
        data.spaceId = data.space;
    }
    var self = this;
    utils.ajax({
        type: 'get',
        url: config.xuserApi + '/api/spaces/' + data.spaceId,
        cache: true
    }, function (payload) {
        payload = payload || [];
        self.success(payload, data);
    });
});

/**
 * 删除space user
 * @param {object} [data] [username, role(rd|op), spaceId]
 */
Action.delUser.listen(function (data) {
    var self = this;
    var username = data.username.indexOf('@') === -1 ? data.username + '@baidu.com' : data.username;
    utils.ajax({
        url: config.xuserApi + '/api/spaces/' + data.spaceId + '/users/delete',
        type: 'post',
        shade: true,
        data: {
            username: username,
            role: data.role
        }
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 添加space user
 * @param {object} [data] [username, role(rd|op), spaceId]
 */
Action.addUser.listen(function (data) {
    var self = this;
    var username = data.username.indexOf('@') === -1 ? data.username + '@baidu.com' : data.username;
    utils.ajax({
        url: config.xuserApi + '/api/spaces/' + data.spaceId + '/users/add',
        type: 'post',
        shade: true,
        data: {
            username: username,
            role: data.role
        }
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 添加app
 * @param {object} [data] [name, org, space, svn, alarm, language, framework(非必须)]
 */
Action.addApp.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/apps',
        type: 'post',
        shade: true,
        data: data
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 修改app
 * @param {object} [data] [name, org, space, svn, alarm, language, framework(非必须)]
 */
Action.editApp.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/apps/edit',
        type: 'post',
        shade: true,
        data: data
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 删除app
 * @param {object} [data] [appId]
 */
Action.delApp.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/apps/' + data.appId + '/delete',
        shade: true,
        type: 'post'
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 加载Images
 * @param {object} [data] [appId]
 */
Action.loadImages.listen(function (data) {
    if (data.space && !data.spaceId) {
        data.spaceId = data.space;
    }
    var self = this;
    var result = {};
    utils.ajax({
        type: 'get',
        url: config.xuserApi + '/api/dockers/public',
        cache: true
    }).then(function (data) {
        result.public = data;
        return utils.ajax({
            type: 'get',
            url: config.xuserApi + '/api/dockers/private?name=' + data.spaceId,
            cache: true
        });
    }).then(function (payload) {
        result.private = payload;
        console.log('result');
        console.log(result);
        result = result || [];
        self.loaded(result);
    });
});

module.exports = Action;
