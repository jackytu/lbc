/**
 * @file app search action
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    search: {children: ['success', 'failed']}
});
Action.search.listen(function (keyword) {
    if (!keyword || keyword.length < 2) {
        return;
    }
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/apps/search',
        data: {
            name: keyword
        },
        cache: true
    }, function (payload) {
        payload = payload || [];
        self.success(payload, keyword);
    });
});
module.exports = Action;
