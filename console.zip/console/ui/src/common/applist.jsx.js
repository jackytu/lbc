/**
 * @file app 列表
 * @author zhaozhixin@baidu.com
 */
var utils = require('../utils/utils');
var UserAppListStore = require('./user-app-list.store');
var UserAppListAction = require('./user-app-list.action');

var AppComponent = window.React.createClass({
    render: function () {
        var url = utils.matchHash(this.props.app.appId);
        return (
            <li>
                <a title={this.props.app.appName} className="control-app" href={url}>
                    <i className="fa fa-circle-o"></i>{this.props.app.appName}
                </a>
            </li>
        );
    }
});
var AppsComponent = window.React.createClass({
    render: function () {
        var apps = this.props.apps || [];
        var show = this.props.show ? '' : 'none';
        return (
            <ul style={{display: show}}>
                {
                    apps.map(function (app) {
                        return <AppComponent app={app} />;
                    })
                }
            </ul>
        );
    }
});

var SpaceComponent = window.React.createClass({
    getInitialState: function () {
        return {
            showList: true
        };
    },
    handleToggleMenu: function (event) {
        this.setState({
            showList: !this.state.showList
        });
    },
    handleLink: function (spaceUrl, event) {
        location.hash = spaceUrl;
        event.stopPropagation();
    },
    render: function () {
        var spaceUrl = '#/space/' + this.props.space.spaceId;
        var iconClass = this.state.showList
            ? 'fa fa-chevron-up sidebar-config-icon' : 'fa fa-chevron-right sidebar-config-icon';
        return (
            <li>
                <div onClick={this.handleToggleMenu} className="control-space">
                    <i className="fa fa-circle-o text-aqua"></i>
                    <span style={{cursor: 'pointer'}} onClick={this.handleLink.bind(this, spaceUrl)}>
                        {this.props.space.spaceName}
                    </span>
                    <a title={this.props.space.spaceName} className={iconClass}></a>
                </div>
                <AppsComponent show={this.state.showList}  apps={this.props.space.apps} />
            </li>
        );
    }
});
var SpacesComponent = window.React.createClass({
    render: function () {
        return (
            <ul style={{display: this.props.show}} className="control-spacewrap">
            {
                this.props.spaces.map(function (space, index) {
                    return <SpaceComponent space={space} />;
                })
            }
            </ul>
        );
    }
});

var OrgComponent = window.React.createClass({
    getParent: function () {
        return this.props.parent;
    },
    handleToggleMenu: function (org, showList) {
        var orgId = org.orgId;
        if (showList === 'block') {
            orgId = -1;
        }
        this.getParent().setState({
            showOrgId: orgId
        });
        return false;
    },
    handleLocation: function (org, event) {
        location.hash = '#/org/' + org.orgId;
        event.stopPropagation();
        return false;
    },
    render: function () {
        var $parent = this.getParent();
        var org = this.props.org;
        var showList = 'none';
        var iconClass = 'fa fa-chevron-right sidebar-config-icon';
        if ($parent.state.showOrgId && $parent.state.showOrgId === org.orgId) {
            showList = 'block';
            iconClass = 'fa fa-chevron-up sidebar-config-icon';
        }

        return (
            <li>
                <a title={org.orgName} onClick={this.handleToggleMenu.bind(this, org, showList)}
                    href="javascript:;" className="control-org">
                    <i className="fa fa-circle-o text-red"></i>
                    <span onClick={this.handleLocation.bind(this, org)}>{org.orgName}</span>
                    <span className={iconClass}></span>
                </a>
                <SpacesComponent parent={this} show={showList} spaces={org.spaces} />
            </li>
        );
    }
});


module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(UserAppListStore, 'lists')],
    getInitialState: function () {
        UserAppListAction.load();
        return {
            showOrgId: false,
            lists: []
        };
    },
    render: function () {
        var that = this;
        return (
            <ul className="control-menu">
            {
                this.state.lists.map(function (org, index) {
                    return <OrgComponent parent={that} org={org} />;
                })
            }
            </ul>
        );
    }
});



