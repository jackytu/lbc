/**
 * @file app search store
 * @author zhaozhixin@baidu.com
 */
var Action = require('./app-search.action');

module.exports = window.Reflux.createStore({
    listenables: Action,
    onSearchSuccess: function (payload) {
        this.trigger(payload);
    }
});

