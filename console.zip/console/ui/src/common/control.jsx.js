/**
 * @file control模板
 * @author  zhaozhixin@baidu.com
 */

var ApplistComponents = require('./applist.jsx');
var SearchlistComponents = require('./searchlist.jsx');

module.exports = window.React.createClass({
    getInitialState: function () {
        return {
            keyword: false
        };
    },
    handleKeyUp: function (event) {
        var input = window.React.findDOMNode(this.refs.seachAppInput);
        this.setState({
            keyword: input.value
        });
    },
    render: function () {
        return (
            <aside id="controlSidebarWrap" className="control-sidebar control-sidebar-dark">
                <ul className="nav nav-tabs nav-justified control-sidebar-tabs">
                    <li className="active"><a><i className="fa fa-search"></i></a></li>
                    <li>
                        <a href="#control-sidebar-settings-tab" data-toggle="tab"><i className="fa fa-home"></i></a>
                    </li>
                </ul>
                <div className="tab-content">
                    <div className="tab-pane active">
                        <form action="#" method="get" className="sidebar-form">
                            <div className="input-group">
                                <input onKeyUp={this.handleKeyUp} ref="seachAppInput"
                                    autocomplete="off" type="text" className="form-control" placeholder="Search..."/>
                                <span className="input-group-btn">
                                    <button type="submit" name="search" id="search-btn" className="btn btn-flat">
                                        <i className="fa fa-search"></i>
                                    </button>
                                </span>
                            </div>
                        </form>
                        <SearchlistComponents keyword={this.state.keyword} urlstate={this.props.urlstate} />
                        <ApplistComponents urlstate={this.props.urlstate} />
                    </div>
                    <div className="tab-pane">
                    </div>
                </div>
            </aside>
        );
    }
});

