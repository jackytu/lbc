/**
 * @file header
 * @author zhaozhixin@baidu.com
 */
var SpaceStore = require('../space/space.store');
var SpaceAction = require('../space/space.action');
var AppStore = require('../app/app.store');
var AppAction = require('../app/app.action');
var OrgStore = require('../org/org.store');
var OrgAction = require('../org/org.action');
module.exports = window.React.createClass({
    mixins: [
        window.Reflux.connect(SpaceStore, 'space'),
        window.Reflux.connect(AppStore.appInfo, 'app'),
        window.Reflux.connect(OrgStore, 'org')
    ],
    componentWillMount: function () {
        this.loadData(this.props.urlstate.params);
    },
    componentWillReceiveProps: function (props) {
        this.loadData(props.urlstate.params);
    },
    loadData: function (params) {
        if (params.spaceid) {
            SpaceAction.load({
                spaceId: params.spaceid
            });
        }
        else if (params.appid) {
            AppAction.appload({
                appId: params.appid
            });
        }
        else if (params.orgid) {
            OrgAction.load({
                orgId: params.orgid
            });
        }
    },
    render: function () {
        var username = window.globalConfig.userName;
        var pos = [];
        var params = this.props.urlstate.params;
        var app;
        var space;
        var appUrl;
        var spaceUrl;
        var orgUrl;
        var org;
        if (params.appid && this.state.app) {
            app = this.state.app;
            appUrl = '#/app/' + app.id;
            spaceUrl = '#/space/' + app.spaceId;
            orgUrl = '#/org/' + app.orgId;
            pos = [
                <a href={orgUrl} className="sidebar-position-item">{app.orgName}</a>,
                <span>/</span>,
                <a href={spaceUrl} className="sidebar-position-item">{app.spaceName}</a>,
                <span>/</span>,
                <span className="sidebar-position-item">{app.name}</span>,
                <span>/</span>
            ];
        }
        else if (params.spaceid && this.state.space) {
            space = this.state.space;
            orgUrl = '#/org/' + space.orgId;
            pos = [
                <a href={orgUrl} className="sidebar-position-item">{space.orgName}</a>,
                <span>/</span>,
                <span className="sidebar-position-item">{space.name}</span>,
                <span>/</span>
            ];
        }
        else if (params.orgid && this.state.org) {
            org = this.state.org;
            pos = [
                <span className="sidebar-position-item">{org.name}</span>,
                <span>/</span>
            ];
        }
        return (
            <header className="main-header">
                <a href="#/home" className="logo">
                    <span className="logo-mini"><img width="60%" src="dist/img/logo-min.png"/></span>
                    <span className="logo-lg"><img height="30" src="dist/img/logo.png"/></span>
                </a>
                <nav className="navbar navbar-static-top">
                    <a href="javascript:;" id="btnSidebarToggle" className="sidebar-toggle">
                        <span className="sr-only">Toggle navigation</span>
                    </a>
                    <div id="sidebarPosition" className="sidebar-position">
                        <span className="fa fa-map-marker"></span> 当前位置,
                        {pos}
                        <span className="sidebar-position-item">{this.props.pageName}</span>
                    </div>
                    <div className="navbar-custom-menu">
                        <ul className="nav navbar-nav">
                            <li className="user user-menu">

                                <a href="#" className="dropdown-toggle">
                                    <img className="loading" src="dist/img/loading.gif" height="9" />
                                    <span className="hidden-xs">{username}</span>
                                </a>
                            </li>
                            <li>
                                <a style={{'padding-left': 0}} href="/logout">
                                    [退出]
                                </a>
                            </li>
                            <li id="btnControlSidebar">
                                <a href="#" className="btn-control-sidebar"><i className="fa fa-gears"></i></a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
        );
    }
});




