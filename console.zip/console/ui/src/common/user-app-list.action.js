/**
 * @file user app list action
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    load: {children: ['success', 'failed']}
});
Action.load.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/users/tree',
        cache: true
    }, function (payload) {
        payload = payload || [];
        self.success(payload, data);
    });
});

module.exports = Action;
