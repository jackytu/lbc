/**
 * @file search list
 * @author zhaozhixin@baidu.com
 */
var utils = require('../utils/utils');
var AppSearchStore = require('./app-search.store');
var AppSearchAction = require('./app-search.action');

module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(AppSearchStore, 'lists')],
    getInitialState: function () {
        return {
            lists: []
        };
    },
    componentWillReceiveProps: function (props) {
        AppSearchAction.search(props.keyword);
    },
    getMatchHtml: function (data, keyword) {
        for (var i = 0; i < data.length; i++) {
            data[i].orgHtml = addTag(data[i].orgName);
            data[i].spaceHtml = addTag(data[i].spaceName);
            data[i].appHtml = addTag(data[i].name);
        }
        function addTag(name) {
            name = name.replace(keyword, ',');
            var arr = name.split(',');
            if (arr.length === 1) {
                return name;
            }
            arr.splice(1, 0, <span className='match-text'>{keyword}</span>);
            return  arr;
        }
        return data;
    },
    render: function () {
        var showList = this.props.keyword ? 'block' : 'none';
        var lists = this.getMatchHtml(this.state.lists, this.props.keyword);
        return (
            <ul style={{display: showList}} className="control-searchlist">
                <li style={{display: lists.length > 0 || this.props.keyword.length < 3 ? 'none' : ''}}>暂无搜索结果</li>
                {
                    lists.map(function (list) {
                        var orgUrl = '#/org/' + list.orgId;
                        var spaceUrl = '#/space/' + list.spaceId;
                        var appUrl = utils.matchHash(list.appId);
                        return <li>
                            <a href={orgUrl}><i className="fa fa-circle-o text-red"></i> {list.orgHtml}</a>
                            <a href={spaceUrl}><i className="fa fa-circle-o text-aqua"></i> {list.spaceHtml}</a>
                            <a href={appUrl}><i className="fa fa-circle-o"></i> {list.appHtml}</a>
                        </li>;
                    })
                }
            </ul>
        );
    }
});




