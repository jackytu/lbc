/**
 * @file sidebar
 * @author zhaozhixin@baidu.com
 */
var intro = require('../utils/intro');
module.exports = window.React.createClass({
    handleStartIntro: function () {
        intro.common.start();
    },
    render: function () {
        var menus = [{
            id: 'dashboard',
            name: 'Dashboard',
            url: '#/home',
            icon: 'fa fa-dashboard'
        },
        {
            id: 'appManager',
            name: 'APP视图',
            url: '#/app/' + this.props.appId,
            icon: 'fa fa-th'
        },
        {
            id: 'monitorManager',
            name: '监控管理',
            url: '#/monitor/' + this.props.appId,
            icon: 'fa fa-bar-chart'
        },
        {
            id: 'confManager',
            name: '配置管理',
            url: '#/conf/' + this.props.appId,
            icon: 'fa fa-cog'
        },
        {
            id: 'autopushManager',
            name: '变更管理',
            url: '#/autopush/' + this.props.appId,
            icon: 'fa fa-cloud-upload'
        }];
        var self = this;
        return (
            <aside className="main-sidebar sidebar-mini">
                <section className="sidebar">
                    <div className="user-panel">
                        <div className="pull-left image">
                            <a href="javascript: ;">
                                <img width="26" src="dist/img/hi.png" alt="User Image" />
                            </a>
                        </div>
                        <div className="pull-left info">
                            <p><a href="javascript:;">&nbsp;值班电话: 131-2294-6382</a></p>
                        </div>
                    </div>

                    <ul className="sidebar-menu">
                        <li  className="header">MENU</li>
                        {
                            menus.map(function (menu) {
                                var current = self.props.pageName === menu.id ? 'active' : '';
                                return <li className={current}>
                                    <a href={menu.url}>
                                        <i className={menu.icon}></i>
                                        <span>{menu.name}</span>
                                    </a>
                                </li>;
                            })
                        }
                        <li className="header">LINKS</li>
                        <li><a target="_blank" onClick={this.handleStartIntro}>
                            <i className="fa fa-circle-o text-yellow"></i> <span>使用引导</span>
                        </a></li>
                    </ul>
                </section>
            </aside>
        );
    }
});