/**
 * @file  user app list store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./user-app-list.action');

module.exports = window.Reflux.createStore({
    listenables: Action,
    onLoadSuccess: function (payload) {
        this.trigger(payload);
    }
});

