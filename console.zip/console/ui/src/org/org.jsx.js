/**
 * @file org 模板
 * @author zhaozhixin@baidu.com
 */
var EditorForm = require('../utils/editorForm');
var OrgStore = require('./org.store');
var OrgAction = require('./org.action');

var UserDropDown = require('../utils/dropdown').ChooseUser;
// space修改
var SpaceEdit = window.React.createClass({
    handleSubmit: function (str, data) {
        data = $.extend({
            org: this.props.org.id,
            pdb: 0,
            version: 2
        }, data);
        OrgAction.addSpace(data);
    },
    render: function () {
        var type = this.props.type || 'init';
        var space = this.props.space || {};
        var spaceName;
        if (type === 'edit') {
            spaceName = [<div className="form-edit-text">{space.name}</div>];
        }
        else if (type === 'add') {
            spaceName = [
                <EditorForm.item
                    editor="true"
                    require
                    min="2"
                    max="20"
                    val=""
                    valid="^(([A-Za-z0-9][-A-Za-z0-9]+[A-Za-z0-9])|([A-Za-z0-9]{1,2}))$"
                    validText="只可包含：字母、数字、减号，如：OurSpace-01"
                    input={
                        <input type="text" name="name" className="form-control"
                            placeholder="只可包含：字母、数字、减号，如：OurSpace-01" />
                } />
            ];
        }
        return (
            <div className="inline-edit-wrap row" style={{display: type === 'init' ? 'none' : 'block'}}>
                <EditorForm.form className="col col-lg-7 col-md-8 col-sm-10 col-xs-12" submit={this.handleSubmit}>
                        <div className="form-group">
                            <label ref="def">空间名称</label>
                            {spaceName}
                        </div>
                        <div className="form-group">
                            <button type="submit" className="btn btn-sm btn-primary">确定</button>
                        </div>
                </EditorForm.form>
            </div>
        );
    }
});
// 管理员列表
var UserList = window.React.createClass({
    handleDelUser: function (user) {
        var cf = window.confirm('确定要删除用户 ' + user.name + '(' + user.username + ')' + ' 吗?');
        if (!cf) {
            return;
        }
        var data = $.extend({
            orgId: this.props.org.id
        }, user);
        OrgAction.delUser(data);
    },
    render: function () {
        var self = this;
        var users = this.props.users;
        return (
            <div className="form-group">
                <label ref="def">{this.props.title}</label>
                <div>
                    {
                        users.map(function (user) {
                            var hi = 'baidu://message/?id=' + user.hi;
                            var mail = 'mailto:' + user.username;
                            var title = user.name + '(' + user.username + '), hi: ' + user.hi + ', tel: ' + user.mobile;
                            return <label title={title} className="label label-default user-label">
                                {user.name}<a href={hi} className="fa fa-comment-o"></a>
                                <a href={mail} className="fa fa-envelope"></a>
                                <i onClick={self.handleDelUser.bind(this, user)} className="fa fa-close"></i>
                            </label>;
                        })
                    }
                </div>
            </div>
        );
    }
});

// space列表
var SpaceList = window.React.createClass({
    getInitialState: function () {
        return {
            currentSpace: false,
            spaceEditType: 'init'
        };
    },
    handleEditClick: function (type, space) {
        space = space || false;
        this.setState({
            currentSpace: space,
            spaceEditType: type
        });
    },
    handleDelSpace: function (space) {
        var cf = window.confirm('空间里如果有APP请先删除APP, 确定要删除空间 ' + space.name + ' 吗?');
        if (!cf) {
            return;
        }
        OrgAction.delSpace({
            spaceId: space.id,
            orgId: this.props.org.id
        });
    },
    render: function () {
        var self = this;
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">空间信息</h3>
                    <i onClick={this.handleEditClick.bind(this, 'add')} className="btn-box-tool fa fa-plus"></i>
                </div>
                <div className="box-body">
                    <div className="form-group">
                        <SpaceEdit org={this.props.org} type={this.state.spaceEditType}
                            space={this.state.currentSpace} />
                        <table className="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>空间名称</th>
                                    <th>空间ID</th>
                                    <th>操作</th>
                                </tr>
                                {
                                    this.props.spaces.map(function (space) {
                                        var spaceUrl = '#/space/' + space.id;
                                        return <tr>
                                            <td><a href={spaceUrl}>{space.name}</a></td>
                                            <td>
                                                {space.id}
                                            </td>
                                            <td>
                                                <button onClick={self.handleDelSpace.bind(this, space)}
                                                    type="button" className="btn btn-xs btn-default">删除</button>
                                            </td>
                                        </tr>;
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    }
});
var UserAdd = window.React.createClass({
    handleSubmit: function (str, data) {
        data = $.extend({
            orgId: this.props.org.id
        }, data);
        data.username = data.user;
        OrgAction.addUser(data);
    },
    render: function () {
        var showAdd = this.props.show ? 'block' : 'none';
        return (
            <div className="inline-edit-wrap row" style={{display: showAdd}}>
                <EditorForm.form className="col col-lg-7 col-md-8 col-sm-10 col-xs-12" submit={this.handleSubmit}>
                        <div className="form-group">
                            <label>邮箱前缀 <i className="must-ico">must</i></label>
                            <EditorForm.item
                                require
                                name="username"
                                editor="true"
                                validText="邮箱前缀请勿包含特殊字符, 也不包含@baidu.com"
                                val=""
                                max="20"
                                maxText="最大20个字符"
                                valid="^[a-zA-Z0-9_\-\.]+$"
                                input={
                                    <UserDropDown name="user" placeholder="邮箱前缀" />
                                } />
                        </div>
                        <div className="form-group">
                            <button type="submit" className="btn btn-sm btn-primary">确定</button>
                        </div>
                </EditorForm.form>
            </div>
        );
    }
});
// 用户信息
var UserInfo = window.React.createClass({
    getInitialState: function () {
        return {
            showAddForm: false
        };
    },
    handleAddClick: function (str, data) {
        this.setState({
            showAddForm: true
        });
    },
    render: function () {
        return (
            <div className="box box-primary">
                <div className="box-header">
                    <h3 className="box-title">人员信息</h3>
                    <i onClick={this.handleAddClick} className="btn-box-tool fa fa-user-plus"></i>
                </div>
                <UserAdd org={this.props.org} show={this.state.showAddForm} />
                <div className="box-body">
                    <div className="col col-xs-12">
                        <UserList org={this.props.org} title="管理员列表" users={this.props.users} />
                    </div>
                </div>
            </div>
        );
    }
});
module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(OrgStore, 'org')],
    getInitialState: function () {
        return {
            isEditorMode: 'false',
            org: []
        };
    },
    handleEditClick: function () {
        this.setState({
            isEditorMode: 'true'
        });
    },
    handleSubmit: function (str, data) {
        console.log(data);
        console.log(str);
        alert('功能正在开发, 敬请期待');
    },
    render: function () {
        var org = this.state.org;
        var spaces = org.spaces || [];
        var editorSwitch = this.state.isEditorMode === 'true' ? 'block' : 'none';
        var users = org.users || [];
        return (
            <div>
                <section className="content-header">
                    <h4>产品线管理</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-header">
                            <h3 className="box-title">基本信息</h3>
                        </div>
                        <EditorForm.form submit={this.handleSubmit}>
                            <div className="box-body">
                                <div className="form-group">
                                    <label ref="def">产品线名称</label>
                                    <div className="form-edit-text">{org.name}</div>
                                </div>
                                <div className="form-group">
                                    <label ref="def">中文名称</label>
                                    <div className="form-edit-text">{org.cnName}</div>
                                </div>
                            </div>

                            <div style={{display: editorSwitch}} className="box-footer">
                                <button type="submit" className="btn btn-sm btn-primary">保存</button>
                            </div>
                        </EditorForm.form>
                    </div>
                    <SpaceList org={org} spaces={spaces} />
                    <UserInfo org={org} users={users} />
                </div>
            </div>
        );
    }
});




