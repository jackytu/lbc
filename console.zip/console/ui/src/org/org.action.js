/**
 * @file org管理
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    load: {children: ['success', 'failed']},
    delUser: {children: ['success', 'failed']},
    addUser: {children: ['success', 'failed']},
    delSpace: {children: ['success', 'failed']},
    addSpace: {children: ['success', 'failed']}
});
Action.load.listen(function (data) {
    if (data.org && !data.orgId) {
        data.orgId = data.org;
    }
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/orgs/' + data.orgId,
        cache: true
    }, function (payload) {
        payload = payload || [];
        self.success(payload, data);
    });
});

/**
 * 删除space
 * @param {number} [data.spaceId] [space id]
 */
Action.delSpace.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/spaces/' + data.spaceId + '/delete',
        shade: true,
        type: 'post'
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 添加space
 * @param {object} [data] [org, version, pdb, name]
 */
Action.addSpace.listen(function (data) {
    var self = this;
    utils.ajax({
        url: config.xuserApi + '/api/spaces',
        shade: true,
        data: data,
        type: 'post'
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 删除org user
 * @param {object} [data] [username, role(rd|op), spaceId]
 */
Action.delUser.listen(function (data) {
    var self = this;
    var username = data.username.indexOf('@') === -1 ? data.username + '@baidu.com' : data.username;
    utils.ajax({
        url: config.xuserApi + '/api/orgs/' + data.orgId + '/users/delete',
        shade: true,
        type: 'post',
        data: {
            username: username
        }
    }, function (payload) {
        self.success(payload, data);
    });
});

/**
 * 添加org user
 * @param {object} [data] [username, role[rd|op], spaceId]
 */
Action.addUser.listen(function (data) {
    var self = this;
    var username = data.username.indexOf('@') === -1 ? data.username + '@baidu.com' : data.username;
    utils.ajax({
        url: config.xuserApi + '/api/orgs/' + data.orgId + '/users/add',
        shade: true,
        data: {
            username: username
        },
        type: 'post'
    }, function (payload) {
        self.success(payload, data);
    });
});
module.exports = Action;
