/**
 * @file org store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./org.action');

module.exports = window.Reflux.createStore({
    listenables: Action,
    onLoadSuccess: function (payload) {
        this.trigger(payload);
    },
    onDelUserSuccess: function (payload, data) {
        Action.load(data);
    },
    onAddUserSuccess: function (payload, data) {
        Action.load(data);
    },
    onDelSpaceSuccess: function (payload, data) {
        Action.load(data);
    },
    onAddSpaceSuccess: function (payload, data) {
        Action.load(data);
    }
});
