/**
 * @file 配置文件
 * @author zhaozhixin@baidu.com
 */
var env = window.globalConfig.isDebug ? 'dev' : 'product';
var configs = {
    dev: {
        // xuserApi: 'http://10.107.50.45:8181'
        xuserApi: 'http://10.107.26.32:8081',
        autopushApi: 'http://10.107.50.45:8181'
    },
    product: {
        xuserApi: '/off',
        autopushApi: '/off'
    }
};
module.exports = configs[env];
