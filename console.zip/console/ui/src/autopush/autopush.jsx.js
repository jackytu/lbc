/**
 * @file autopush 模板
 * @author zhaozhixin@baidu.com
 */

var AutopushStore = require('./autopush.store');
var AutopushAction = require('./autopush.action');
var AppStore = require('../app/app.store');
var AppAction = require('../app/app.action');
var config = require('../config');

module.exports = window.React.createClass({
    mixins: [window.Reflux.connect(AppStore.appInfo, 'app')],
    render: function () {
        var app = this.state.app || {};
        var conf = this.state.conf || {};
        var url = app.id ? config.autopushApi + '/api/autopush2/index?app_id=' + app.id : '';
        return (
            <div>
                <section className="content-header">
                    <h4>变更管理</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-body">
                            <iframe className="monitor-frame"
                                scrolling="auto"
                                framebroder="0"
                                src={url}></iframe>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
});





