/**
 * @file 上线
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var utils = require('../utils/utils');
var Action = window.Reflux.createActions({
    load: {children: ['success']}
});
Action.load.listen(function (data) {
});
module.exports = Action;
