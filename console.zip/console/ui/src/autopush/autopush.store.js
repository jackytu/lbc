/**
 * @file autopush store
 * @author  zhaozhixin@baidu.com
 */

var Action = require('./autopush.action');

module.exports = window.Reflux.createStore({
    listenables: Action,
    onLoadSuccess: function (payload) {
        this.trigger(payload);
    }
});
