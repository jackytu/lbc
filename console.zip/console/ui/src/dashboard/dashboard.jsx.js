/**
 * @file dashboard todo
 * @author 115857620@qq.com
 */
module.exports = window.React.createClass({
    render: function () {
        return (
            <div>
                <section className="content-header">
                    <h4>DASHBOARD</h4>
                </section>
                <div className="col-xs-12">
                    <div className="box box-primary">
                        <div className="box-header">
                            <h3 className="box-title">DASHBOARD</h3>
                        </div>
                        <div className="box-body">
                            <p>视图开发中, 敬请期待...</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
});
