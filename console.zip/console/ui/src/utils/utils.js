/**
 * @file utils
 * @author zhaozhixin@baidu.com
 */
var config = require('../config');
var loaderCount = 0;
function hideLoading() {
    loaderCount--;
    if (loaderCount <= 0) {
        $('.loading').hide();
        $('.shade').hide();
    }
}
function showLoading(showShade) {
    loaderCount++;
    $('.loading').show();
    showShade && $('.shade').show();
}

function showTips(type, info) {
    var obj = $('.mycallout');
    var autoHide = true;
    var html = '<p>操作成功!</p>';
    switch (type) {
        case 'noauth':
            var userList = '';
            if (info && info.length > 0) {
                var len = Math.min(info.length, 5);
                for (var i = 0; i < len; i++) {
                    userList += '<label title="' + info[i].name
                    + '(' + info[i].username + '), hi:' + info[i].hi
                    + ', tel:' + info[i].mobile
                    + '" class="label label-default" style="background:transparent;display:inline-block;"><span>'
                    + info[i].name + '</span><a href="baidu://message/?id='
                    + info[i].hi + '" class="fa fa-comment-o"></a><a href="mailto:'
                    + info[i].username + '" class="fa fa-envelope"></a></label>';
                }
            }
            html = '<h4>没有访问权限<i style="padding:0;font-size:16px" class="btn-box-tool fa fa-close"></i></h4><p>请联系'
                + userList + '添加权限</p>';
            autoHide = false;
            obj.html(html).attr('class', 'mycallout callout callout-warning');
            break;
        case 'error':
            html = '<h4>操作失败<i style="padding:0;font-size:16px" class="btn-box-tool fa fa-close"></i></h4> <p>原因:'
                + info + '</p>';
            autoHide = false;
            obj.html(html).attr('class', 'mycallout callout callout-danger');
            break;
        case 'notFound':
            html = '<h4>错误:404<i style="padding:0;font-size:16px" class="btn-box-tool fa fa-close"></i></h4>'
                + '<p>页面或请求不存在!</p>';
            autoHide = false;
            obj.html(html).attr('class', 'mycallout callout callout-warning');
            break;
        default:
            obj.html(html).attr('class', 'mycallout callout callout-success');
    }
    obj.find('.btn-box-tool').unbind('click').bind('click', function () {
        obj.hide();
    });
    obj.fadeIn();
    if (autoHide) {
        setTimeout(function () {
            obj.fadeOut();
        }, 1500);
    }
}
module.exports = {
    ajax: function (options, callback) {
        if (options.type && options.type !== 'get' && options.type !== 'GET') {
            options.data = options.data ? JSON.stringify(options.data) : {};
        }
        showLoading(options.shade);
        options = $.extend({
            contentType: 'application/json',
            dataType: 'json',
            xhrFields: {
                withCredentials: true
            },
            complete: function (res) {
                hideLoading();
                var data = res.responseJSON || {};
                if (data.code === 200) {
                    callback && callback(data.data);
                }
                else {
                    console.group && console.group('request warn, code: ' + data.code);
                    console.log('request: ');
                    console.log(options);
                    console.log('resposne: ');
                    console.log(res);
                    console.group && console.groupEnd();
                }
            },
            success: function (res) {
                var result = res || {};
                switch (result.code) {
                    case 200:
                        options.shade && showTips();
                        break;
                    case 403:
                        showTips('noauth', res.data);
                        break;
                    case 404:
                        showTips('notFound');
                        break;
                    default:
                        if (options.shade) {
                            var message = res.message || '服务异常, 请稍后再试, 或者联系ONCALL同学解决';
                            showTips('error', message);
                        }
                }
            },
            error: function (res) {
                if (options.shade) {
                    var message = res.message || '服务异常, 请稍后再试, 或者联系ONCALL同学解决';
                    showTips('error', message);
                }
            }
        }, options);
        return $.ajax(options);
    },

    /**
     * [dateFormat description]
     * @param  {[string]} timestamp [时间戳]
     * @param  {[string]} fmt       [格式 'yyyy-MM-dd']
     * @return {[string]}           [格式化好的日期]
     */
    dateFormat: function (timestamp, fmt) {
        var date = new Date(timestamp);
        var o = {
            // 月份
            'M+': date.getMonth() + 1,
            // 日
            'd+': date.getDate(),
            // 小时
            'h+': date.getHours(),
            // 分
            'm+': date.getMinutes(),
            // 秒
            's+': date.getSeconds(),
            // 季度
            'q+': Math.floor((date.getMonth() + 3) / 3),
            // 毫秒
            'S': date.getMilliseconds()
        };
        if (/(y+)/.test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
        }
        for (var k in o) {
            if (new RegExp('(' + k + ')').test(fmt)) {
                fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1)
                    ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)));
            }
        }
        return fmt;
    },
    matchHash: function (appid) {
        var rules = [
            '/autopush/',
            '/app/',
            '/conf/'
        ];
        var hash = location.hash;
        for (var i = 0; i < rules.length; i++) {
            if (hash.indexOf(rules[i]) !== -1) {
                return '#' + rules[i] + appid;
            }
        }
        return '#/app/' + appid;
    }
};
