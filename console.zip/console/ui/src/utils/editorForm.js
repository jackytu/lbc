/**
 * @file 表单
 * @author zhaozhixin@baidu.com
 */

module.exports = {
    /**
     * [getInitialState description]
     * @param {[string]} [max] [最大长度]
     * @param {[string]} [min] [最小长度]
     * @param {[boolean]} [require] [是否必须]
     * @param {[string]} [valid] [自定义验证规则]
     * @param {[string]} [maxText] [最大长度提示]
     * @param {[string]} [minText] [最小长度提示]
     * @param {[string]} [requireText] [必选项提示]
     * @param {[string]} [validText] [自定义验证规则提示]
     * @param {[string]} [val] [当前值]
     * @param {[string]} [dval] [显示的值, 当dval不定义的时候, 显示val]
     * @example
     *     <EditorForm.form submit={this.handleSubmit}>
                <div className="box-body">
                    <div className="form-group">
                        <label ref="def">Input</label>
                        <EditorForm.item editor="false" require min="5" max="10" val=""
                            input={<input type="text" name="fsdf"
                            className="form-control" placeholder="Enter email" />} />
                    </div>
                    <div className="form-group">
                        <label>Password</label>
                        <EditorForm.item editor="false" require min="5" max="10" val=""
                            input={<input type="password" name="password"
                            className="form-control" placeholder="Enter email" />} />
                    </div>
                    <div className="form-group">
                        <label>Checkbox</label>
                        <EditorForm.item editor="false" require min="5" max="10" dval="需要,不需要" val="option1,option2"
                            input={
                                <div>
                                    <label className="checkbox-inline">
                                        <input name="checkbox1" type="checkbox" value="option1" /> 需要
                                    </label>
                                    <label className="checkbox-inline">
                                        <input name="checkbox2" type="checkbox" value="option2" /> 不需要
                                    </label>
                                </div>
                            } />

                    </div>
                    <div className="form-group">
                        <label>Radio</label>
                        <EditorForm.item editor="false" require min="5" max="10" dval="需要" val="option1"
                            input={
                                <div>
                                    <label className="checkbox-inline">
                                        <input type="radio" name="radio" value="option1" /> 需要
                                    </label>
                                    <label className="checkbox-inline">
                                        <input type="radio" name="radio" value="option2" /> 不需要
                                    </label>
                                </div>
                            } />
                    </div>
                    <div className="form-group">
                        <label>Selected</label>
                        <EditorForm.item editor="false" dval="fd2f" val="ffd"
                            input={<select className="form-control" name="select">
                                <option value="fd">fdf</option><option value="ffd">fd2f</option>
                            </select>} />
                    </div>
                    <div className="form-group">
                        <label>Textarea</label>
                        <EditorForm.item editor="false" require min="5" max="10" val="false"
                            input={<textarea className="form-control" name="textarea"></textarea>} />
                    </div>
                </div>

                <div className="box-footer">
                    <button type="submit" className="btn btn-primary">Submit</button>
                </div>
            </EditorForm.form>
     */
    item: window.React.createClass({

        /**
         * 初始化
         * @return {[object]} [description]
         */
        getInitialState: function () {
            return {
                isDirty: false,
                isRequired: this.props.require && !this.props.val ? false : true,
                isMin: true,
                isMax: true,
                isCustomValid: true,
                isValid: true
            };
        },

        /**
         * 设置value
         * @param {[string]} val [用户定义的val]
         * @param {[element]} el  [dom]
         */
        setValue: function (val, el) {
            switch (el[0].type) {
                case 'select-one':
                    el.find('option').each(function () {
                        if (val === $(this).val()) {
                            $(this).attr('selected', 'selected');
                            return;
                        }
                    });
                    break;
                case 'checkbox':
                case 'radio':
                    el.each(function () {
                        val = String(val);
                        if (val && val.indexOf($(this).val()) !== -1) {
                            $(this).attr('checked', 'checked');
                        }
                    });
                    break;
                default:
                    el.val(val);
            }
            var state;
            if (this.props.require) {
                state = {
                    isRequired: val ? true : false,
                    isMin: true,
                    isMax: true,
                    isCustomValid: true,
                    isDirty: true,
                    isValid: true
                };
            }
            else {
                state = {
                    isRequired: true,
                    isMin: true,
                    isMax: true,
                    isCustomValid: true,
                    isDirty: true,
                    isValid: true
                };
            }
            this.setValidState(state);
        },
        componentWillReceiveProps: function (props) {
            this.setValue(props.val, this.getRealDom());
        },

        /**
         * 在组建装载好以后执行, 这个是react的默认事件, 在这里获取DOM做事件绑定
         */
        componentDidMount: function () {
            var $formEditor = this.getRealDom();
            var self = this;
            var status = {
                isRequired: true,
                isMin: true,
                isMax: true,
                isCustomValid: true,
                isDirty: true,
                isValid: true
            };
            this.setValue(this.props.val, $formEditor);
            // checkbox
            if ($formEditor[0].type === 'checkbox') {
                $formEditor.bind('change', function () {
                    if (self.props.require) {
                        status.isRequired = false;
                        $formEditor.each(function () {
                            if ($(this).is(':checked')) {
                                status.isRequired = true;
                                return;
                            }
                        });
                    }
                    self.setValidState(status);
                });
            }
            // select
            else if ($formEditor[0].type === 'select-one') {
                $formEditor.bind('change', function () {
                    $formEditor.unbind('change');
                    self.setValidState(status);
                });
            }
            // input
            else {
                $formEditor.bind('keyup', function () {
                    var val = $(this).val().trim();
                    if (self.props.require) {
                        status.isRequired = val ? true : false;
                    }
                    if (self.props.max) {
                        status.isMax = val.length > self.props.max ? false : true;
                    }
                    if (self.props.min) {
                        status.isMin = val.length < self.props.min ? false : true;
                    }
                    if (self.props.valid) {
                        status.isCustomValid = new RegExp(self.props.valid).test(val) ? true : false;
                    }
                    self.setValidState(status);
                });
            }
        },

        /**
         * 获取真实DOM
         * @return {[element]} [dom]
         */
        getRealDom: function () {
            return $(this.refs.wrap.getDOMNode()).find('input, textarea, select');
        },

        /**
         * 设置验证状态
         * @param {[object]} status [传入状态]
         */
        setValidState: function (status) {
            status.isValid = true;
            for (var i in status) {
                if (!status.hasOwnProperty(i)) {
                    return;
                }
                if (!status[i]) {
                    status.isValid = false;
                    break;
                }
            }
            this.setState(status);
        },

        /**
         * 获取验证规则的class
         * @param  {[object]} status [传入状态]
         * @return {[string]}        [类名]
         */
        getValidClass: function (status) {
            var className = 'form-valid';
            for (var i in status) {
                if (!status.hasOwnProperty(i)) {
                    return;
                }
                var item = i.replace(/^is(.*)$/, '$1').toLocaleLowerCase();
                if (status[i]) {
                    className = className + ' jp-' + item;
                }
                else {
                    className = className + ' jp-no' + item;
                }
            }
            return className;
        },

        /**
         * [获取提示语]
         * @param  {[type]} status [传入状态]
         * @return {[string]}        [提示语]
         */
        getTips: function (status) {
            var text = {
                isMax: this.props.maxText || '长度不能大于' + (this.props.max || 0),
                isMin: this.props.minText || '长度不能小于' + (this.props.min || 0),
                isRequired: this.props.requireText || '此项必填',
                isCustomValid: this.props.validText || '验证未通过'
            };
            for (var i in status) {
                if (!status[i] && text[i]) {
                    return text[i];
                }
            }
            return '';
        },
        render: function () {
            var showInput = this.props.editor === 'true' ? '' : 'none';
            var showText = this.props.editor === 'true' ? 'none' : '';
            var showTip = this.props.editor === 'true' && !this.state.isValid ? '' : 'none';
            var className = this.getValidClass(this.state);
            var tipText = this.getTips(this.state);
            return (
                <div data-required={this.state.isRequired} data-dirty={this.state.isDirty}
                    data-valid={this.state.isValid} className="form-wrap" ref="wrap">
                    <p style={{display: showText}} className="form-edit-text">
                        {this.props.dval || this.props.val || '暂无数据'}</p>
                    <div className={className} style={{display: showInput}}>
                    {this.props.input}
                    </div>
                    <p style={{display: showTip}} className="form-tip">{tipText}</p>
                </div>
            );
        }
    }),
    form: window.React.createClass({

        /**
         * 监听表单提交, 拦截默认的提交方式, 收集表单数据传给this.props.submit方法
         * @return {[boolean]}       [description]
         */
        handleSubmit: function () {
            var $form = $(this.refs.form.getDOMNode());
            var isDirty = false;
            var i;
            for (i = 0; i < $form.find('.form-wrap').length; i++) {
                var item = $form.find('.form-wrap').eq(i);
                if (item.attr('data-required') !== 'true' && item.attr('data-required') !== true) {
                    alert('请填写所有必填项!');
                    return false;
                }
                if (item.attr('data-valid') !== 'true' && item.attr('data-valid') !== true) {
                    alert('请通过所有验证项!');
                    return false;
                }
                if (item.attr('data-dirty') === 'true' || item.attr('data-dirty') === true) {
                    isDirty = true;
                }
            }
            if (!isDirty && !this.props.noDirty) {
                alert('请修改表单后再提交!');
                return false;
            }
            var dataArr = $form.serializeArray();
            var dataObj = {};
            for (i = 0; i < dataArr.length; i++) {
                var name = dataArr[i].name;
                if (!dataObj[name]) {
                    dataObj[name] = dataArr[i].value;
                }
                else {
                    dataObj[name] = dataObj[name] + ',' + dataArr[i].value;
                }
            }
            this.props.submit($form.serialize(), dataObj, dataArr);
            return false;
        },
        render: function () {
            return (
                <form autoComplete="off" className={this.props.className} onSubmit={this.handleSubmit} ref="form">
                    {this.props.children}
                </form>
            );
        }
    })
};
