/**
 * @file 引导流程生成器
 * @author zhaozhixin@baidu.com
 */

var intro = require('intro.js').introJs;
module.exports = {
    common: {
        intro: false,
        key: 'COMMON_INTRO_DISABLED',
        getIntroObj: function () {
            if (!this.intro) {
                this.intro = intro();
            }
            return this.intro;
        },
        init: function () {
            this.getIntroObj().setOptions({
                // 设定引导的步骤
                steps: [{
                    element: $('#btnControlSidebar')[0],
                    intro: 'APP选择功能搬家到这里啦',
                    position: 'left'
                }, {
                    element: $('#sidebarPosition')[0],
                    intro: '记录当前位置, 方便快速切换'
                }, {
                    element: $('#btnSidebarToggle')[0],
                    intro: '点这里可以缩放左边菜单'
                }, {
                    element: $('#controlSidebarWrap')[0],
                    intro: '这里可以查找产品线, 空间, APP',
                    position: 'left'
                }],
                showBullets: false
            }).onchange(function (targetElement) {
                if ($(targetElement).attr('id') === 'controlSidebarWrap') {
                    $('.control-sidebar').addClass('control-sidebar-open');
                    setTimeout(function () {
                        window.scrollTo(0, 0);
                    }, 100);
                }
            });
        },
        start: function () {
            if (!this.intro) {
                this.init();
            }
            this.getIntroObj().start();
        }
    }
};
