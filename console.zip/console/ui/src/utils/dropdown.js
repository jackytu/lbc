/**
 * @file util dropdown
 * @author zhaozhixin@baidu.com
 */
var DropdownInput = window.DropdownInput;
var config = require('../config');

var timer = null;
module.exports = {
    ChooseModulePath: window.React.createClass({
        getInitialState: function () {

            return {
                options: [],
                value: null
            };
        },
        handleChange: function (val) {
            var self = this;
            timer && clearTimeout(timer);
            timer = setTimeout(function () {
                $.ajax({
                    url: config.xuserApi + '/api/apps/modules?query=' + val.value,
                    dataType: 'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    success: function (res) {
                        if (res && res.code === 200) {
                            self.setState({
                                options: res.data
                            });
                        }
                    }
                });
            }, 200);
        },
        componentWillReceiveProps: function (props) {
            this.setState({
                value: props.value
            });
        },
        render: function () {
            return (
                <DropdownInput
                    menuClassName='dropdown-input'
                    onChange={this.handleChange}
                    placeholder={this.props.placeholder}
                    name={this.props.name}
                    defaultValue={this.state.value}
                    options={this.state.options} />
            );
        }
    }),
    ChooseUser: window.React.createClass({
        getInitialState: function () {
            return {
                options: [],
                value: null
            };
        },
        handleChange: function (val) {
            var self = this;
            timer && clearTimeout(timer);
            timer = setTimeout(function () {
                $.ajax({
                    url: config.xuserApi + '/api/users/query?keyword=' + val.value,
                    dataType: 'json',
                    xhrFields: {
                        withCredentials: true
                    },
                    success: function (res) {
                        if (res && res.code === 200) {
                            self.setState({
                                options: res.data
                            });
                        }
                    }
                });
            }, 300);
        },
        render: function () {
            return (
                <DropdownInput
                    menuClassName='dropdown-input'
                    onChange={this.handleChange}
                    placeholder={this.props.placeholder}
                    priKey='loginName'
                    name={this.props.name}
                    defaultValue={this.state.value}
                    displayKeys='name,dept'
                    options={this.state.options} />
            );
        }
    })
};
