/**
 * @file fis配置文件
 * @author  zhaozhixin@baidu.com
 */
fis.config.set('project.exclude', ['node_modules/**', 'src/**']);
fis.config.set('roadmap.path', [
    {
        reg: 'dist/js/app.js',
        url: '/off/dist/js/app.js',
        useStandard: false
    },
    {
        reg: 'dist/lib/lib.js',
        url: '/off/dist/lib/lib.js',
        useStandard: false
    },
    {
        reg: 'dist/img/**',
        useCompile: false,
        useHash: false
    },
    {
        reg: /^\/dist\/(.*)/i,
        url: '/off/dist/$1'
    }
]);
