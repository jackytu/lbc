package console.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import console.entity.app.App;
import console.service.AppService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/dispatcher-servlet.xml" })
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class AppServiceImplTest {
    @Autowired
    private AppService appService;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testQueryAppById() {
        App app = new App("test-1111", 1, 1, "", "jpaas-rd@baidu.com", "java", "bjf");
        appService.insertApp(app);
        App app2 = appService.getAppById(app.getId());
        assertEquals(app, app2);
    }

    @Test
    public void testGetAppByName() {
        App app = new App("test-1111", 1, 1, "", "jpaas-rd@baidu.com", "java", "bjf");
        appService.insertApp(app);
        App app2 = appService.getAppByName("test-1111");
        assertEquals(app, app2);
    }

    @Test
    public void testGetAllApps() {
        List<App> apps = appService.getAllApps();
        assertTrue(apps.size() > 0);
    }

    @Test
    public void testUpdateApp() {
        App app = new App("test-1111", 1, 1, "", "jpaas-rd@baidu.com", "java", "bjf");
        appService.insertApp(app);
        App app2 = appService.getAppByName("test-1111");
        app2.setLanguage("C");
        appService.updateApp(app2);
        App app3 = appService.getAppByName("test-1111");
        assertTrue(app3.getLanguage().equals("C"));
    }

    @Test
    public void testDeleteApp() {
        App app = new App("test-1111", 1, 1, "", "jpaas-rd@baidu.com", "java", "bjf");
        appService.insertApp(app);
        App app2 = appService.getAppById(app.getId());
        assertEquals(app, app2);
        appService.deleteApp(app.getId());
        App app3 = appService.getAppById(app.getId());
        assertEquals(null, app3);
    }

    @Test
    public void testGetAppMonitorById() {
    }

    @Test
    public void testSearchApp() {
    }

}
