package console.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import console.entity.Space;
import console.entity.User;
import console.service.SpaceService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/dispatcher-servlet.xml" })
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class SpaceServiceImplTest {
    @Autowired
    private SpaceService spaceService;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testQuerySpaceById() {
        Space space = new Space("testspace-111", 1);
        spaceService.addSpace(space);
        Space space2 = spaceService.querySpaceById(space.getId());
        assertEquals(space, space2);
    }

    @Test
    public void testAddSpaceOPUser() {
        Space space = new Space("testspace-111", 1);
        spaceService.addSpace(space);
        spaceService.addSpaceOPUser(space.getId(), "wuwei03@baidu.com");
        List<User> users = spaceService.getSpaceOPs(space.getId());
        assertTrue(users.contains(new User("wuwei03@baidu.com")));
    }

}
