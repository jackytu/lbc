package console.service.impl;

import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import console.entity.Org;
import console.entity.Space;
import console.entity.User;
import console.service.OrgService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "file:src/main/webapp/WEB-INF/dispatcher-servlet.xml" })
@TransactionConfiguration(defaultRollback = true)
@Transactional
public class OrgServiceImplTest {
    @Autowired
    private OrgService orgService;

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testQueryOrgById() {
        Org org = orgService.queryOrgById(1);
        assertNotNull(org);
    }

    @Test
    public void testGetAllOrgs() {
        List<Org> orgs = orgService.getAllOrgs();
        assertNotEquals(0, orgs.size());
    }

    @Test
    public void testGetOrgSpaces() {
        List<Space> spaces = orgService.getOrgSpaces(1);
        assertNotEquals(0, spaces.size());
    }

    @Test
    public void testGetOrgUsers() {
        List<User> users = orgService.getOrgUsers(1);
        assertNotEquals(0, users.size());
    }

}
