﻿/**
 * $
 jquery 补充函数
 * add by zzx
 */
define(function(require, exports, module) {
	var $ = require("jquery");
	$.extend($, {
		/**
		 * @description 判断变量是否存在,或者是否以某种类型存在
		 * @param {object} o  判断变量是否存在
		 * @param {object} type 数据类型  Number,Boolean等
		 * @return {Boolean} nResult 返回结果 true或者false
		 */
		exists : function(o, type) {
		    return o != undefined && o !== null && (type ? o.constructor == type : true);
		},
		/**
		 * @description 把字符串自动转换成它原来的类型
		 * @param val o  任意对象
		 * @return val any 
		 */
		parseAny : function(val){			
			if(typeof val =='string'){
				if(val!="" && !isNaN(val)){
					val = val-0;
				}
				else if(val.toLowerCase()=="true"){
					val = true;
				}
				else if(val.toLowerCase()=="false"){
					val = false;
				}
			}
			return val;
		},
		/**
		 * @description 提交数据,$.ajax的扩展 参数可以使用 xxx?a={a}&b={b}
		 * @param val o  任意对象
		 * @return val any 
		 */
		submitData:function(opt){
			if(!opt.url){
				return;
			}			
			if(opt.data){
				var reg;
				for(var i in opt.data){
					if(opt.data.hasOwnProperty(i)){
						reg = eval("/{"+i+"}/");
						opt.url = opt.url.replace(reg, opt.data[i]);
					}
				}
				opt.data = {};
			}
			if(!opt.error){
				//发生错误
				opt.error = function(e){
					console.log("服务器异常!");
					console.log(e);
				}
			}
			$.ajax(opt);
		},
		/**
		 * @description 转换成日期对象
		 * @param val string|number  yyyy-mm-dd
		 * @return Date  object
		 */
		toDate:function(str){
			var _str;
			_str = typeof str === "string" ? str.replace(/-/g,"/") : str;
			return new Date(_str);
		},
		/**
		 * @description 设置localstorage
		 * @param key [string]
		 * @param val [any]
         * @param time [number|string] 毫秒  		 
		 * @return null
		 */
		setLocalStorage:function(key, val, time){
			if(!key){
				return;
			}
			//var _val = Object.prototype.toString.call(val) === "[object Object]" ? JSON.stringify(val) : val;
			_val = {};
			_val.__time = time || new Date().getTime();
			_val.data = val;
			localStorage[key] = encodeURIComponent(JSON.stringify(_val));
		},
		/**
		 * @description 获取localstorage
		 * @param key [string] 		 
		 * @return [object]
		 */
		getLocalStorage:function(key){
			var data = localStorage[key];
			if(!data){
				return null;
			}
			return Object.prototype.toString.call(data) === "[object Object]" ? data : JSON.parse(decodeURIComponent(data))
		},
		clearLocalStorage:function(){
			localStorage.clear();
		},
		/**
		 * @description 获取两个时间点的差,结束时间默认为当前时间
		 * @param start [string|number] 毫秒 
		 * @param end [string|number] 毫秒  		 
		 * @return [number] 毫秒
		 */
		getDelay:function(start, end){
			if(!start){
				return "";
			}
			end = end || new Date().getTime();
			return parseInt(end) - parseInt(start);
		}
	});
	
    
})