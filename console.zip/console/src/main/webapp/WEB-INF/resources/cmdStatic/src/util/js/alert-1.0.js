﻿/**
 * $.myUtil.alert.js
 * add by zzx
 */
define(function(require, exports, module) {
var $ = require("jquery");
	var Alert = function(opts){
		var _opts = {
			cls:'alertPanel  alert-danger',
			hasCloseBtn:true,
			autoClose:true,
			delay:10000,
			closeTmpl : '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>',
			msg:'',
			title:'',
			parent:$("body")
		};
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	Alert.prototype = {
		init:function(){
			var _opts = this.opts;
			var closeTmpl;
			if( _opts.hasCloseBtn){
				closeTmpl = _opts.closeTmpl;
				_opts.cls += ' alert alert-dismissable';
			}else{
				closeTmpl = '';
				_opts.cls += 'alert';
			}
			this.alertObj = document.createElement("div");
			this.alertObj.className = _opts.cls;
			this.alertObj.innerHTML = closeTmpl+'<strong>'+_opts.title+'</strong>'+_opts.msg;
			_opts.parent.css("position","relative");
			_opts.parent.append(this.alertObj);
			this.addEvent();
			this.show();
		},
		addEvent:function(){
			var _opts = this.opts;
			var _this = this;
			var timer = null;
			$(this.alertObj).find(".close").bind("click", function(){
				_this.close();
			});
			//自动关闭
			if(_opts.autoClose){
				timer = setTimeout(function(){
					_this.close();
				}, _opts.delay)
			}
		},
		show:function(){
			$(this.alertObj).show();
		},
		close:function(){
			$(this.alertObj).remove();
		}
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.alert = function(opts){
		return new Alert(opts);
	}
})