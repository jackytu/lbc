﻿/**
* opData 运营数据业务逻辑
*@Require jQuery
*/
define(function(require, exports, module) {
	var $ = require("jquery");
			require("tmpl");
			require("bootstrap-3.0");
			require("highCharts");
			require("util/timeSearch-1.0");

		var hosts = 'http://10.50.33.23';
		var Actions = {
			//APP数目
			appnum:hosts+':8099/podata/appnum',
			//WEB集群流量
			webflow:hosts+':8099/podata/webflow',
			//C集群流量
			backendflow:hosts+':8099/podata/backendflow',
			//可用性
			sla:hosts+':8099/podata/sla',
			//上线次数
			dpnum:hosts+':8099/podata/dpnum',
			//上线时间
			dptime:hosts+':8099/podata/dptime',
			//用户数量
			prodnum:hosts+':8099/podata/prodnum',
			//cpuinfo
			cpuinfo:hosts+':8099/podata/cpu/info',
			//keydatainfo
			keydatainfo:hosts+':8099/podata/keydata/info'
		};
		var params;
		var chart;
		var localData = {};
		var localHash = {};
		var zeroCode = 0;
		//显示个数
		var COUNT = 7;	
		//语言包
		var lang = {
			appnum:{
				name:"app数目",
				unit:"个"
			},
			webflow:{
				name:"web集群流量",
				unit:"万"
			},
			backendflow:{
				name:"c集群流量",
				unit:"亿"
			},
			sla:{
				name:"可用性",
				unit:"%"
			},
			dpnum:{
				name:"上线次数",
				unit:"次"
			},
			dptime:{
				name:"上线时间",
				unit:"分"
			},
			prodnum:{
				name:"用户数量",
				unit:"人"
			}
		}
		var btn = $("#refreushChart");
		function createChart(opts){
			var _opts = {
				title:{
					text:"JPaaS运营数据趋势图",
					x:-20
				},
				chart:{
					type:"spline"
				},
				//描点设置
				plotOptions:{
					spline:{
						lineWidth:2,
						states:{
							hover:{lineWidth:3}
						},
						marker:{
							enabled:false
						},
						point:{
							events:{
								//添加辅助线
								mouseOver:function(res){
									chart.xAxis[0].removePlotLine('plot-line-1');
									chart.xAxis[0].addPlotLine({
										value: this.x,
										color: '#ddd',
										width: 2,
										id: 'plot-line-1'
									})
								},
								mouseOut:function(){
									chart.xAxis[0].removePlotLine('plot-line-1');
								}
							}
						}
					}
				},
				//x轴
				xAxis:{
					categories:[],
					labels:{
						step:1
					},
					tick:{
						tickInterval:2
					}
				},
				//Y轴
				yAxis:{
					title:{
						text:"变化率 (%)"
					},
					plotLines:[{value:0,width:1,color:"#808080"}],
					labels: {
						formatter:function(){
							return this.value+"%";
						}
					}
				},
				//tips
				tooltip:{
					valueSuffix:"%",
					useHTML:true,
					//格式化tips
					formatter:function(){
						var val = "时间:"+this.key;
						for(var i = 0; i < chart.series.length; i++){
							var eName = chart.series[i].options.enName,
							y = this.y > 0 ? "+"+this.y : this.y,
							name = chart.series[i].name,
							unit = lang[eName] ? lang[eName].unit : "",
							data = localHash[eName] && localHash[eName][this.key]!==null ? localHash[eName][this.key] + unit : "";
							data = data ? "<span>"+data+" ("+y+"%)</span>" : "暂无数据";
							val += "<div style='color:"+chart.series[i].color+"'>"+name+":"+data+"</div>";
						}
						return val
					}
				},
				legend:{layout:"vertical",align:"right",verticalAlign:"middle",borderWidth:1},
				//数据
				series:[]
			}
			$.extend(_opts, opts);
			for(var i = 0; i < _opts.series.length; i++){
				var seriesIndex = _opts.series[i];
				seriesIndex.enName = seriesIndex.name;
				seriesIndex.name = lang[seriesIndex.name] ? lang[seriesIndex.name].name : seriesIndex.name;
				
			}
			$('#container').highcharts(_opts);
			chart = $('#container').highcharts();
		}
		
		function getData(type, data, callback){
			var opt;
				opt = {
					url:Actions[type],
					data:data,
					contentType:"*/*",
					dataType:"jsonp",
					success:function(res){
						callback && callback(res, type);
					}
				}
				$.ajax(opt);
		}
		function precentChange(res, inited){
			if(!inited){
				zeroCode = res;
				return 0;
			}else{
				if(res == 0){
					return 0;
				}
				return (res === null || res === "") ? null : ((res - zeroCode)/zeroCode*100).toFixed(2);
			}
		}
		function parseData(resObject){
			var _type;
			var _series = [];
			for(var type in resObject){
				if(!resObject.hasOwnProperty(type)){
					return;
				}	
				if(!_type){
					_type = type;
				}
				var res = resObject[type];
				var _res = null;
				localData[type] = {
					title:[],
					val:[]
				};	
				for(var i in res){
					if(res.hasOwnProperty(i) && res[i]!==null){
						if(!_res){
							if(res[i] != 0){
								_res = {};
								_res[i] = precentChange(res[i], false);
							}else{
								_res = {};
								_res[i] = precentChange(1, false);
							}
						}else{
							_res[i] = precentChange(res[i], true);
						}
						localData[type].title.push(i);
						localData[type].val.push((_res[i]!==null && res[i]!=="") ? parseFloat(_res[i]) : null);
					}else{
						localData[type].title.push(i);
						localData[type].val.push(null);
					}
				}
				if(localData[type].title.length > localData[_type].title.length){
					_type = type;
				}
				_series.push({
					name:type,
					data:localData[type].val
				})
				localHash[type] = res;
			}
			var opts = {
				xAxis:{
					categories:localData[_type].title,
					labels:{
						step:1
					},
					tickInterval:Math.round(localData[_type].val.length/COUNT)
				},
				series:_series
			}
			createChart(opts);
		}
		
		function getDatas(_param, callback){
			var data = {
				time:_param.start + "..." + _param.end
			}
			var arr = _param.type.split(",");
			var resObject = {};
			var count = 0;
			for(var i = 0; i < arr.length;i++){
				getData(arr[i], data, function(res, type){	
					count++;
					resObject[type] = res;
					if(count >= arr.length){
						callback ? callback(resObject) : parseData(resObject);
					}
				});
			}
		}
		//格式化为20130102格式
		function dataFormat(str){
			if(/^\d{4}-\d{2}-\d{2}$/.test(str)){
				return str.split("-").join("");
			}
			var arr = str.split("-");
			for(var i = 0; i < arr.length; i++){
				if(arr[i].length < 2){
					arr[i] = '0' + arr[i];
				}
			}
			return arr.join("");
		}
		function init(){
			
			$(".jpaasOpdata").bind("scroll",function(){
				var panelObj = $(this).find(".panel-body");
				if($(this).find(".panel").offset().top < 52){
					panelObj.addClass("addFixed");
				}else{
					panelObj.removeClass("addFixed");
				}
			})
			var searchBar = $.myUtil.searchBar({
				box:$(".reportSearchBox"),
				insertMethod:"prepend",
				tmplData:{
					defaultVal:'month',
					wdatePicker:{
						start:"{maxDate:'%y-%M-{%d-1}'}",
						end:"{maxDate:'%y-%M-{%d-1}'}"
					},
					optsData:[
						{val:"week", text:"最近7天"},
						{val:"month", text:"最近30天"},
						{val:"sea", text:"最近一季度"},
						{val:"year", text:"最近一年"}
					]
				}
			});
			initTable();
			initpic();
			btn.bind("click", function(){
				initTable();
				initpic();
				
			})
			$(".typeCheckList input").bind("change",function(){
				initpic();
			});
			function initTable(){
				params = searchBar.getFormData($(".reportSearchBox"));
				searchBar.compareDate(params);
				params.start = dataFormat(params.start);
				params.end = dataFormat(params.end);
				params.type = "cpuinfo,keydatainfo";
				getDatas(params, function(res){
					$("#dataInfoBox").html($.tmpl($("#TmplKeydataInfo").val(),{res:res.keydatainfo}));
					var online = [];
					var offline = [];
					var mixline = [];
                    var selfline = [];
					var other = [];
					for(var i = 0; i < res.cpuinfo.length; i++){
						var cur = res.cpuinfo[i];
						if(cur.type === "online"){
							online.push(cur);
						}else if(cur.type === "offline"){
							offline.push(cur);
						}else if(cur.type === "mixline"){
							mixline.push(cur);
						}else if(cur.type === "selfline"){
                            selfline.push(cur);
                        }else{
							other.push(cur);
						}
					}
					$("#cpuInfoBox").html($.tmpl($("#TmplCpuInfo").val(),{online:online, offline:offline,mixline:mixline,selfline:selfline,other:other}));
					initNavMenu();
				});
			}
			function initpic(){
				params = searchBar.getFormData($(".reportSearchContent"));
				if(!params.type){
					alert("请至少选择一个类型!");
					return;
				}
				searchBar.compareDate(params);
				getDatas(params);
			}
			function initNavMenu(){
				var fixedNavMenu = $(".fixedNavMenu");
				fixedNavMenu.show();
				fixedNavMenu.find(".tit").unbind("click").bind("click",function(){
					fixedNavMenu.toggleClass("slide");
				    if(fixedNavMenu.hasClass("slide")){
						$(this).find("span").html(">");
					}else{
						$(this).find("span").html("<");
					}
				})
				$(".jpaasOpdata").scrollTop(0);
				fixedNavMenu.find("a").each(function(){
					var href = $(this).attr("href");
					console.log($(href).offset())
					var top = $(href).offset().top - 130;
					$(this).attr("data-offset",top);
				})
				fixedNavMenu.find("a").unbind("click").bind("click",function(){
					var top = $(this).attr("data-offset");
					$(".jpaasOpdata").scrollTop(top);
					return false;
				})
			}
		}
		init();
  });
