﻿seajs.config({
  base: "/site_media/cmdStatic/src/",
  alias: {
    "jquery": "lib/jquery-2.0.3/jquery-2.0.3.min.js",
	//loading 组件
	"util/loading-1.0":"util/js/loading-1.0.js",
	//jquery 扩展库
	"util/jqueryExtends-1.0": "util/js/jqueryExtends-1.0.js",
	//模板
	"tmpl":"lib/tmpl/tmpl.js",
	//bootstrap
	"bootstrap-3.0":"lib/bootstrap/js/bootstrap.min.js",
	//highCharts
	"highCharts":"lib/highCharts/highCharts.js",
	//表单检测
	"util/formCheck-1.0":"util/js/formCheck-1.0.js",
	//alert
	"util/alert-1.0":"util/js/alert-1.0.js",
	//chart
	"util/chart-1.0":"util/js/chart-1.0.js",
	//query
	"util/query-1.0":"util/js/query-1.0.js",
	//按时间搜索组件
	"util/timeSearch-1.0":"util/js/timeSearch-1.0.js",
	//树的组件
	"util/tree-1.0":"util/js/tree-1.0.js",
	//stickUp
	"stickUp":"lib/stickUp/stickUp.min.js"
  }
})