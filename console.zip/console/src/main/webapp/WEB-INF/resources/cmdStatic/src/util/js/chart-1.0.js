﻿/**
 * $.myUtil.chart.js
 * add by zzx
 */
define(function(require, exports, module) {
var $ = require("jquery");
	var tmpl = '<div class="myChartBox">\
		<div>\
			<div class="chartLeft chart-side"></div>\
			<div class="chartRight chart-main"></div>\
		</div>\
		<div>\
			<div class="chartLeft"></div>\
			<div class="chartRight chart-bottom"></div>\
		</div>\
	</div>';
	//loading 类
	var Chart = function(opts){
		var _opts = {
			box:$("body"),
			//效果
			effect:true,
			tmpl:tmpl,
			//方向 0 横向 1 纵向
			direction:1,
			endNum:100,
			count:[0,10,20,30,40,50,60,70,80,90],
			startNum:0,
			data:[]
		};
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	
	Chart.prototype = {
		init:function(){
			var _opts = this.opts;
			var title;
			var num;
			_opts.box.append(_opts.tmpl);
			var all = _opts.direction ? _opts.box.find(".chart-main").height() : _opts.box.find(".chart-main").width();
			this.createNum(all);
			for(var i = 0; i < _opts.data.length; i++){
				for(var j in _opts.data[i]){
					if(_opts.data[i].hasOwnProperty(j)){
						title = j;
						num = all - (parseFloat(_opts.data[i][j]) - _opts.startNum) / (_opts.endNum - _opts.startNum) * parseFloat(all);
						this.createItem(title, num);
					}
				}
			}
		},
		createNum:function(all){
			var _opts = this.opts;
			var _px = all / _opts.count.length;
			var tmpl = '';
			for(var i = _opts.count.length - 1; i >= 0 ; i--){
				tmpl = '<div class="chart-list" style="height:'+_px+'px;"><span>'+_opts.count[i]+'</span></div>';				
				if(_opts.direction){
					_opts.box.find(".chart-side").append(tmpl);
				}else{
					_opts.box.find(".chart-bottom").append(tmpl);
				}
			}
		},
		createItem:function(title, num){
			var _opts = this.opts;
			var titleTmpl = '<div class="chart-item">'+title+'</div>';
			if(_opts.direction){
				var tmpl = '<div class="chart-item"><div style="top:'+num+'px" class="num"></div></div>';
				_opts.box.find(".chart-bottom").append(titleTmpl);
			}else{
				var tmpl = '<div class="chart-item chart-itemdir"><div style="right:'+num+'px" class="num"></div></div>';
				_opts.box.find(".chart-side").append(titleTmpl);
			}
			_opts.box.find(".chart-main").append(tmpl);
		}
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.chart = function(opts){
		return new Chart(opts);
	}
})