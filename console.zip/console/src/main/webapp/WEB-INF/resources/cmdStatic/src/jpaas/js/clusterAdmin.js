﻿/**
* cluster_admin 多集群管理页面业务逻辑
*@Require jQuery
*/
define(function(require, exports, module) { 
	var $ = require('jquery');
			require('tmpl');
			require('bootstrap-3.0');
			require('util/loading-1.0');
			require('util/jqueryExtends-1.0');
			require('util/formCheck-1.0');
			require('util/alert-1.0');
			
	var Hosts = '';
	var Actions = {
		//获取集群信息
		getClusters:'/xplatfe/api2/get_clusters/',
		//查询单个集群信息
		getCluster:'xplatfe/api2/get_cluster?cluster_id={clusterId}',
		//搜索集群信息
		searchCluster:'/xplatfe/api2/search_cluster?cluster_name={clusterName}',
		//新增集群
		addCluster:'/xplatfe/api2/add_cluster?name={name}&target={target}&idc={idc}&shortname={shortname}&pushmanage={pushmanage}',
		//删除集群
		deleteCluster:'/xplatfe/api2/delete_cluster?cluster_id={clusterId}',
		//更新集群
		updateCluster:'/xplatfe/api2/update_cluster?cluster_id={clusterId}&name={name}&target={target}&idc={idc}&shortname={shortname}&pushmanage={pushmanage}'
	}
	var congfig = {
		telecoms:{
			cu:"中国联通",
			ct:"中国电信",
			cm:"中国移动",
		},
		region:{
			bj:"北京",
			hz:"杭州",
			nm:"内蒙"
		}
	}
    var idcs = [
        {
            name:"tc"
        },
        {
            name:"jx"
        },
        {
            name:"cq01"
        },
        {
            name:"m1"
        },
        {
            name:"st01"
        },
        {
            name:"db"
        },
        {
            name:"yf"
        },
        {
            name:"cq02"
        },
        {
            name:"nj02"
        },
        {
            name:"hz01"
        },
        {
            name:"hk01"
        },
        {
            name:"sh01"
        },
        {
            name:"cp01"
        }
    ]
	//本地缓存数据
	var localData;
	var content = $("#clusterAdmin"); 
	var $clusterPanel = $("#clusterPanel");
	var clusterAdminController = {
		//初始化方法
		init:function(){
			var loading = $.myUtil.loading({
				parent:$clusterPanel
			});
			this.refreushPanel(loading);
			this.addEvent();
		},
		//更新panel
		refreushPanel:function(loading){
			var _this = this;
			this.getClusters(function(_res){
				loading && loading.hide();
				_this.renderClusters(_res);
			});
		},
		addEvent:function(){
			var _this = this;
			//创建一个模态框
			$("#btnCreateCluster").bind("click", function(){	
				_this.showModal($.tmpl($("#TmplBase").val(),{me:{btnType:"add"}}));
                var data = {
                    allIdcs : idcs
                };
				$("#addCluster").html($.tmpl($("#TmpladdCluster").val(),{me:data}));
			});
			content.delegate("#btnUpdateCluster","click", function(){
				_this.updateCluster($("#addCluster"), $(this).attr("data-id"));
			})
			content.delegate("#btnAddCluster", "click", function(){
				_this.createCluster($("#addCluster"));
			});
			//删除集群
			content.delegate(".deleteCluster", "click", function(){  
                var cf = window.confirm("确定要删除该集群吗?");
                if(!cf){
                    return;
                }
				var clusterId = $(this).attr("data-clusterId");
				var loading = $.myUtil.loading({
					parent:$('#myModal-content')
				});
				_this.deleteCluster(clusterId, function(code, msg){
					if(msg){
						$.myUtil.alert({
							parent:$clusterPanel,
							msg:msg
						})	
						return;
					}
					_this.refreushPanel(loading);
				})
			});
			content.delegate(".updateCluster", "click", function(){
				var clusterId = $(this).attr("data-clusterId");
				_this.showModal( $.tmpl($("#TmplBase").val(),{me:{btnType:"update",clusterId:clusterId}}));
                var data = {
                    allIdcs : idcs
                }
                for(var i = 0; i < localData.length; i++){
                    if(localData[i].id == clusterId){
                        $.extend(data, localData[i]);
                        break;
                    }
                }
                $("#addCluster").html($.tmpl($("#TmpladdCluster").val(),{me:data}));
			})
		},
		//修改集群信息
		updateCluster:function(obj, id){
			var _this = this; 
			var data = this.getFormData(obj, "[data-doAjax='true']");
			if(!data || !id){
				return;
			}
			data.clusterId = id;
			var loading = $.myUtil.loading({
				parent:$('#myModal-content')
			});
			//创建RAW
			$.submitData({
				data:data,
				url:Actions.updateCluster,
				success:function(res){
					loading.hide();
					_this.parseData(res, function(_res){
						var loading = $.myUtil.loading({
							parent:$clusterPanel
						});
						_this.refreushPanel(loading);
						_this.hideModeal();
					},function(_res, code, msg){
						$.myUtil.alert({
							parent:$clusterPanel,
							msg:msg
						});
					});
				}
			})
		},
		//删除集群
		deleteCluster:function(clusterId, callback){
			var _this = this;
			$.submitData({
				url:Actions.deleteCluster,
				data:{
					clusterId:clusterId
				},
				success:function(res){
					_this.parseData(res, function(_res){
						callback && callback();
					},function(_res, code, msg){
						callback && callback(code, msg);
					});
				}
			})	
		},
		//输出cluster列表
		renderClusters:function(data){
			var _data = {
				me:data,
				telecoms:congfig.telecoms,
				region:congfig.region
			}
			localData = data;

			$clusterPanel.html($.tmpl($("#TmplClusterList").val(), _data));
		},
		//创建cluster
		createCluster:function(obj){
			var _this = this; 
			var data = this.getFormData(obj, "[data-doAjax='true']");
            console.log(data)
			if(!data){
				return;
			}
			var loading = $.myUtil.loading({
				parent:$('#myModal-content')
			});
			//创建RAW
			$.submitData({
				data:data,
				url:Actions.addCluster,
				success:function(res){
					loading.hide();
					_this.parseData(res, function(_res){
						var loading = $.myUtil.loading({
							parent:$clusterPanel
						});
						_this.refreushPanel(loading);
						_this.hideModeal();
					},function(_res, code, msg){
						$.myUtil.alert({
							parent:$clusterPanel,
							msg:msg
						});
					});
				}
			})
		},
		//获取集群信息
		getClusters:function(callback){
			var _this = this;
			$.submitData({
				url:Actions.getClusters,
				success:function(res){
					_this.parseData(res, function(_res){
						callback && callback(_res);
					},function(_res, code, msg){
						console.log(msg);
						//TODO
					});
				}
			})
		},
		/**************************************************/
		//解析data,处理异常
		parseData:function(res, success, error){
			console.log(res);
			var _res, code, msg;
			if(!res){
				code = 404;
				msg = "data is not found";
			}else{
				try{
					_res = typeof res==="string" ? JSON.parse(res) : res;
					if(_res){
						code = 200;
						msg = "success";
					}else{
						code = 404;
						msg = "data is not found";
						//todo
					}
				}catch(e){
					code = 500;
					msg = "data parse error";
				}
			}
			//TODO..		
			if(!res){
				error && error(_res, code, msg);
			}else{
				success && success(_res);
			}
		},
		showModal:function(html, cls){
			cls = cls || "";
			var _cls = cls+" modal-dialog";
			$("#myModal-Box").attr("class",_cls);
			$("#myModal-content").html(html);
			$('#myModal').modal();
		},
		hideModeal:function(){
			$('#myModal').modal("hide");
		},
		//获取form的数据
		getFormData:function(parent, type){
			return $.myUtil.formCheck(parent, type, function(input, msg, _parent){
				var msgObj = _parent.find(".help-block[data-formName='"+input.attr("name")+"']");				
				if(msg){
					if(!msgObj.attr("data-def")){
						msgObj.attr("data-def",msgObj.html());
					}
					input.parent().addClass("has-error");
					msgObj.show().html(msg).addClass("red");
				}else{
					var def = msgObj.attr("data-def");
					input.parent().removeClass("has-error");
					if(def){
						msgObj.html(def).removeClass("red");
					}else{
						msgObj.removeClass("red");
					}
				}
			})
		}
	}
	clusterAdminController.init();
})