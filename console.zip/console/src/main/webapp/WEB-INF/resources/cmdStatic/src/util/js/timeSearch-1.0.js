﻿/**
 *@Require WdatePicker.js
 *@Require jQuery.js
 *@Require Tmpl.js
 *@Require common.js
 *按时间搜索 搜索条
 *@Return $.myUtil.searchBar.js
 * add by zzx
 */
define(function(require, exports, module) {
	var $ = require('jquery');
			require('tmpl');
			require('util/jqueryExtends-1.0');
			require('util/formCheck-1.0');
	var tmpl = '<div class="searchContent">\
		  时间:&nbsp;&nbsp;\
		  <div class="form-group">\
			<select value="<%=defaultVal%>" name="dateType" class="form-control changeTimeSel">\
			  <%for(var i=0; i < optsData.length; i++){ var selected = optsData[i].val == defaultVal ? "selected=true":"";%>\
			  <option <%=selected%> value="<%=optsData[i].val%>"><%=optsData[i].text%></option>\
			  <%}%>\
			</select>\
		  </div>\
		  <div class="form-group">\
			<input name="start" data-doAjax="true" type="text" onclick="WdatePicker(<%=wdatePicker.start%>)" class="form-control startTime" placeholder="yyyy-mm-dd">\
		  </div>\
		  至\
		  <div class="form-group">\
			<input name="end" data-doAjax="true" type="text" onclick="WdatePicker(<%=wdatePicker.end%>)" class="form-control endTime" placeholder="yyyy-mm-dd">\
		  </div>\
		</div>';
	var SearchBar = function(opts){
		var _opts = {
			//模板
			tmpl:tmpl,
			//插入方式
			insertMethod:"html",
			//模板数据
			tmplData:{
				defaultVal:'week',
				wdatePicker:{
					start:"{maxDate:'%y-%M-{%d-1}'}",
					end:"{maxDate:'%y-%M-{%d-1}'}"
				},
				optsData:[
					{val:"week", text:"最近7天"},
					{val:"month", text:"最近30天"},
					{val:"sea", text:"最近一季度"},
					{val:"year", text:"最近一年"}
				]
			},
			//输出的数据格式
			params:{
				start: "2012-01-01", 
				end: new Date().getTime() - 1000 * 60 * 60 * 24
			},
			box:$("body")
		};
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	
	SearchBar.prototype = {
		init:function(){
			var _opts = this.opts;
			_opts.box[_opts.insertMethod]($.tmpl(_opts.tmpl, _opts.tmplData));
			this.changeTimeSel = _opts.box.find(".changeTimeSel");
			this.startTimeEl =  _opts.box.find(".startTime");
			this.endTimeEl = _opts.box.find(".endTime");
			this.renderDate(this.changeTimeSel.val());
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			this.changeTimeSel.bind("change",function(){
				_this.renderDate($(this).val());
			});
		},
		//输出日期
		renderDate:function(val){
			var _opts = this.opts;
			var now = /^\d{4}-[01][012]-[0123]\d$/.test(_opts.params.end) ? $.toDate(_opts.params.end).getTime() : _opts.params.end;
			var _seaSetting = [1,3,6,9];
			var _sea = $.toDate(now).getMonth() + 1;
			var days = 1000 * 60 * 60 * 24;
			var timeConfig = {
				week: this.dateChange(now - days * 7),
				month:this.dateChange(now - days * 30),
				sea:this.dateChange(now - days * 91),
				year:this.dateChange(now - days * 365)
				//sea:this.dateChange(now,"-","01","0"+_seaSetting[Math.ceil(_sea/3)-1]),
				//year:this.dateChange(now,"-","01","01",$.toDate(now).getFullYear())
			}
			this.startTimeEl.val(timeConfig[val]);
			this.endTimeEl.val(this.dateChange(now));
		},
		//收集表单数据
		getFormData:function(parent, type){
			parent = parent || this.opts.box;
			type = type || "[data-doAjax='true']";
			return $.myUtil.formCheck(parent, type, function(input, msg, _parent){
				//todo
			})
		},
		//日期类型转换
		dateChange:function(str, spl, day, month, year){
			spl = spl || "-";
			str = typeof str === "string" ? str.replace("-","/") : str;
			var date = $.toDate(str);
			var year = year || date.getFullYear();
			var mouth = month || date.getMonth() + 1;
			var day = day || date.getDate();
			return year + spl + mouth + spl + day;
		},
		//比较
		compareDate:function(_param){
			var start = $.toDate(_param.start).getTime();
			var end = $.toDate(_param.end).getTime();
			var other;
			if(start > end){
				other = _param.start;
				_param.start = _param.end;
				_param.end = other;
				this.startTimeEl.val(this.dateChange(_param.start));
				this.endTimeEl.val(this.dateChange(_param.end));
			}
		}
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.searchBar = function(opts){
		return new SearchBar(opts);
	}
})