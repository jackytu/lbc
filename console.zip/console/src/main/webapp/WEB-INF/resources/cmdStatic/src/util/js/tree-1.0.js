﻿/**
 *@Require jQuery.js
 *@Require Tmpl.js
 *@Require common.js
 *@Require loading.js
 *树的逻辑
 *@Return $.myUtil.tree.js
 * add by zzx
 */
define(function(require, exports, module) {
	var $ = require('jquery');
			require('tmpl');
			require('util/jqueryExtends-1.0');
			require('util/loading-1.0'); 
	var HOSTS = "";
	var Actions = {
		getUser:HOSTS + "/xplatfe/api/get_user?user_name={user_name}",
		//获取orgs
		get_orgs_by_user:HOSTS+"/xplatfe/api/get_orgs_by_user?user_name={user_name}@baidu.com"
	}
	var templete = {
		baseMenu:'\
				<select id="productSelect" class="form-control selectPro">\
					<%for(var i=0;i<me._orgs.length;i++){var _me = me._orgs[i];\
					var _select = _me.id === me.currentApp.org ? "selected=\'selected\'":"";\
					if(_me.id === 1)continue;\
					%>\
					<option <%=_select%> value="<%=_me.id%>"><%=_me.cn_name%></option>\
					<%}%>\
				</select>\
				<div class="menuList">\
				</div>\
		',
		tree:'<%for(var i = 0; i <me._orgs.length;i++){var _me = me._orgs[i];if(_me.id === 1)continue;%>\
				<%if(_me.id == me.currentApp.org){%>\
					<%for(var j = 0; j < _me.spaces.length; j++){var _spaces = _me.spaces[j];var appType = _spaces.version == 2 ? "xplat":"jpaas";_action = _spaces.version == 2 ? "#a=baseInfo":"";%>\
					<div class="listBox">\
						<div class="listTitle"><%=_spaces.name%><span class="myIcon myIcon_down"></span></div>\
						<div class="listLink">\
							<%for(var k = 0; k < _spaces.apps.length; k++){var _app = _spaces.apps[k];var cls = _app.id === me.currentApp.id ? "current" : "";%>\
								<a href="?app_id=<%=_app.id%>&app_type=<%=appType%>&org=<%=_app.org%>&space=<%=_app.space%><%=_action%>" class="<%=cls%>" data-id="<%=_app.id%>" data-org="<%=_app.org%>" data-name="<%=_app.name%>" data-space="<%=_app.space%>" ><%=_app.name%></a>\
							<%}%>\
						</div>\
					</div>\
		<%}break;}}%>',
		empty:'<div style="margin:20px auto;color:#fff;">没有可用的App</div><a href="/xplatfe/users/setting" class="btn btn-primary" >申请权限</a>',
		demo:'\
			<select id="productSelect" class="form-control selectPro">\
				<option selected="selected">微购</option>\
			</select>\
			<div class="menuList">\
				<div class="listBox">\
					<div class="listTitle">api<span class="myIcon myIcon_down"></span></div>\
						<div class="listLink"><%var cls = me ? "current":"";%>\
							<a href="/xplatfe/app/app_detail?app_id=26&app_type=jpaas&org=8888&space=15" class="<%=cls%>" >picapi</a>\
						</div>\
					</div>\
				</div>\
			</div>\
		'
	}
	var Tree = function(opts){
		var _opts = {
			user_name:null,
			dep:null,
			cached:1,
			content:$(".layout-menu"),
			templete:templete,
			//缓存过期时间
			saveTime:1000*60*2,
			//本地缓存key
			localKey:"MENU",
			//当前的app
			currentApp:null
		}
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	var loading;
	Tree.prototype = {
		init:function(){
			var _opts = this.opts;
			var _this = this;
			loading = $.myUtil.loading({
				parent:_opts.content
			});
			//_opts.user_name = "wuwei03"
			if(_opts.user_name){
				this.getUsers({user_name:_opts.user_name}, function(res){
					loading.hide();
					if(res){
						_this.data = res;
						res.currentApp = null;
						res._orgs = [];
						for(var i = 0; i < res.orgs.length;i++){
							if(res.orgs[i].dep === _opts.dep){
								res._orgs.push(res.orgs[i]);
							}
						}	
						for(var i = 0; i < res.apps.length; i++){
							if(res.apps[i].id == _opts.currentApp){
								res.currentApp = $.extend({}, res.apps[i]);
								break;
							}
						}
						if(!res.currentApp){
							var _space = res._orgs[0] && res._orgs[0].spaces ? res._orgs[0].spaces[0] : null;
							res.currentApp = $.extend({}, _space && _space.apps ? _space.apps[0] : {});
							res.currentApp.id = null;
						}
						if(res._orgs && res._orgs.length > 0){
							_this.render(_opts.templete.baseMenu, res);
							_this.menuBox = _opts.content.find(".menuList");
							_this.render(_opts.templete.tree, res, _this.menuBox);
						}else{
							_this.render(_opts.templete.empty);
						}
						$("#depChange").show();
					}else{
						_this.render(_opts.templete.demo, _opts.currentApp);
					}
					_this.resizeTree();
				})
			}else{
				console.log("user_name不存在!");
			}
			this.addEvent();
		},
		//绑定事件
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			_opts.content.delegate("#productSelect", "change", function(){
				var val = $(this).val();
				var res = _this.data;
				if(res){
					for(var i = 0; i < res.orgs.length; i++){
						if(res.orgs[i].id == val){
							res.currentApp = $.extend({}, res.orgs[i].spaces[0].apps[0]);
							res.currentApp.id = "";
							break;
						}
					}
					_this.render(_opts.templete.tree, res, _this.menuBox);
					_this.resizeTree();
				}
			});
			_opts.content.delegate(".listLink a","click", function(){
				if($(this).hasClass("current")){
					return false;
				}
			});
			_opts.content.delegate(".listTitle","click",function(){
				$(this).next(".listLink").toggle();
				$(this).find(".myIcon").toggleClass("myIcon_down");
				$(this).toggleClass("removeBg");
				_this.resizeTree();
				return false;
			});
			_opts.content.delegate(".listTitle","selectstart",function(){
				return false;
			});
			var timer;
			$(window).bind("resize", function(){
				clearTimeout(timer);
				timer = setTimeout(function(){
					_this.resizeTree();
				},200)
			});
		},
		resizeTree:function(){
			if($(".layout-leftContent").height() > $(".layout-content").height() || $(".layout-content").width() <= 1100){
				$(".layout-leftContent").css("position","relative");
			}else{
				$(".layout-leftContent").css("position","fixed");
			}
		},
		//获取用户信息
		getUsers:function(data, callback){
			var _opts = this.opts;
		 	var localKey = _opts.localKey;
			var time = _opts.saveTime;
			var local = $.getLocalStorage(localKey);
			var _this = this;
			var reqCount = 0;
			var tempData = {};
			var reqArr = [
					{
						type:"get_orgs_by_user",
						actions:Actions.get_orgs_by_user,
					},
					{
						type:"getUser",
						actions:Actions.getUser
					}
				];
			if(!local){
				submitDatas();
			}else{
				//过期或者服务器主动变更 都会去服务器重新拿
				if($.getDelay(local.__time) > time || !_opts.cached){
					submitDatas();
				//未过期就从缓存里面取
				}else{
					callback && callback(local.data);
				}
			}
			function submitData(type, url){
				$.submitData({
					url:url,
					data:data,
					success:function(res){
						_this.parseData(res, function(_res){
							reqCount++;
							tempData[type] = _res;
							if(reqCount >= reqArr.length){
								_res = _parseData();
								var inited = $.getLocalStorage("INITED");
								if(!inited || $.getDelay(inited.__time) >= time){
									$.clearLocalStorage();
									$.setLocalStorage(localKey, _res);//设置缓存数据				
								}
								callback && callback(_res);
							}
						},function(_res){
							console.log(_res);
							callback && callback();
						});
					}
				})
			}
			function submitDatas(){
				for(var i = 0; i < reqArr.length; i++){
					submitData(reqArr[i].type, reqArr[i].actions);
				}
			}
			function _parseData(){
				var apps = [];
				var orgs = tempData["get_orgs_by_user"];
				var spaces = tempData["getUser"].spaces;
				for(var i = 0; i <orgs.length; ){
					if(orgs[i].id === 1){
						orgs.splice(i, 1);
					}else{
						orgs[i].spaces = [];
						for(var j = 0; j < spaces.length;){
							apps = apps.concat(spaces[j].apps);
							if(orgs[i].id == spaces[j].org){
								orgs[i].spaces.push(spaces[j]);
								spaces.splice(j, 1);
							}else{
								j++;
							}
						}
						i++;
					}
				}
				return {orgs:orgs,apps:apps};
			}
		},
		parseData:function(res, success, error){
			if(!res){
				error && error(res);
				return;
			}
			var _res;
			try{			
			     _res = typeof res === "string" ? JSON.parse(res) : res;	
			}catch(e){
				_res = null;
			}
			if(Object.prototype.toString.call(_res) === "[object Array]" && _res.length == 0){
				_res = null;
			}
			if(_res){
				success && success(_res);
			}else{
				error && error(res);
			}
		},
		render:function(tmpl, data, parent, type){
			var _opts = this.opts;
			parent = parent || _opts.content;
			//追加数据
			if(type){
				parent.append($.tmpl(tmpl, {me:data}));
			//替换数据
			}else{
				parent.html($.tmpl(tmpl, {me:data}));
			}
		}
		
	}
	$.myUtil = $.myUtil || {};
	$.myUtil.tree = function(opts){
		return new Tree(opts);
	}
})