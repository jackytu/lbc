﻿(function($, win, undeined){
/***********************************************************************************进程监控****************/
	var InsnumMinitor = function(opts){
		this.init(opts);
	}
	InsnumMinitor.prototype = {
		init:function(opts){
			console.log("insnum init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			//添加
			_opts.panelBox.delegate(".btn_add_insnum_monitor","click",function(){
				renderAddInsnumMonitor(_opts.panelBox,{clusters:_opts.clusterName});
			})
            //取消
			_opts.panelBox.delegate(".btn_render_insnum_list","click",function(){
				_this.render(null);
			})
            //添加
            _opts.panelBox.delegate(".btn_submit_insnum_monitor","click",function(){
                var data = _opts.formIns.getForm($(this));
                if(data){
                    _this.submitMonitor(data);
                }
            })
            //查看
            _opts.panelBox.delegate(".btn_view_insnum_monitor","click", function(){
                var mail = $(this).parents("td").attr("data-mail");
                var sms = $(this).parents("td").attr("data-sms");
                renderAddInsnumMonitor(_opts.panelBox,{clusters:_opts.clusterName,mail:mail,sms:sms,type:"mod"});
            })
            //监控修改
            _opts.panelBox.delegate(".btn_mod_insnum_monitor","click",function(){
                var data = _opts.formIns.getForm($(this));
                if(data){
                    _this.modMonitor(data);
                }
            })
            //监控删除
            _opts.panelBox.delegate(".btn_del_insnum_monitor","click",function(){
                _this.delMonitor();
            })

            //监控生效
            /*
            _opts.panelBox.delegate(".btn_take_insnum_effect","click", function(){
                _this.take_effectMonitor();
            })
			*/
		},
		render:function(panel, params){
			var _this = this;
			this.getMonitor(function(res){
				renderMonitorList(_this.opts.panelBox, res);
			});
		},
		submitMonitor:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey,app_name:this.opts.appName,space:this.opts.spaceName,org:this.opts.orgName},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_insnum_monitor, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
                    _this.render();
				}
			})
		},
        modMonitor:function(data, callback){
            var _data = $.extend({app_key:this.opts.appkey,app_name:this.opts.appName,space:this.opts.spaceName,org:this.opts.orgName},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_insnum_monitor, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
                    _this.render();
				}
			})
        },
		delMonitor:function(callback){
            var _this = this;
			this.opts.doAjax(this.opts.actions.del_insnum_monitor, {app_key:this.opts.appkey,app_name:this.opts.appName,space:this.opts.spaceName,org:this.opts.orgName}, function(res){
				if(callback){
					callback(res);
				}else{
                    _this.render();
				}
			})
        },
		
		getMonitor:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_insnum_monitor, {app_key:this.opts.appkey,app_name:this.opts.appName,space:this.opts.spaceName,org:this.opts.orgName}, function(res){
				if(callback){
					callback(res);
				}else{
					renderMonitorList(_this.opts.panelBox, res);
				}
			},true)
		},
		/*
        take_effectMonitor:function(callback){
            var _this = this;
			this.opts.doAjax(this.opts.actions.tef_insnum_monitor, {}, function(res){
                if(res && res.rescode == 0 ){
                    alert("监控已生效");
                }else{
                    alert("监控生效失败！");
                }
			},true)
        }*/
		
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderMonitorList(box, data){
		box.html($.tmpl($("#tmpl_insnum_monitorList").val(),{me:data}));
	}
	//添加监控
	function renderAddInsnumMonitor(box, data){
		data = data || {};
		box.html($.tmpl($("#tmpl_addInsnumMonitor").val(),{me:data}));
	}
	
	$.myMonitor = $.myMonitor || {};
	$.myMonitor.InsnumMinitor = InsnumMinitor;
 }(jQuery));
