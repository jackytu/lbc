﻿/**
 * $.myUtil.loading.js
 * add by zzx
 */
(function($, win, undefined){
	//loading 类
	var Loading = function(opts){
		var _opts = {
			parent:$("body"),
			cls:"loadingPanel",
            parentPosition:"relative",
			html:'<img src="/img/loading2.gif" />',
			//初始化的时候就显示
			initShow:true
		};
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
		_opts.initShow && this.show();
	}
	Loading.prototype = {
		init:function(){
			var _opts = this.opts;
			var _loading = _opts.parent.children("."+_opts.cls)[0];
			if(_loading){
				this.loading = _loading;
			}else{
				this.loading = document.createElement("div");
				this.loading.className = _opts.cls;
				this.loading.innerHTML = _opts.html;
				_opts.parent.css("position",_opts.parentPosition);
				_opts.parent.append(this.loading);
			}
		},
		show:function(){
			$(this.loading).show();
		},
		hide:function(){
			$(this.loading).hide();
		}
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.loading = function(opts){
		return new Loading(opts);
	}
}($, window))
