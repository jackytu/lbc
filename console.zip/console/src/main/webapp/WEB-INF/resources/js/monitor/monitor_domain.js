﻿(function($, win, undeined){
/***********************************************************************************进程监控****************/
	var DomainMinitor = function(opts){
		this.init(opts);
		this.rawKey = null;
		this.rawName = null;
		this.itemKey = null;
		this.itemName = null;
		this.domain = null;
	}
	DomainMinitor.prototype = {
		init:function(opts){
			console.log("domain init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			//添加raw
			_opts.panelBox.delegate(".btn_add_domain_raw","click",function(){
				var _rawKey = $(this).attr("data-rawKey");
				var _name = $(this).attr("data-name");
				var _domain = $(this).attr("data-domain"); 
				if(_rawKey && _name){
					_this.rawKey = _rawKey;
					_this.rawName = _name;
					_this.domain = _domain;
					renderAddDomainRaw(_opts.panelBox, {
						raw_key:_rawKey,
						name:_name,
						domain:_domain,
						type:"mod"
					});
				}else{
					renderAddDomainRaw(_opts.panelBox);
				}
			})
			_opts.panelBox.delegate(".btn_render_raw_list","click",function(){
				_this.render(null);
			})
			//提交raw
			_opts.panelBox.delegate(".btn_submit_domain_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitRaw(data);
				}
			});
			
			//创建alert
			_opts.panelBox.delegate(".btn_submit_domain_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitAlert(data);
				}
			});
			//创建rule
			_opts.panelBox.delegate(".btn_submit_domain_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitRule(data);
				}
			});
			//创建alert
			_opts.panelBox.delegate(".btn_submit_domain_item","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitItem(data);
				}
			});
			//修改raw
			_opts.panelBox.delegate(".btn_mod_domain_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modRaw(data);
				}
			});
			//获取raw
			_opts.panelBox.delegate(".btn_get_domain_raw","click",function(){
				renderAddDomainRaw(_opts.panelBox, {
					raw_key:_this.rawKey,
					name:_this.rawName,
					domain:_this.domain,
					type:"mod"
				});
			})
			//获取alert
			_opts.panelBox.delegate(".btn_get_domain_alert","click",function(){
				_this.getAlert();
			})
			//获取rule list
			_opts.panelBox.delegate(".btn_get_domain_rule","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var itemKey = $(this).attr("data-itemKey");
				var itemName = $(this).attr("data-itemName");
				var domain = $(this).attr("data-domain");
				if(rawKey && rawName){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.domain = domain;	
				}
				if(itemKey){
					_this.getRule(null, {item_key:itemKey,name:itemName});
				}else{
					_this.getRule();
				}
			})
			//获取item list
			_opts.panelBox.delegate(".btn_get_domain_item","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var domain = $(this).attr("data-domain");
				if(rawKey && rawName){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.domain = domain;
				}
				_this.getItem();
			})
			//获取rule list item
			_opts.panelBox.delegate(".btn_get_domain_ruleItem","click",function(){
				var rule = null;
				try{
					rule = JSON.parse($(this).attr("data-rule"));
				}catch(e){}
				_this.itemKey = rule.item_key;
				_this.itemName = rule.item_name;
				renderAddDomainRule(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						itemKey:_this.itemKey, 
						itemName : _this.itemName,
						rule:rule
					}
				);
			});
			//获取item list item
			_opts.panelBox.delegate(".btn_get_domain_itemItem","click",function(){
				var item = null;
				try{
					item = JSON.parse($(this).attr("data-item"));
				}catch(e){}
				_this.itemKey = item.item_key;
				_this.itemName = item.name;
				renderAddDomainItem(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						item:item
					}
				);
			});
			//修改alert
			_opts.panelBox.delegate(".btn_mod_domain_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modAlert(data);
				}
			});
			
			//添加rule
			_opts.panelBox.delegate(".btn_add_domain_rule","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var itemKey = $(this).attr("data-itemKey");
				var itemName = $(this).attr("data-itemName");
				var domain = $(this).attr("data-domain");
				if(rawKey && itemKey){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.domain = domain;
					_this.itemKey = itemKey;
					_this.itemName = itemName;
				}
				renderAddDomainRule(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						itemKey:_this.itemKey,
						itemName:_this.itemName
					}
				);
			});
			//添加item
			_opts.panelBox.delegate(".btn_add_domain_item","click",function(){
				renderAddDomainItem(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName});
			});
			//修改rule
			_opts.panelBox.delegate(".btn_mod_domain_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modRule(data);
				}
			});
			//修改item
			_opts.panelBox.delegate(".btn_mod_domain_item","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modItem(data);
				}
			});
			//删除raw
			_opts.panelBox.delegate(".btn_del_domain_raw","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				_this.delRaw(rawKey);
			});
			//删除alert
			_opts.panelBox.delegate(".btn_del_domain_alert","click",function(){
				_this.delAlert(_this.rawKey);
			});
			//删除rule
			_opts.panelBox.delegate(".btn_del_domain_rule","click",function(){
				var ruleKey = $(this).attr("data-ruleKey");
				_this.delRule(ruleKey);
			});
			//删除item
			_opts.panelBox.delegate(".btn_del_domain_item","click",function(){
				var itemKey = $(this).attr("data-itemKey");
				_this.delItem(itemKey);
			});
			//选择rule
			_opts.panelBox.delegate(".get_rule_by_select","change", function(){
				var item = {};
				try{
					item = JSON.parse($(this).val());
				}catch(e){}
				if(item && item.item_key){
					_this.getRule(null, item);
				}
			})
		},
		render:function(panel, params){
			this.rawKey = null;
			var _this = this;
			this.getMonitor(function(res){
				renderMonitorList(_this.opts.panelBox, {list:res.raw});
				_this.get_domain_query_status(function(parentType){
				    _this.domainStatus(parentType);
				});
			});
		},
		get_domain_query_status:function(callback){
            this.opts.get_mon_query_status(function(res, parentType){
                if(parentType == true){//整体是屏蔽的
                    console.log("parentType"+parentType);
                    $(".btn_domain_mon_screen").attr("disabled",true);//domain的屏蔽不可用
                    $(".btn_domain_mon_screen").css("background","#ADADAD");
                    $(".btn_domain_un_mon_screen").attr("disabled",true);//domain的解除不可用
                    $(".btn_domain_un_mon_screen").css("background","#ADADAD");
                }else{//整体是解除的
                }
                callback && callback(parentType);
            });
		},
		domainStatus:function(parentType){
		    var rule_name;
		    var _this = this;
		    $(".btn_domain_mon_status_query").each(function(i){
		        var $this = $(this);
		        rule_name = $this.attr("data-domain");
                _this.doDomainAjax($this, rule_name, parentType);
		    })
		},
		doDomainAjax:function(_this,rule_name, parentType){
		    $.ajax({
                url:"/xplatfe/monitor/domain_monitor_status_query/",
                data:{"rule_name":rule_name},
                success:function(res){
                    if(parentType != true){//外面是解除状态
                        if(res && res.msg.block == "yes"){//屏蔽中
                            _this.parents(".my_domain_item").find(".btn_domain_mon_screen").attr("disabled",true);//使屏蔽按钮不可用
                            _this.parents(".my_domain_item").find(".btn_domain_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_domain_item").find(".btn_domain_un_mon_screen").removeAttr("disabled");//使解除按钮可用
                            _this.parents(".my_domain_item").find(".domain_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" class="mon_stoped" />');
                        }else{//未屏蔽
                            _this.parents(".my_domain_item").find(".btn_domain_mon_screen").removeAttr("disabled");//使屏蔽按钮可用
                            _this.parents(".my_domain_item").find(".btn_domain_un_mon_screen").attr("disabled",true);//使解除按钮不可用
                            _this.parents(".my_domain_item").find(".btn_domain_un_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_domain_item").find(".domain_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/started.png" alt="started" class="mon_started" />');
                        }
                    }else{//外面是屏蔽状态
                        _this.parents(".my_domain_item").find(".domain_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                    }
                }
            });
		},
		submitRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_domain_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}else if(res.raw_key){
					_this.rawKey = res.raw_key;
					_this.rawName = _data.name;
				}
				if(callback){
					callback(res);
				}else{
					renderAddDomainItem(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		modRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_domain_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_domain_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modRule:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_domain_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		modItem:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_domain_item,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getItem();
				}
			})
		},
		submitAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_domain_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		submitRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_name + "_" + data.monitor_item_sel;
			this.opts.doAjax(this.opts.actions.add_domain_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					renderAddDomainAlert(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		submitItem:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_domain_item,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				_this.itemKey = res.item_key;
				_this.itemName = data.name;
				if(callback){
					callback(res);
				}else{
					renderAddDomainRule(
						_this.opts.panelBox, {
							rawKey:_this.rawKey,
							name:_this.rawName, 
							itemKey:_this.itemKey, 
							itemName : _this.itemName
						}
					)
				}
			})
		},
		getAlert:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_domain_raw, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _alert = res && res.alert ? res.alert : null;
					console.log(res)
					if(_alert){
						_alert = $.extend({
							rawKey:_this.rawKey,
							name:_this.rawName,
							type:"mod"
						},_alert)
					}else{
						_alert = {
							rawKey:_this.rawKey,
							name:_this.rawName,
						}
					}
					renderAddDomainAlert(_this.opts.panelBox, _alert);
				}
			},true)
		},
		getRule:function(callback, curItem){
			var _this = this;
			this.getItem(function(item){
				var _item = item && item.items ? item.items : [];
				var _curItem = curItem || _item[0];
				if(!_curItem || !_curItem.item_key){
					alert("请先添加一个监控项！");
					return;
				}
				_this.itemKey = _curItem.item_key;
				_this.itemName = _curItem.name;
				_this.opts.doAjax(_this.opts.actions.get_domain_rule, {item_key:_curItem.item_key}, function(res){
					if(callback){
						callback(res);
					}else{
						var _rule = res && res.rules ? res.rules : [];
						renderGetDomainRule(_this.opts.panelBox, {
							rawKey:_this.rawKey,
							name:_this.rawName,
							domain:_this.domain,
							rule:_rule,
							item:_curItem,
							itemList:_item
						});
					}
				},true)
			})
		},
		getItem:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_domain_item, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _item = res && res.items ? res.items : [];
					renderGetDomainItem(_this.opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						item:_item
					});
				}
			},true)
		},
		getMonitor:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_domain_monitor_by_app_key, {app_key:this.opts.appkey}, function(res){
				if(callback){
					callback(res);
				}else{
					renderMonitorList(_this.opts.panelBox, res);
				}
			},true)
		},
		delRaw:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_domain_raw,{raw_key:rawKey},function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delAlert:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_domain_alert, {raw_key:rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delRule:function(ruleKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_domain_rule, {rule_key:ruleKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		delItem:function(itemKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_domain_item, {item_key:itemKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getItem();
				}
			})
		}
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderMonitorList(box, data){
		box.html($.tmpl($("#tmpl_domain_monitorList").val(),{me:data}));
	}
	//添加raw
	function renderAddDomainRaw(box, data){
		data = data || {};
		box.html($.tmpl($("#tmpl_addDomainRaw").val(),{me:data}));
	}
	//添加alert
	function renderAddDomainAlert(box, data){
		box.html($.tmpl($("#tmpl_addDomainAlert").val(),{me:data}));
	}
	//添加Rule
	function renderAddDomainRule(box, data){
		box.html($.tmpl($("#tmpl_addDomainRule").val(),{me:data}));
	}
	//添加Item
	function renderAddDomainItem(box, data){
		box.html($.tmpl($("#tmpl_addDomainItem").val(),{me:data}));
	}
	//获取rule列表
	function renderGetDomainRule(box, data){
		box.html($.tmpl($("#tmpl_getDomainRule").val(),{me:data}));
	}
	function renderGetDomainItem(box, data){
		box.html($.tmpl($("#tmpl_getDomainItem").val(),{me:data}));
	}
	
	$.myMonitor = $.myMonitor || {};
	$.myMonitor.DomainMinitor = DomainMinitor;
 }(jQuery));