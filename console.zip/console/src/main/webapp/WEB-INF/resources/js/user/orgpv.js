(function($, win, undeined){ 
	var org_object = JSON.parse($("#hidden_org").val());
	var OrgpvList = function(opts){
        this.init(opts);
    }
	//************************OrgpvList.prototype**************************//
    OrgpvList.prototype = {
		init:function(opts){
			this.opts = opts;
		},
		get_org_role:function(callback){
			this.opts.doajax(this.opts.actions.get_org_role, {org_id:this.opts.org_id}, "json", function(res){
				if(res){//is admin or org_developer
					callback && callback(res);
				}else{
					alert("不是org管理员，没有权限查看");
				}
			});
		},
        reload:function(){
			location.hash = "#/orgpv/";
		},
		render:function(panel, params){
			var _this = this;
			this.get_org_role(function(res){
				var data = {"role":res,"org_cn_name":org_object.cn_name};
				renderOrgpvList(_this.opts.content,data);
				$("#page_content").hide();
			});
		}
	}
	//************************静态方法输出*********************************//
    function renderOrgpvList(box, data){
        box.html($.tmpl($("#tmpl_orgpv").val(),{me:data}));
    }
	$.myAdmin = $.myAdmin || {};
    $.myAdmin.OrgpvList = OrgpvList;
}(jQuery));
