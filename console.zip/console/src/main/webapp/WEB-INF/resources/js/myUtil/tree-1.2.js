﻿/**
 *@Require jQuery.js
 *@Require Tmpl.js
 *@Require common.js
 *@Require loading.js
 *树的逻辑
 *@Return $.myUtil.tree.js
 * add by zzx
 */
(function($, win, undeined){  
	var HOSTS = "";
	var Actions = {
		getUser:HOSTS + "/xplatfe/api2/get_user_spaces?page=1&size=0&get_user_space=true"
	}
	var templete = {
		tree:'<div class="menuList">\
            <%for(var i = 0; i <me.spaces.length;i++){var _me = me.spaces[i];%>\
					<div class="listBox">\
						<div class="listTitle"><%=_me.name%><span class="myIcon myIcon_down"></span></div>\
						<div class="listLink">\
							<%for(var j = 0; j < _me.apps.length; j++){var _app = _me.apps[j];var cls = _app.id == me.currentApp ? "current" : "";%>\
								<a href="<%=me.path%>?app_id=<%=_app.id%>" class="<%=cls%>" data-id="<%=_app.id%>" data-org="<%=_app.org%>" data-name="<%=_app.name%>" data-space="<%=_app.space%>" ><%=_app.name%></a>\
							<%}%>\
						</div>\
					</div>\
            <%}%></div>',
		empty:'<div style="margin:20px auto;color:#fff;">没有可用的App</div><a href="/xplatfe/user2/setting" class="btn btn-primary" >申请权限</a>'
		
	}
	var Tree = function(opts){
		var _opts = {
			path:null,
			content:$(".layout-menu"),
			templete:templete,
			//当前的app
			currentApp:null,
            currentOrg:null
		}
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	var loading;
	Tree.prototype = {
		init:function(){
			var _opts = this.opts;
			var _this = this;
            this.data = {};
			loading = $.myUtil.loading({
				parent:$(".layout-menu-wapper"),
                initShow:false,
			});
            if(_opts.currentOrg){
                this.renderTree(_opts.currentOrg);
                this.addEvent();
            }else{
                _this.render(_opts.templete.empty);
            }
		},
        renderTree:function(org_id){
            var _this = this;
            var _opts = this.opts;
            loading.show();
            _opts.content.html("");
            this.getUsers({org_id:org_id}, function(res){
                loading.hide();
                if(res && res.spaces.length > 0){
                    res["currentApp"] = _opts.currentApp;
                    res["path"] = _opts.path;
                    _this.render(_opts.templete.tree, res);
                }else{
                    _this.render(_opts.templete.empty);
                }
                _this.resizeTree();
            })
        },
		//绑定事件
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
            $(".tree_org_item").bind("click", function(){
                var cn_name = $(this).attr("data-cn_name");
                var id = $(this).attr("data-id");
                $("#current_org_text").html(cn_name);
                _this.renderTree(id);
            })
			
			_opts.content.delegate(".listLink a","click", function(){
				if($(this).hasClass("current")){
					return false;
				}
			});
			_opts.content.delegate(".listTitle","click",function(){
				$(this).next(".listLink").toggle();
				$(this).find(".myIcon").toggleClass("myIcon_down");
				$(this).toggleClass("removeBg");
				_this.resizeTree();
				return false;
			});
			_opts.content.delegate(".listTitle","selectstart",function(){
				return false;
			});
			var timer;
			$(window).bind("resize", function(){
				clearTimeout(timer);
				timer = setTimeout(function(){
					_this.resizeTree();
				},200)
			});
		},
		resizeTree:function(){
			if($(".layout-leftContent").height() > $(".layout-content").height() || $(".layout-content").width() <= 1100){
				$(".layout-leftContent").css("position","relative");
			}else{
				$(".layout-leftContent").css("position","fixed");
			}
		},
        getUsers:function(data, callback){
            var org_id = data.org_id;
            var _this = this;
            if(_this.data[org_id]){
                callback && callback(_this.data[org_id]);
                return
            }
            $.ajax({
                url:Actions.getUser,
                data:data,
                success:function(res){
                    _this.data[org_id] = res;
                    callback && callback(res);
                }
            })
        },
		render:function(tmpl, data, parent, type){  
			var _opts = this.opts;
			parent = parent || _opts.content;
			//追加数据
			if(type){
				parent.append($.tmpl(tmpl, {me:data}));
			//替换数据
			}else{
				parent.html($.tmpl(tmpl, {me:data}));
			}
		}
		
	}
	$.myUtil = $.myUtil || {};
	$.myUtil.tree = function(opts){
		return new Tree(opts);
	}
}(jQuery, window))
