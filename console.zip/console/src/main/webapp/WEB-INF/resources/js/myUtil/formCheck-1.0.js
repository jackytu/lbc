﻿/**
 * $.myUtil.formCheck.js
 * add by zzx
 */
(function($, win, undefined){
	var formCheck = {
		//判断是否为空
		require:function(val){
			if(val=="" || typeof val==="undefined"){
				return  [-1, "值不能为空"];
			}
			return [0,"noError"];
		},
		//不能包含中文
		chinese:function(val){
			if(/[\u4e00-\u9fa5]/.test(val)){
				return [-1, "不能包含中文"];
			}
			return [0,"noError"];
		},
		//整数
		integer:function(val){
			if(!/^-?[0-9]+$/.test(val)){
				return [-1, "必须为整数"];
			}
			return [0,"noError"];
		},
		/**
		*限定数字范围
		*@Param val [String] 要比对的值
		*@Param key [String] low-high  限定的值
		*/
		scope:function(val, key){
			var arr = key.split("-");
			var temp;
			if(!$.exists(arr[0]) && !$.exists(arr[1])){
				console.log("error");
				return;
			}
			if(!/^-?[0-9]+(.[0-9]+|[0-9]*)$/.test(val)){
				return [-1, "必须为数字"];
			}
			arr[0] = arr[0] && parseInt(arr[0]);
			arr[1] = arr[1] && parseInt(arr[1]);
			if(!$.exists(arr[0])){
				if(val > arr[1]){
					return [-1, "请输入小于等于"+arr[1]+"的值"];
				}
			}else if(!$.exists(arr[1])){
				if(val < arr[1]){
					return [-1, "请输入大于等于"+arr[0]+"的值"];
				}
			}else{
				if(arr[1] < arr[0]){
					temp = arr[1];
					arr[1] = arr[0];
					arr[0] = temp;
				}
				if(val > arr[1] || val < arr[0]){
					return [-1, "请输入"+arr[0]+"到"+arr[1]+"之间的数"];
				}
			}
			return [0,"noError"];
		}
	}
	var checkForm = function(input, type, callback){
		var rules, temp, _callback = callback || function(){}, _formCheck = formCheck;	
		try{
			rules = JSON.parse( input.attr(type) );
			if(!rules || !_formCheck){
				_callback(input);
				return true;
			}
		}catch(e){
			console.log(e);
			_callback(input);
			return true;
		}
		for(var i in rules){
			if(rules.hasOwnProperty(i) && _formCheck[i]){
				 temp = _formCheck[i](input.val(), rules[i]);
				 if(temp[0] === -1){
					_callback(input, temp[1]);
					return false;
				 }
			}
		}
		_callback(input);
		return true;
	};
	var getFormData = function(parent, type, error){
		var _type = type || '',
			params = {},
			_checkBoxArr = {},
			_checked = true,
			_flag = true,
			_parent = parent || $("body");
		//支持select
		_parent.find("select"+_type).each(function(index){
			var key = $(this).attr("name");
			if(key){
				params[key] = $(this).val();
			}
		});
		_parent.find("input"+_type).each(function(index){
			var type = $(this).attr("type");
			var key = $(this).attr("name");
			console.log(type)
			//支持checkBox
			if(type == "checkbox"){
				if(!_checkBoxArr[key]){
					_checkBoxArr[key] = {
						input:$(this)
					};
				}
				if($(this)[0].checked){
					if(!params[key]){
						_checkBoxArr[key].allow = true;
						params[key] = $(this).val();
					}else{
						params[key] += ","+$(this).val();
					}
				}
			}else if(type == "radio"){
				if($(this)[0].checked){
					params[key] = $(this).val();
				}
			}else{	
				//支持普通的Input
				if(key){
					params[key] = $(this).val();
					_checked =  checkForm($(this), "data-checkRule", function(input, msg){
						error && error(input, msg, _parent);
					});
					if(!_checked){
						_flag = false;
					}
				}
			}			
		});
		for(var i in _checkBoxArr){
			if(_checkBoxArr.hasOwnProperty(i) && !_checkBoxArr[i].allow){
				error && error(_checkBoxArr[i].input, "请至少选择一项", _parent);
				return false;
			}
			error && error(_checkBoxArr[i].input, null , _parent);
		}
		return _flag ? params : false;
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.formCheck = getFormData;
}($, window))