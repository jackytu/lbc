﻿/**
 *@Require jQuery.js
 *@Require Tmpl.js
 *@Require loading.js
 *联想词
 *@Return $.myUtil.think.js
 * add by zzx
 */
(function($){
	var HOSTS = "";
	var Actions = {
		getUserList:"/xplatfe/api2/get_userInfo_byKeywords?keyword="
	}
	var templete = {
		list:'<%if(me.length <=0){%><div style="color:#666;font-size:12px;padding:10px;">暂无数据</div>\
        <%}%>\
        <%for(var i = 0; i < me.length;i++){%>\
				<a class="aNode" data-loginName="<%=me[i].loginName%>" data-name="<%=me[i].name%>" href="javascript:;" title="邮箱:<%=me[i].email%>,部门:<%=me[i].dept%>" style="display:block;padding:0 10px;width:100%;white-space:nowrap;overflow:hidden;height:30px;line-height:30px;"><span style="float:none;color:#555;"><%=me[i].name%></span><span style="font-size:12px;color:#bbb;margin-left:5px;float:none;"><%=me[i].email.split("@")[0]%></span><span><%=me[i].dept%></span></a>\
			  <%}%>\
		',
	}
	var Think = function(opts){
		var _opts = {
			obj:null,
            direction:"bottom",
            parents:$("body")
		}
		$.extend(_opts, opts);
		this.opts = _opts;
		this.init();
	}
	Think.prototype = {
		init:function(){
			var _opts = this.opts;
			var _this = this;
			var obj = _opts.obj;
			this.thinkObj = this.createThinkObj();
			this.addEvent();
		},
		addEvent:function(){
			var obj = this.opts.obj;
			var timer = null;
			var _this = this;
            if(typeof obj == "string"){
                this.opts.parents.delegate(obj, "keyup", function(e){
                    obj = _this.opts.obj = $(this);
                    doKeyUp($(this), e);
                })
                
            }else{
                obj.bind("keyup",function(e){
                    doKeyUp($(this), e);
                });
            }
			$("body").bind("click", function(){
                _this.close();
            })
			this.thinkObj.delegate(".aNode","click",function(){
				var _obj = {
					inputObj:obj,
					listObj:_this.thinkObj,
					_this:$(this)
				};
				obj.trigger("thinkListClicked",_obj);
                _this.close();
                return false;
			})
            function doKeyUp($this, e){
                var currentObj = _this.thinkObj.find(".current");
                if(e.keyCode == 13){
                    var _obj = {
                        inputObj:obj,
                        listObj:_this.thinkObj,
                        _this:currentObj.length > 0 ? currentObj : _this.thinkObj.find(".aNode").eq(0)
                    };
                    obj.trigger("thinkListClicked",_obj);
                    _this.close();
                    return false;
                }
                if(e.keyCode == 40 || e.keyCode == 38){
                    var index = currentObj.index();
                    var $aNode = _this.thinkObj.find(".aNode");
                    if(index == -1){
                        index = 0;
                    }else if(e.keyCode == 40){
                        index += 1;
                        index = index >= $aNode.length ? 0 : index;
                    }else{
                        index -= 1;
                        index = index < 0 ? $aNode.length-1 : index;
                    }
                    currentObj.removeClass("current");
                    $aNode.eq(index).addClass("current");
                    return false;
                }
				var val = $this.val();
				try{
					val = val.trim();	
				}catch(e){}
				clearTimeout(timer);
				timer = setTimeout(function(){
                    _this.setPos();
					_this.doThink(val);
				},300)
            }
		},
        setPos:function(){
            var parentName = this.opts.parents[0].nodeName;
            var obj = this.opts.obj;
            if(this.opts.direction == "top"){
                if(parentName == "BODY" || parentName == "#document" || !parentName){
                    this.thinkObj.css("top",obj.offset().top-310+"px").css("left",obj.offset().left+"px");
                }else{
                    this.thinkObj.css("top",obj.offset().top-310+this.opts.parents.scrollTop()+"px").css("left",obj.offset().left+"px");
                }
            }else{
                if(parentName == "BODY" || parentName == "#document" || !parentName){
                    this.thinkObj.css("top",obj.offset().top+obj.outerHeight()+"px").css("left",obj.offset().left+"px");
                }else{
                    this.thinkObj.css("top",obj.offset().top+obj.outerHeight()+this.opts.parents.scrollTop()+"px").css("left",obj.offset().left+"px");
                }
            }
        },
        close:function(){
            this.thinkObj.hide();
        },
		createThinkObj:function(){	
			if($("#myThinkObjContent")[0]){
				return $("#myThinkObjContent")
			}
			var thinkObj = document.createElement("div");
			thinkObj.className = "myThinkObjContent";
			thinkObj.id = "myThinkObjContent";
			thinkObj.style.cssText = "position:absolute;z-index:1050;display:none;border:1px solid #ccc;background:#fff;width:350px;height:310px;overflow-x:hidden;overflow-y:auto;white-space:nowrap;";
			this.opts.parents.append(thinkObj);
			return $(thinkObj);
		},
		doThink:function(val){
			var _this = this;
			if(val){
				this.doAjax(val,function(res){	
					if(res){
						_this.thinkObj.html($.tmpl(templete.list,{me:res}));
						_this.thinkObj.show();
					}else{
						_this.thinkObj.hide();
					}
				});
			}else{
				this.thinkObj.hide();
			}
		},
		doAjax:function(keyword, callback){
			$.ajax({
				url:Actions.getUserList+keyword,
				success:function(res){	
					callback && callback(res);
				}
			})
		}

	}
	$.myUtil = $.myUtil || {};
	$.myUtil.think = function(opts){
		return new Think(opts);
	}
}(jQuery))
