﻿/**
 *@Require jQuery.js
 *扩展jquery的观察者模式
 *@Return $.myUtil.observer.js
 * add by zzx
 */
(function ($) {

    var o = $({});
    var observer = {};
    
    observer.on = function () {
        o.on.apply(o, arguments);
    };

    observer.off = function () {
        o.off.apply(o, arguments);
    };

    observer.fire = function () {
        o.trigger.apply(o, arguments);
    };
    $.myUtil = $.myUtil || {};
    $.myUtil.observer = observer;
} (jQuery));