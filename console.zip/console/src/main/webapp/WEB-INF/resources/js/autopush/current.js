﻿/**
 * @file 上线的主要逻辑
 * @author zhaozhixin@baidu.com
 */
(function ($) {

    function unique(arr) {
        arr.sort();
        var re = [arr[0]];
        for (var i = 1; i < arr.length; i++) {
            if (arr[i] !== re[re.length - 1]) {
                re.push(arr[i]);
            }
        }
        return re;
    }

    function diff() {
        var temp = {};
        var result = [];
        var i;
        var j;
        var argsj;
        var args = arguments;
        var arg0 = args[0];
        for (i = 0; i < arg0.length; i++) {
            temp[arg0[i]] = {
                target: 0
            };
        }
        for (i = 1; i < args.length; i++) {
            for (j = 0; j < args[i].length; j++) {
                argsj = args[i][j];
                if (temp[argsj]) {
                    temp[argsj].target = -1;
                }
                else {
                    temp[argsj] = {
                        target: i
                    };
                }
            }
        }
        for (i in temp) {
            if (temp[i].target !== -1) {
                result.push({
                    ele: i,
                    index: temp[i].target
                });
            }
        }
        return result;
    }
    var CurrentAutopush = function (opts) {
        this.init(opts);
        this.diffObj = null;
    };
    CurrentAutopush.prototype = {
            init: function (opts) {
                this.opts = opts;
                this.currentState = null;
                this.socket = null;
                this.isApproval = true;
                this.isMd5Checked = false;
                this.getAutopushState();
                this.addEvent();

            },
            getAutopushState: function () {
                var self = this;
                self.disabledAutoPush = false;
                $.ajax({
                    url: '/api/autopush2/get_autopush_state',
                    success: function (res) {
                        if (res && res.data && res.data.state === 'off') {
                            self.disabledAutoPush = true;
                        }
                    }
                });
            },
            addEvent: function () {
                var self = this;
                var opts = self.opts;
                opts.content.delegate('.btn_start_ci_process', 'click', function () {
                    self.renderAddCiReview();
                });
                opts.content.delegate('.btn_start_rd_process', 'click', function () {
                    self.renderAddRdReview();
                });
                opts.content.delegate('.btn_render_current', 'click', function () {
                    self.renderReview({
                        type: 'new'
                    });
                });
                opts.content.delegate('.btn_submit_ci_review', 'click', function () {
                    var data = opts.formIns.getForm($(this));
                    if (data) {
                        opts.doajax(opts.actions.icafe_ci_submit, data, 'json', function (res) {
                            if (res && (res.status === 1 || res.status === '1')) {
                                self.render('current', []);
                            }
                            else {
                                var msg = res ? res.msg : '';
                                alert('发起审批错误！原因：' + msg);
                            }
                        });
                    }
                });
                // 增量上线
                opts.content.delegate('#sel-plan', 'change', function () {
                    var val = $(this).val();
                    var lastVer = $('#last_version_wrap');
                    var ver = $('#version_wrap');
                    var rollbackVersionWrap = $('#rollbackVersionWrap');
                    var ftpWrap = $('#ftp_wrap');
                    var scmWrap = $('#scm_wrap');
                    var btnMd5 = $('.btn_md5');
                    var increaseFile = $('#increasement-file');
                    var deployVersion = $('#deploy_version');
                    scmWrap.hide();

                    if (val === 'increasement') {
                        lastVer.children('label').html('<span class="must_ico">*</span>运行中版本');
                        ver.hide();
                        var html = '<div id="increasement-file" class="form-group">'
                                        + '<label class="col-sm-2 control-label">'
                                            + '<span class="must_ico">*</span>增量部署目录</label>'
                                            + '<div style="width:350px;" class="col-sm-6">'
                                            + '<input value="/home/work" data-require="true" '
                                            + 'name="target_dir" type="text" class="form-control" >'
                                            + '</div></div>';
                        $(html).insertAfter('#last_version_wrap');
                        deployVersion.val('9-9-9-99999');
                        rollbackVersionWrap.hide();
                        ftpWrap.show();
                        btnMd5.show();
                    }
                    else if (val === 'rollback') {
                        lastVer.children('label').html('<span class="must_ico">*</span>替换下线版本');
                        ver.hide();
                        deployVersion.val('9-9-9-99999');
                        rollbackVersionWrap.show();
                        increaseFile.remove();
                        ftpWrap.hide();
                        btnMd5.hide();
                    }
                    else {
                        lastVer.children('label').html('<span class="must_ico">*</span>替换下线版本');
                        ver.show();
                        rollbackVersionWrap.hide();
                        deployVersion.val('');
                        increaseFile.remove();
                        ftpWrap.show();
                        btnMd5.show();
                    }
                });
                // 上线套餐提示
                opts.content.delegate('.tips_icon', 'mouseover', function () {
                    var html = [
                        '<div id="myTipsWrap" style="display:none;position:absolute;max-width:400px" ',
                        'class="popover fade top in">',
                        '<div class="arrow" style="left: 20px;"></div>',
                        '<div class="popover-content">',
                            '<p>预发布-小流量-全流量：预发布阶段上线单个实例，小流量对单个实例进行域名映射，',
                            '全流量完成新版本上线。该流程实现灰度发布，上线过程存在多版本共同提供服务的情况。</p>',
                            '<p>预发布-全量部署-全流量：预发布上线单个实例，全量部署实例全部上线（新版本无流量接入），',
                            '全流量完成新版本流量接入并将老版本下线。该流程中新旧版本直接替换，不存在灰度发布</p>',
                            '</div>',
                        '</div>'
                    ].join('');
                    if (!$('#myTipsWrap')[0]) {
                        $('body').append(html);
                    }
                    var offset = $(this).offset();
                    var height = $('#myTipsWrap').height();
                    $('#myTipsWrap').css({
                        left: offset.left - 20 + $(this).outerWidth() / 2 + 'px',
                        top: offset.top - height + 'px'
                    }).show();
                });
                opts.content.delegate('.tips_icon', 'mouseout', function () {
                    $('#myTipsWrap').hide();
                });
                opts.content.delegate('.btn_submit_rd_review', 'click', function () {
                    var data = opts.formIns.getForm($(this));
                    if (data) {
                        opts.doajax(opts.actions.icafe_rd_submit, data, 'json', function (res) {
                            if (res && (res.status === 1 || res.status === '1')) {
                                self.render('current', []);
                            }
                            else {
                                var msg = res ? res.msg : '';
                                alert('发起审批错误！原因：' + msg);
                            }
                        });
                    }
                });
                opts.content.delegate('#input_war_text', 'keyup', function () {
                    var val = $(this).val().trim();
                    var war;
                    var svn = $('#input_scm_text').attr('data-svn');
                    if (val && svn) {
                        war = 'ftp://getprod:' + svn + '/output/' + val + $('#input_war_type').val();
                    }
                    else {
                        war = '';
                    }
                    $('#input_scm_text').attr('value', war).val(war);
                });
                opts.content.delegate('#input_war_type', 'change', function () {
                    var val = $('#input_war_text').val().trim();
                    var war;
                    var svn = $('#input_scm_text').attr('data-svn');
                    if (val && svn) {
                        war = 'ftp://getprod:' + svn + '/output/' + val + $(this).val();

                    }
                    else {
                        war = '';
                    }
                    $('#input_scm_text').attr('value', war).val(war);
                });
                opts.content.delegate('#input_ftp_text', 'change', function () {
                    self.isMd5Checked = false;
                });
                opts.content.delegate('#input_scm_text', 'change', function () {
                    self.isMd5Checked = false;
                });
                opts.content.delegate('.btn_md5', 'click', function () {
                    var ftp;
                    if (self.isScmAutopush()) {
                        ftp = $('#input_scm_text').val();
                    }
                    else {
                        ftp = $('#input_ftp_text').val();
                    }
                    self.opts.doajax(self.opts.actions.md5_check, {
                        ftp: ftp
                    }, 'json', function (res) {
                        if (res && res.state === 'ok') {
                            alert('验证成功！上线包对应的md5值为：' + res.info);
                            self.isMd5Checked = true;
                        }
                        else {
                            alert('验证失败！原因：' + res.info);
                            self.isMd5Checked = false;
                        }
                    });
                });
                opts.content.delegate('#deploy_last_version', 'diffVersion', function () {
                    var val = $(this).find('select').val();
                    if (self.diffObj) {
                        for (var i = 0; i < self.diffObj.length; i++) {
                            if (self.diffObj[i].ele === val) {
                                $('#last_version_tips').show();
                                $('#last_version_tips').find('p').html('警告：集群版本不一致，仅' + self.diffObj[i]
                                    .cluster + '存在版本' + self.diffObj[i].ele);
                                return;
                            }
                        }
                    }
                    $('#last_version_tips').hide();
                });
                opts.content.delegate('#deploy_last_version select', 'change', function () {
                    $('#deploy_last_version').trigger('diffVersion');
                });
                opts.content.delegate('.btn_get_scm_version', 'click', function () {
                    var ftp = $(this).attr('data-ftp');
                    var version;
                    try {
                        version = ftp.split('_')[1];
                    }
                    catch (e) {
                        version = null;
                    }
                    if (version) {
                        $('#deploy_version').val(version);
                    }
                    $(this).hide();
                    $('.btn_get_custom_version').show();
                    $('#scm_wrap').show();
                    $('#ftp_wrap').hide();
                    self.isMd5Checked = false;
                });
                opts.content.delegate('.btn_get_custom_version', 'click', function () {
                    $(this).hide();
                    $('.btn_get_scm_version').show();
                    $('#scm_wrap').hide();
                    $('#ftp_wrap').show();
                    self.isMd5Checked = false;
                });

                opts.content.delegate('.btn_submit_ci_autopush', 'click', function () {
                    if (self.disabledAutoPush) {
                        alert('由于服务调整, 暂时不允许发起上线, 详情请咨询JPaaS服务号');
                        return false;
                    }
                    var data = opts.formIns.getForm($(this));
                    if (data) {
                        var old = $('#deploy_version').attr('data-old');
                        if (data.plan === 'rollback') {
                            if (!data.rversion || !data.last_version) {
                                alert('请选择一个回滚版本');
                                return;
                            }
                            if (data.rversion === data.last_version) {
                                alert('回滚版本和替换下线版本不能相同!');
                                return;
                            }
                            data.version = data.last_version;
                            data['last_version'] = data.rversion;
                        }
                        if (data.plan !== 'rollback') {
                            if (old && data.plan !== 'increasement') {
                                old = old.split(',');
                                for (var i = 0; i < old.length; i++) {
                                    if (old[i] && old[i] === data.version) {
                                        alert('scm版本已经存在！请联系OP解决');
                                        return;
                                    }
                                }
                            }
                            if (!self.isMd5Checked) {
                                alert('请先通过MD5验证，再发起上线！');
                                return;
                            }
                            if (!/^(\d+\-){3}(\d+)$/.test(data.version)) {
                                alert('版本格式不正确，正确格式类似：1-0-0-11');
                                return;
                            }
                        }
                        if (!data.unit || !/^[1-9][0-9]*$/.test(data.unit)) {
                            alert('请正确填写并发度');
                            return;
                        }
                        if (!self.isScmAutopush()) {
                            data['scm_path'] = data.ftp_path;
                        }

                        self.opts.doajax(self.opts.actions.icafe_ci_autopush, data, 'json', function (
                            res) {
                            if (res) {
                                location.hash = '#/current/deploy';
                            }
                        });
                    }
                });
                opts.content.delegate('.changeStep', 'click', function () {
                    var step = $(this).attr('data-step');
                    self.checkStatus(self.process_id, step);
                });
                opts.content.delegate('.btn-start-next', 'click', function () {
                    var from = $(this).attr('data-from').split('@')[0];
                    var to = $(this).attr('data-to').split('@')[0];
                    var isRollback = $(this).attr('data-rollback');
                    var isCancel = $(this).attr('data-cancel');
                    var state = $(this).attr('data-status');
                    var reg = /^FULL_TARGET(\d+)_FINISHED$/;
                    var reg2 = /^FULL_TARGET(\d+)_SCALING$/;
                    var targetIndex = 0;
                    var cf;
                    if (isRollback) {
                        cf = window.confirm('确定要执行回滚操作吗？');
                        if (!cf) {
                            return;
                        }
                    }
                    if (isCancel) {
                        cf = window.confirm('确定要撤销上线单吗？撤销操作不会进行回滚，可能导致线上异常，请确认后谨慎操作！');
                        if (!cf) {
                            return;
                        }
                    }
                    else {
                        if (!isRollback) {
                            if (reg.test(state) || reg2.test(state)) {
                                targetIndex = parseInt(state.replace(reg, '$1'), 10) + 1;
                                from = 'minor';
                                to = 'full';
                            }
                        }
                        else {
                            if (reg.test(state) || reg2.test(state)) {
                                targetIndex = parseInt(state.replace(reg, '$1'), 10);
                            }
                        }
                    }
                    var data = {
                        start: from,
                        end: to
                    };
                    data['target_index'] = targetIndex;
                    data['process_id'] = self['process_id'];
                    data['icafe_process_id'] = self['icafe_process_id'];
                    $('.btn-start-next').attr('disabled', 'disabled');
                    $('.timeTreeBlock-status').addClass('status-ing').html(
                        '<img style=\'margin-right:3px;\' src=\'/img/loading.gif\' />正在处理请求'
                    );
                    self.deployStatus(data, function (res) {
                        if (location.hash !== '#/current/deploy') {
                            location.hash = '#/current/deploy';
                        }
                        else {
                            self.checkStatus(self.process_id, null, 2);
                        }
                    });
                });
                opts.content.delegate('.btn_start_process', 'click', function () {
                    self.isApproval = false;
                    self.render('current', []);
                });
            },
            isScmAutopush: function () {
                return $('#ftp_wrap').css('display') === 'none';
            },
            // 获取进行中的上线
            getBeingAutopush: function (callback) {
                var self = this;
                this.opts.doajax(this.opts.actions.getHistory, null, 'jsonp', function (res) {
                    var st = null;
                    var being = null;
                    if (res) {
                        for (var i = 0; i < res.length; i++) {
                            st = self.opts.lang[res[i].state];
                            // 未完成
                            if (!st) {
                                being = res[i];
                                break;
                            }
                        }
                    }
                    callback && callback(being);
                }, true);
            },
            render: function (panel, params) {
                var self = this;
                var param = params[0];
                var maxStep = 0;
                var step = 0;
                self.opts.loading.show();
                self.getBeingAutopush(function (historyRes) {
                    self.getLatestIcafe(function (icafeRes) {
                        self.opts.loading.hide();
                        icafeRes = icafeRes || {};
                        var data = {};
                        data['history_res'] = historyRes;
                        data['icafe_res'] = icafeRes;
                        if (icafeRes && icafeRes.process) {
                            self['icafe_process_id'] = icafeRes.process.processId;
                        }
                        if (historyRes) {
                            // 有未完成的上线单
                            self.getStatus(historyRes.id, function (res) {
                                if (res.state === 'FULL_FINISHED' || res.state === 'INCREASEMENT_FINISHED') {
                                    maxStep = 3;
                                }
                                else {
                                    maxStep = 2;
                                }
                                (step = self.renderMenu(maxStep, param)) !== false && self.renderContent(step, data);
                            });
                        }
                        else {
                            if (icafeRes.state === 'ready' || !self.isApproval) {
                                maxStep = 1;
                            }
                            (step = self.renderMenu(maxStep, param)) !== false && self.renderContent(step, data);
                        }
                    });
                });

            },
            showLog: function (processId) {
                var log = this.opts.log;
                var logPre = log.find('pre');
                this.socket = new WebSocket(this.opts.logPath + '/autopush/api/log/' + processId);
                log.show();
                logPre.html('');
                this.socket.onmessage = function (event) {
                    var ev = event || window.event;
                    var height = logPre[0].scrollHeight;
                    logPre.append(ev.data);
                    logPre.scrollTop(height);
                };
            },
            renderContent: function (step, data) {
                var self = this;
                self.opts.log.hide();
                // 如果是org管理员 就不做权限判断
                if (!this.opts.isorgdeveloper || this.opts.isorgdeveloper === 'False') {
                    if (data.history_res && data.history_res.operator.split('@')[0] !== this.opts.user) {
                        this.opts.content.html('<p class="alert alert-warning">' + data.history_res.operator
                            + '存在未完成的上线单，如需要新建上线单，请联系' + data.history_res.operator
                            + '或者产品线管理员结单 <a target="_blank" href="/xpltfe/autopush2/form?process_id='
                            + data.history_res.id + '">上线单详情</a></p>');
                        return;
                    }
                    if (data.icafe_res && data.icafe_res.process && data.icafe_res.process.createUser.split('@')[
                            0] !== this.opts.user) {
                        this.opts.content.html('<p class="alert alert-warning">' + data.icafe_res.process.createUser
                            + '存在未完成的审批单，如需要新建上线单，请联系' + data.icafe_res.process.createUser
                            + '或者产品线管理员结单 <a target="_blank" href="' + data.icafe_res.process.processUrl
                            + '">审批单详情</a></p>');
                        return;
                    }
                }
                if (step === 0) {
                    var icafe = data.icafe_res || {};
                    if (data.history_res || icafe.state === 'wait' || icafe.state === 'ready') {
                        icafe.type = 'current';
                    }
                    else {
                        icafe.type = 'new';
                    }
                    this.renderReview(icafe);
                }
                else if (step === 1) {
                    this.renderAutopush(data);
                    this.getHistoryVersion(function (res) {
                        self.renderHistoryVersion(res);
                    });
                }
                else if (step === 2) {
                    if (data.history_res) {
                        self['process_id'] = data['history_res'].id;
                        self.showLog(self['process_id']);
                        if (location.hash !== '#/current/deploy') {
                            location.hash = '#/current/deploy';
                        }
                        else {
                            self.checkStatus(self.process_id, null, 1);
                        }
                    }
                }
                else if (step === 3) {
                    if (data.history_res) {
                        self['process_id'] = data['history_res'].id;
                        self.renderCheckService(self['process_id'], data);
                    }
                }
            },
            renderCheckService: function (processId, data) {
                var param = {
                    data: data,
		    opts: this.opts,
                    lang: this.opts.lang
                };
                param['process_id'] = processId;
                this.opts.content.html($.tmpl($('#current_tmpl_check').val(), param));
            },
            checkStatus: function (processId, currentStep, renderState) {
                if (!processId || location.hash !== '#/current/deploy') {
                    return;
                }
                var argu = arguments;
                var self = this;

                this.getStatus(processId, function (res) {
                    res.currentStep = currentStep;
                    if (res && res.state) {
                        var langState;
                        if (res.plan === 'nuomi') {
                            langState = self.opts.lang.NUOMILANGSTATE;
                        }
                        else if (res.plan === 'increasement') {
                            langState = self.opts.lang.INCREASESTATE;
                        }
                        else if (res.plan === 'rollback') {
                            langState = self.opts.lang.ROLLBACKSTATE;
                        }
                        else {
                            langState = self.opts.lang.LANGSTATE;
                        }

                        var st = res.state;
                        var hasFinished = st.indexOf('FINISHED');
                        var currentItem = null;
                        for (var i = 0; i < langState.all.length; i++) {
                            var langItem = langState[langState.all[i].state];
                            if (currentItem) {
                                break;
                            }
                            for (var j = 0; j < langItem.length; j++) {
                                if (langItem[j].state === st) {
                                    currentItem = langState.all[i];
                                    break;
                                }
                            }
                        }
                        res.currentItem = currentItem;
                        if (st !== self.currentState || currentStep || renderState === 1) {
                            self.renderAutopushDeploy(res);
                        }
                        if ((hasFinished === -1 && st.indexOf('FAIL') === -1 && st.indexOf('DONE') === -1)
                            || (hasFinished !== -1 && st === self.currentState && !currentStep && renderState !== 1)) {
                            self.currentState = st;
                            if (!self.timer) {
                                self.timer = setTimeout(function () {
                                    self.timer = null;
                                    argu.callee.call(self, processId, currentStep);
                                }, 1500);
                            }
                        }
                        self.currentState = st;
                    }
                    console.log(res);
                });
            },
            renderAutopushDeploy: function (res) {
                var lang;
                if (res && res.plan === 'nuomi') {
                    lang = this.opts.lang.NUOMILANGSTATE;
                }
                else if (res.plan === 'increasement') {
                    lang = this.opts.lang.INCREASESTATE;
                }
                else if (res.plan === 'rollback') {
                    lang = this.opts.lang.ROLLBACKSTATE;
                }
                else {
                    lang = this.opts.lang.LANGSTATE;
                }
                var param = {
                    me: res,
		    opts: this.opts,
                    lang: lang
                };
                param['app_info'] = this.opts['app_info'];
                this.opts.content.html($.tmpl($('#current_tmpl_deploy').val(), param));
            },
            renderHistoryVersion: function (res) {
                var deployLastVersion = $('#deploy_last_version');
                var rollbackVersion = $('#rollbackVersion');
                if (res) {
                    var ver = res.running_versions && res.running_versions.split(',') || [];
                    var allVer = res.all_versions && res.all_versions.split(',') || [];
                    var html = '<select class="form-control" name="last_version">';
                    var rollbackHtml = '<select class="form-control" name="rversion">';
                    for (var i = ver.length - 1; i >= 0; i--) {
                        if (ver[i]) {
                            html += '<option value="' + ver[i] + '">' + ver[i] + '</div></option>';
                        }
                        for (var j = 0; j < allVer.length; j++) {
                            if (allVer[j] === ver[i]) {
                                allVer.splice(j, 1);
                                break;
                            }
                        }
                    }
                    for (var i = allVer.length - 1; i >= 0; i--) {
                        if (allVer[i]) {
                            rollbackHtml += '<option value="' + allVer[i] + '">' + allVer[i] + '</div></option>';
                        }
                    }
                    if (ver.length <= 0) {
                        rollbackHtml = html = '<input type="text" style="display:none;" name="last_version" />暂无';
                    }
                    else {
                        html += '</select>';
                        rollbackHtml += '</select>';
                        /* 增量发布
                        $('#sel-plan').append('<option value='increasement'>增量发布</option>');*/
                    }
                    $('#deploy_version').attr('data-old', res.all_versions);
                    deployLastVersion.html(html);
                    rollbackVersion.html(rollbackHtml);
                    deployLastVersion.trigger('diffVersion');
                    $('.btn_submit_ci_autopush').removeAttr('disabled');
                }
                else {
                    $('.btn_submit_ci_autopush').attr('disabled', 'disabled');
                    deployLastVersion.html('<span style="color:red;">历史版本获取错误,请联系OP解决</span>');
                }
            },
            renderMenu: function (maxStep, param) {
                var res = param ? this.menuControll(maxStep, param) : this.menuControll(maxStep);
                if (res && res.data) {
                    renderCiMenu(this.opts.menu, res.data);
                    return res.currentStep;
                }
                return false;
            },
            renderAddCiReview: function (data) {
                data = data || {};
                this.opts.content.html($.tmpl($('#current_tmpl_addCiReview').val(), {
                    me: data,
		    opts: this.opts
                }));
            },
            renderAddRdReview: function (data) {
                data = data || {};
                this.opts.content.html($.tmpl($('#current_tmpl_addRdReview').val(), {
                    me: data,
		    opts: this.opts
                }));
            },
            renderAutopush: function (data) {
                var param = {
                    me: data,
		    opts: this.opts,
                    lang: this.opts.lang,
                    isMatrix: this.opts.isMatrix,
                    isApproval: this.isApproval
                };
                param['app_info'] = this.opts.app_info;
                this.opts.content.html($.tmpl($('#current_tmpl_autopush').val(), param));
            },
            renderReview: function (data) {
                var param = {
                    me: data,
		    opts: this.opts
                };
                param['scm_svn'] = this.opts.scmsvn;
                this.opts.content.html($.tmpl($('#current_tmpl_review').val(), param));
            },
            getCurrentActivityList: function (activityList) {
                if (!activityList || !activityList[0]) {
                    return;
                }
                for (var i = 0; i < activityList.length; i++) {
                    if (!activityList[i].endTime) {
                        return activityList[i];
                    }
                }
                return activityList.sort(function (a, b) {
                    if (a.endTime.time > b.endTime.time) {
                        return -1;
                    }
                    else if (a.endTime.time < b.endTime.time) {
                        return 1;
                    }
                    return 0;
                })[0];
            },
            getLatestIcafe: function (callback) {
                var self = this;
                var icafeState = 'wait';
                var icafeMsg = null;
                var icafeObj = null;
                self.opts.doajax(self.opts.actions.get_icafe_process, null, 'json', function (res) {
                    if (res && res.state !== "false") {
                        var oRes = JSON.parse(res.icafe);
                        var scmVersion = res.version ? res.version.split('.').join('-') : res.version;
                        if (oRes) {
                            oRes = oRes.list[0];
                        }
                        if (oRes) {
                            // 取值： 0--运行 1 --完成 2--暂停 3--终止
                            var len = oRes.activityList.length;
                            if (len > 0) {
                                var curActivityList = self.getCurrentActivityList(oRes.activityList);
                                if (curActivityList.activityName.indexOf('OP/DBA') !== -1) {
                                    if (curActivityList.operationStatus === 0) {
                                        icafeState = 'ready';
                                    }
                                    else {
                                        icafeState = 'done';
                                    }
                                }
                                else {
                                    if (curActivityList.operationStatus === 0) {
                                        icafeMsg = '等待' + curActivityList.performer + '处理';
                                    }
                                }
                                icafeObj = {
                                    state: icafeState,
                                    msg: icafeMsg,
                                    process: oRes
                                };
                                icafeObj['scm_version'] = scmVersion;
                            }
                        }
                    }
                    callback && callback(icafeObj);
                }, true);
            },
            getHistoryVersion: function (callback) {
                var self = this;
                var targets = self.opts.app_info.target.split(',');
                var args = [];
                var url;
                for (var i = 0; i < targets.length; i++) {
                    url = self.opts.actions.get_history_version.replace('{target}', targets[i]);
                    args.push($.ajax({
                        url: url,
                        dataType: 'jsonp'
                    }));
                }
                // 多群集调用
                $.when.apply(null, args).done(function () {
                    var params = args.length < 2 ? [arguments] : arguments;
                    var param;
                    try {
                        var result = {};
                        result['all_versions'] = [];
                        result['running_versions'] = [];
                        var runningArr = [];
                        var clusterArr = [];
                        var i;
                        for (i = 0; i < params.length; i++) {
                            param = params[i];
                            if (param[1] === 'success') {
                                runningArr.push(param[0].running_versions.split(','));
                                clusterArr.push(param[0].cluster.replace('.baidu.com', ''));
                                param[0].all_versions
                                    && (result['all_versions'] = result['all_versions']
                                        .concat(param[0]['all_versions'].split(',')));
                                param[0].running_versions
                                    && (result['running_versions'] = result['unning_versions']
                                        .concat(param[0]['running_versions'].split(',')));
                            }
                        }
                        var df = {};
                        // 集群数量大于1个就触发diff检查
                        if (runningArr.length >= 2) {
                            df = diff.apply(null, runningArr);
                            for (i = 0; i < df.length; i++) {
                                df[i].cluster = clusterArr[df[i].index];
                            }
                        }
                        self.diffObj = df;
                        result['all_versions'] = unique(result['all_versions']).join(',');
                        result['running_versions'] = unique(result['running_versions']).join(',');
                        callback && callback(result);
                    }
                    catch (e) {
                        callback && callback(params[0][0]);
                    }
                });
            },
            getStatus: function (processId, callback) {
                var self = this;
                var url = self.opts.actions.get_status;
                var param = {};
                param['process_id'] = processId;
                self.opts.doajax(url, param, 'json', function (res) {
                    callback && callback(res);
                }, true);
            },
            deployStatus: function (data, callback) {
                var self = this;
                var url = self.opts.actions.deploy_status;
                self.opts.doajax(url, data, 'json', function (res) {
                    callback && callback(res);
                }, true);
            },
            menuControll: function (maxStep, param) {
                var currentStep = 0;
                var proc = ['ci_review', 'autopush', 'deploy', 'check'];
                var i;
                maxStep = maxStep || 0;
                param = param || proc[maxStep];
                for (i = 0; i < proc.length; i++) {
                    if (proc[i] === param) {
                        currentStep = i;
                        break;
                    }
                }
                if (currentStep > maxStep) {
                    location.hash = '#/current/' + proc[maxStep];
                    return null;
                }
                var data = [];
                for (i = 0; i < 4; i++) {
                    data[i] = {};
                    if (maxStep >= i) {
                        if (currentStep === i) {
                            data[i].href = 'javascript:;';
                            data[i].cls = 'processing';
                        }
                        else {
                            data[i].href = '#/current/' + proc[i];
                            data[i].cls = 'processed';
                        }
                    }
                    else {
                        data[i].href = 'javascript:;';
                        data[i].cls = '';
                    }
                }
                return {
                    data: data,
                    currentStep: currentStep
                };
            }
        };
    function renderCiMenu(box, data) {
        box.html($.tmpl($('#current_tmpl_menu').val(), {
            me: data
        }));
    }

    $.myAutopush = $.myAutopush || {};
    $.myAutopush.currentAutopush = CurrentAutopush;
}(jQuery));
