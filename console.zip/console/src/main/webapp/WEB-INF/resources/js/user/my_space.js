﻿/**
 * @file myspace
 * @author  zhaozhixin@baidu.com
 */
(function ($) {
    var maxLen;
    var MySpace = function (opts) {
        this.size = 5;
        this.pageContent = $('#page_content');
        this.pageUtil = $.myUtil.page({
            obj: this.pageContent,
            initShow: false,
            doRender: false
        });
        this.appList = {};
        this.statusList = null;
        this.clusters = null;
        this.init(opts);
    };
    MySpace.prototype = {
            init: function (opts) {
                this.opts = opts;
                this.addEvent();
            },
            addEvent: function () {
                var self = this;
                var opts = self.opts;
                $('#setAutopushState').bind('click', function () {
                    var state = $('#autopushState').val();
                    var desc = $('#autopushDesc').val();
                    $.ajax({
                        url: '/xplatfe/api2/set_autopush_state?state=' + state + '&desc=' + desc,
                        success: function (res) {
                            if (res && res.code === 200) {
                                alert('操作成功');
                            }
                            else {
                                alert('操作失败');
                            }
                        }
                    });
                    return false;
                });
                this.pageContent.bind('pageChange', function (res, data) {
                    if (location.hash.indexOf('list') === -1) {
                        location.hash = '/myspace/' + data;
                    }
                });
                opts.content.delegate('.btn_search_list', 'click', function () {
                    var data = self.opts.formIns.getForm($(this));
                    self.doSearch(data.keyword, data.type);
                });
                opts.content.delegate('.btn_add_space', 'click', function () {
                    var orgClusters = self.opts.org.clusters;
                    renderAddSpace(self.opts.content, orgClusters);
                    self.pageContent.hide();
                });
                opts.content.delegate('.btn_submit_app', 'click', function () {
                    var data = self.opts.formIns.getForm($(this));
                    if (/(^online\-)|(^rd\-)|(^qa\-)/.test(data.name)) {
                        alert('APP不能以"online-"或"rd-"开头');
                        return false;
                    }
                    if (data) {
                        self.addApp(data, function (res) {
                            if (res && res.status === 'ok') {
                                alert('添加成功!');
                                self.reload();
                            }
                            else if (res.code === -3) {
                                alert('app已经存在，换一个吧!');
                            }
                            else {
                                alert('添加app失败！' + res.msg);
                            }
                        });
                    }
                });
                opts.content.delegate('.delapp', 'click', function () {
                    var appId = $(this).attr('data-appid');
                    var appName = $(this).attr('data-appname');
                    var conf = window.confirm('确定要删除' + appName + '吗?');
                    var param = {};
                    param['app_id'] = appId;
                    if (conf) {
                        self.delApp(param, function (res) {
                            if (res) {
                                if (res.status === 'ok') {
                                    alert('删除成功!');
                                    self.reload();
                                }
                                else {
                                    alert('删除失败！' + res.msg);
                                }
                            }
                            else {
                                alert('服务异常，稍后再试');
                            }
                        });
                    }
                });
                opts.content.delegate('.change_version', 'change', function () {
                    var val = $(this).val();
                    $(this).parents('.formBox').find('.form-group').each(function () {
                        var tag = $(this).attr('data-tag');
                        if (!tag) {
                            return;
                        }
                        if ('v' + val === tag) {
                            $(this).show();
                        }
                        else {
                            $(this).hide();
                        }
                    });
                });
                opts.content.delegate('.btn_add_user_auth', 'click', function () {
                    var data = self.opts.formIns.getForm($(this));
                    var spaceId = data.space_id;
                    if (data) {
                        self.editorSpaceAuth(data, function (res) {
                            if (res && res.status === 'ok') {
                                self.appList = {};
                                self.renderSpaceAuthList(spaceId);
                            }
                            else {
                                alert('添加失败，原因:' + res.msg);
                                self.opts.loading.hide();
                            }
                        });
                    }
                });
                opts.content.delegate('.btn_add_admin_auth', 'click', function () {
                    var data = self.opts.formIns.getForm($(this));
                    var spaceId = data.space_id;
                    if (data) {
                        self.editorSpaceAuth(data, function (res) {
                            if (res && res.status === 'ok') {
                                self.appList = {};
                                self.renderSpaceAuthList(spaceId);
                            }
                            else {
                                alert('添加失败，原因:' + res.msg);
                                self.opts.loading.hide();
                            }
                        });
                    }
                });
                opts.content.delegate('.btn_delete_space_auth', 'click', function () {
                    var tr = $(this).parents('tr');
                    var spaceId = tr.attr('data-spaceid');
                    var user = tr.attr('data-user');
                    var role = tr.attr('data-role');
                    var param = {
                        user: user,
                        type: role
                    };
                    param['space_id'] = spaceId;
                    self.deleteSpaceAuth(param, function (res) {
                        if (res && res.status === 'ok') {
                            self.appList = {};
                            self.renderSpaceAuthList(spaceId);
                        }
                        else {
                            alert('删除失败');
                            self.opts.loading.hide();
                        }
                    });
                });
                opts.content.delegate('.my_editorRole', 'click', function () {
                    var data = JSON.parse($(this).parents('tr').attr('data-str'));
                    var spaceId = data.id;
                    self.renderSpaceAuthList(spaceId);
                });
                opts.content.delegate('.btn_submit_space', 'click', function () {
                    var data = self.opts.formIns.getForm($(this));
                    if (data) {
                        if (data.version === 2 || data.version === '2') {
                            data['cf_user'] = self.opts.user_name;
                            if (!data.clusters) {
                                alert('请选择集群!');
                                return;
                            }
                        }
                        else if (data.version === 1 || data.version === '1') {
                            var arr = [];
                            var v1Cluster = self.opts.org.clusters;
                            for (var i = 0; i < v1Cluster.length; i++) {
                                if (v1Cluster[i].target.indexOf('api.') !== -1) {
                                    arr.push(v1Cluster[i].id);
                                }
                            }
                            if (arr.length > 0) {
                                data.clusters = arr.join(',');
                            }
                            else {
                                data.clusters = '1,2';
                            }
                            if (!data.cf_user) {
                                alert('JPaaS用户不能为空!');
                                return;
                            }
                            data['cf_user'] = data['cf_user'].split('@')[0];
                        }
                        self.addSpace(data, function (res) {
                            if (res) {
                                if (res.status === 'ok') {
                                    alert('添加成功!');
                                    self.reload();
                                }
                                else if (res.code === -3) {
                                    alert('名称已经存在，换一个吧!');
                                }
                                else {
                                    alert('创建space失败！' + res.msg);
                                }
                            }
                            else {
                                alert('服务异常，稍后再试');
                            }
                        });
                    }
                });

                opts.content.delegate('.delspace', 'click', function () {
                    var data = JSON.parse($(this).parents('tr').attr('data-str'));
                    var spaceId = data.id;
                    var orgId = data.org;
                    var spaceName = data.name;
                    var conf = window.confirm('确定要删除' + spaceName + '吗?');
                    var param = {};
                    param['org_id'] = orgId;
                    param['space_id'] = spaceId;
                    if (orgId && spaceId && conf) {
                        self.delSpace(param, function (res) {
                            if (res) {
                                if (res.status === 'ok') {
                                    alert('删除成功!');
                                    self.reload();
                                }
                                else {
                                    alert('删除失败！' + res.msg);
                                }
                            }
                            else {
                                alert('服务异常，稍后再试');
                            }
                        });
                    }
                });

                opts.content.delegate('.addapp', 'click', function () {
                    var data = JSON.parse($(this).parents('tr').attr('data-str'));
                    self.getAppList(function (res) {
                        var d = {
                            spaces: res.spaces_all
                        };
                        d['space_id'] = data.id;
                        d['org_id'] = data.org;
                        renderAddApp(self.opts.content, d);
                        self.pageContent.hide();
                    });
                });

                opts.content.delegate('.appDelay', 'click', function () {
                    var data = JSON.parse($(this).parents('tr').attr('data-str'));
                    self.delayApp(data.id, function (res) {
                        if (res.success === 'true' || res.success === true) {
                            alert('APP已经成功续期30天！');
                        }
                        else {
                            alert('续期失败,原因' + res.msg);
                        }
                    });
                });
            },
            delayApp: function (spaceId, callback) {
                var param = {};
                param['space_id'] = spaceId;
                this.opts.doajax(this.opts.actions.delay_app, param, 'json', function (res) {
                    if (res) {
                        callback && callback(res);
                    }
                    else {
                        alert('服务调整中，稍后再试');
                    }
                });
            },
            reload: function () {
                this.appList = {};
                location.hash = '#/myspace/1!r=' + Math.random();
            },
            renderSpaceAuthList: function (spaceId) {
                var self = this;
                self.getSpaceAuthList(spaceId, function (res) {
                    renderAuthList(self.opts.content, res);
                    self.pageContent.hide();
                });
            },
            deleteSpaceAuth: function (data, callback) {
                this.opts.loading.show();
                this.opts.doajax(this.opts.actions.delete_space_auths, data, 'json', function (res) {
                    callback && callback(res);
                }, true);
            },
            doSearch: function (keyword, type) {
                var self = this;
                this.getAppList(function (res) {
                    renderAppList(self.opts.content, res);
                    if (maxLen > 1 && !res.key) {
                        self.pageUtil.render({
                            len: maxLen,
                            current: 1
                        });
                        self.pageContent.show();
                    }
                    else {
                        self.pageContent.hide();
                    }
                }, 1, keyword, type);
            },
            render: function (panel, params) {
                var page = parseInt(params[0], 10);
                if (!page || page === 'NaN') {
                    page = 1;
                }
                var self = this;
                this.getAppList(function (res) {
                    renderAppList(self.opts.content, res);
                    maxLen = Math.ceil(res.len / self.size);
                    self.renderStatus();
                    if (maxLen > 1) {
                        self.pageUtil.render({
                            len: maxLen,
                            current: page
                        });
                        self.pageContent.show();
                    }
                    else {
                        self.pageContent.hide();
                    }
                }, page);
            },
            renderStatus: function () {
                this.getStatus(function (res) {
                    $('.xplat_app_wrap').each(function () {
                        var app = $(this).attr('data-appname');
                        var space = $(this).attr('data-spacename');
                        var flag = false;
                        for (var i in res) {
                            if (i === space) {
                                for (var j = 0; j < res[i].length; j++) {
                                    if (res[i][j] === app) {
                                        // 已经推了
                                        flag = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (!flag) {
                            $(this).html('等待首次发布');
                        }
                        else {
                            $(this).html('');
                        }
                    });
                });
            },
            getStatus: function (callback) {
                var self = this;
                if (!this.statusList) {
                    this.opts.doajax(this.opts.actions.xplat_get_apps_by_org, {
                        org: this.opts.org.name
                    }, 'json', function (res) {
                        if (res && res[0]) {
                            self.statusList = res[0];
                            callback && callback(res[0]);
                        }

                    });
                }
                else {
                    callback && callback(this.statusList);
                }
            },
            getAppList: function (callback, page, keyword, type) {
                var self = this;
                page = page || 1;
                var key = page + '|' + keyword + '|' + type;
                if (this.appList[key]) {
                    callback && callback(this.appList[key]);
                }
                else {
                    var param = {
                        size: this.size,
                        page: page,
                        keyword: keyword,
                        type: type
                    };
                    param['org_id'] = this.opts['org_id'];
                    this.opts.doajax(this.opts.actions.get_user_spaces, param, 'json', function (res) {
                        if (res) {
                            self.appList = {};
                            self.appList[key] = res;
                            callback && callback(res);
                        }
                        else {
                            alert('服务调整中，稍后再试');
                        }
                    });
                }
            },
            getSpaceAuthList: function (spaceId, callback) {
                var param = {};
                param['space_id'] = spaceId;
                this.opts.doajax(this.opts.actions.get_space_auth_list, param, 'json', function (res) {
                    if (res && res.status === 'ok') {
                        callback && callback(res);
                    }
                    else {
                        alert('服务调整中，稍后再试');
                    }
                });
            },
            editorSpaceAuth: function (data, callback) {
                this.opts.loading.show();
                this.opts.doajax(this.opts.actions.editor_space_auths, data, 'json', function (res) {
                    callback && callback(res);
                }, true);
            },
            addSpace: function (data, callback) {
                this.opts.doajax(this.opts.actions.add_space, data, 'json', function (res) {
                    callback && callback(res);
                });
            },
            addApp: function (data, callback) {
                this.opts.doajax(this.opts.actions.add_app, data, 'json', function (res) {
                    callback && callback(res);
                });
            },
            delSpace: function (data, callback) {
                this.opts.doajax(this.opts.actions.del_space, data, 'json', function (res) {
                    callback && callback(res);
                });
            },
            delApp: function (data, callback) {
                this.opts.doajax(this.opts.actions.del_app, data, 'json', function (res) {
                    callback && callback(res);
                });
            }
        };
    /***************************************************************************************静态方法**************/
    // 输出列表
    function renderAppList(box, data) {
        box.html($.tmpl($('#tmpl_mySpaceList').val(), {
            me: data
        }));
    }
    // add space
    function renderAddSpace(box, data) {
        box.html($.tmpl($('#tmpl_addSpace').val(), {
            me: data
        }));
    }
    // add app
    function renderAddApp(box, data) {
        box.html($.tmpl($('#tmpl_addApp').val(), {
            me: data
        }));
    }
    // auths list
    function renderAuthList(box, data) {
        box.html($.tmpl($('#tmpl_myAuthList').val(), {
            me: data
        }));
    }
    $.myUser = $.myUser || {};
    $.myUser.MySpace = MySpace;
}(jQuery));