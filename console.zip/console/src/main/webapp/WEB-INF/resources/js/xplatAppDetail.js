﻿/**
 * xPlat app detail
 *@Require jQuery
 */


;
(function ($) {
    var currentAppId = $("#currentAppId").attr("data-id");
    var pageInit = {};
    var size = 5;
    var formIns = $.myUtil.form();
    var sortNames = $('#shortnames').attr('data-shortname').split(',');
    function init() {
        initHelpText();
        var data = initData();
        console.info("running:");
        console.info(data);
        if (data && data.instance && data.instance.length > 0) {
            renderBase(data.instance);
            initSmartBns();
            addEvent();
            stopAppVersion();
        }
        for (var i = 0; i < sortNames.length; i++) {
            renderCarshIns(0, sortNames[i]);
        } 
    }

    function renderCarshIns(start, shortname) {
        start = start || 0;
        var end = start + size - 1;
        var url = '/xplatfe/api2/xplat_get_crashed_instances?app_id=' + currentAppId + '&start=' + start +
            '&end=' + end + '&shortname=' + shortname;
        $.ajax({
            url: url,
            success: function (res) {
                console.info("stopping:");
                console.info(res);
                if (!res) {
                    return;
                }
                initPages(res.size, shortname);
                res.data = parseData(res.data);
                renderCarshInstance(res, shortname);
            }
        })
    }

    function addEvent() {
        $(".btnViewInstance").bind("click", function () {
            var modalObj = $("#show_instance");
            var modalBody = modalObj.find(".modal-body");
            var modalHead = modalObj.find(".modal-header");
            var ins = JSON.parse($(this).attr("data-ins"));
            var appname = $(this).attr("data-appname");
            var cluster = $(this).attr("data-cluster");
            var clusterName = $(this).attr("data-clusterName");
            modalBody.html($.tmpl($("#tmplIns").val(), {
                me: ins,
                clusterName: clusterName,
                cluster: cluster
            }));
            modalHead.html(
                '<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button><h4 class="modal-title">' +
                appname + ' ( ' + cluster + ' )</h4>')
            modalObj.modal();
        });

        $(".btn_show_push_help").bind("click", function () {
            var target = $(this).attr("data-target");
            $("#show_push_help").modal();
            $("#help_target").html("-a " + target);
        })
    }

    function stopAppVersion() {
        $(".btn_stop_app_version").bind("click", function () {
            var conf = window.confirm("确定要停止吗？");
            if (!conf) {
                return;
            }
            var that = this;
            $(this).attr("value", "停止中..").attr("disabled")
            var version = $(this).attr("data-version");
            var cluster_name = $(this).attr("data-cluster_name");
            $.ajax({
                url: "/xplatfe/api2/update_app_state?app_id=" + currentAppId + "&version=" +
                    version + "&cluster_name=" + cluster_name,
                success: function (res) {
                    $(that).attr("value", "停止").removeAttr("disabled");
                    if (res && res.State == "success") {
                        alert("操作成功！由于采集延时，请30秒后再刷新页面查看app状态");
                    } else {
                        var desc = res ? res.Description : "";
                        alert("操作失败，原因:" + desc);
                    }
                }
            })
        });
        $("#show_instance").delegate(".btn_restart_instance", "click", function () {
            var conf = window.confirm("确定要重启吗？");
            if (!conf) {
                return;
            }
            var that = this;
            $(this).attr("value", "重启中..").attr("disabled")
            var version = $(this).attr("data-version");
            var cluster_name = $(this).attr("data-cluster_name");
            var instance_index = $(this).attr("data-instance_index");
            $.ajax({
                url: "/xplatfe/api2/restart_instance?app_id=" + currentAppId + "&version=" +
                    version + "&cluster_name=" + cluster_name + "&instance_index=" +
                    instance_index,
                success: function (res) {
                    $(that).attr("value", "重启").removeAttr("disabled");
                    if (res && res.State == "success") {
                        alert("操作成功！由于采集延时，请30秒后再刷新页面查看app状态");
                    } else {
                        var desc = res ? res.Description : "";
                        alert("操作失败，原因:" + desc);
                    }
                }
            })
        });

    }

    function parseData(res) {
        if (res.length <= 0) {
            return;
        }
        var hash = {};
        for (var i = 0; i < res.length; i++) {
            var app_name = res[i].app_name;
            if (!hash[app_name]) {
                hash[app_name] = [];
            }
            hash[app_name].push(res[i]);
        }
        return hash;
    }

    function initPages(total, shortname) {
        if (pageInit[shortname]) {
            return;
        }
        pageInit[shortname] = true;
        $.myUtil.page({
            obj: $('#' + shortname + 'PageContent'),
            len: Math.ceil(total / size),
            current: 1,
        });
        $('#' + shortname + 'PageContent').bind('pageChange', function (e, page) {
            renderCarshIns(page * size - size, shortname);
        })
    }

    function renderBase(info) {
        $("#baseInfoContent").html($.tmpl($("#tmplBaseInfo").val(), {
            me: info
        }));
    };

    function renderCarshInstance(info, shortname) {
        $('#' + shortname + 'CarshContent').html($.tmpl($('#tmplCarsh').val(), {
            me: info,
            shortname: shortname
        }));
    }

    function initData() {
        var res = $("#appAllInfo").attr("data");
        res = res ? JSON.parse(res) : res;
        if (!res || $.isEmptyObject(res)) {
            return;
        }
        return {
            instance: res.instances,
            //原始信息
            data: res,
        }
    }

    function initHelpText() {
        var $lanMenu = $(".lanMenu");
        var $lanBlock = $(".lanBlock");
        var id = $lanMenu.find(".current").attr("data-id");
        $(".lanBlock[data-id='" + id + "']").css("display", "block");
        $lanMenu.find("a").bind("click", function () {
            id = $(this).attr("data-id");
            $lanMenu.find(".current").removeClass("current");
            $(this).addClass("current");
            $lanBlock.hide();
            $(".lanBlock[data-id='" + id + "']").css("display", "block");
        })
    }

    function initSmartBns() {
        var flag = true;
        $(".btn-show-bnstag").bind("click", function () {
            var td = $(this).parents('td');
            $("#show_bnstag").modal();
            $(".edit-smart-bns")
                .attr("data-appid", td.attr("data-appid"))
                .attr('data-cluster', td.attr('data-cluster'))
                .attr('data-appname', td.attr('data-appname'));
        })
        //设置bns
        $(".set-smart-bns").bind("click", function () {
                if (!flag) {
                    return;
                }
                flag = false;
                var td = $(this).parents('td');
                submitBns({
                    app_id: td.attr("data-appid"),
                    short_name: td.attr('data-cluster'),
                    app_version: td.attr('data-appname')
                }, function (res) {
                    flag = true;
                    if (res && res.success === true) {
                        alert("设置成功!");
                        location.reload();
                    } else {
                        alert("设置失败!");
                    }
                })
            })
            //修改
        $(".edit-smart-bns").bind("click", function () {
                if (!flag) {
                    return;
                }
                flag = false;
                var bnsTag = $(".bns-tag-input").val();
                submitBns({
                    app_id: $(this).attr("data-appid"),
                    short_name: $(this).attr('data-cluster'),
                    app_version: $(this).attr('data-appname'),
                    bns_tag: bnsTag
                }, function (res) {
                    flag = true;
                    if (res && res.success === true) {
                        alert("修改成功!");
                        location.reload();
                    } else {
                        alert("修改失败!");
                    }
                })
            })
            //取消bns
        $(".cancel-smart-bns").bind("click", function () {
            var conf = window.confirm('确定要取消智能BNS?');
            if (!conf) {
                return;
            }
            if (!flag) {
                return;
            }
            flag = false;
            var td = $(this).parents('td');
            submitBns({
                app_id: td.attr("data-appid"),
                short_name: td.attr('data-cluster'),
                app_version: td.attr('data-appname'),
                status: 'False'
            }, function (res) {
                flag = true;
                if (res && res.success === true) {
                    alert("取消成功!");
                    location.reload();
                } else {
                    alert("取消失败!");
                }
            })
        })

        function submitBns(data, callback) {
            $.ajax({
                url: "/xplatfe/api2/setSmartBns",
                data: data,
                success: function (res) {
                    callback && callback(res);
                }
            })
        }
    }
    init();
}(jQuery));



//APP 重启
(function ($) {
    var currentAppId = $('#currentAppId').attr('data-id');
    var btnAppRestarts = $('.btn-app-restart');
    var autoPushApi = $('#autopush-api').attr('data-api');
    var viewHistoryContent = $('#view-history-content');
    var historyPageContent = $('#historyPageContent');
    var btnAppHistory = $('.btn-app-history');
    var timer = null,
        loading = null,
        pageObj = null;

    function init() {
        //初始化时去拿一下状态
        getState(function (res) {
            renderButton(res.state, res.target, res.version);
            if (res.state && res.state.indexOf('_PROCESSING') !== -1) {
                startTimer();
            }
        });
        //绑定重启按钮
        btnAppRestarts.bind('click', function () {
            var _text = $(this).text();
            var _shortName = $(this).attr('data-cluster-shortname');
            var _target = $(this).attr('data-target');
            var _version = $(this).attr('data-version');
            if (!window.confirm('确定要重启集群' + _shortName + '上的版本' + _version + '吗？')) {
                return false;
            }
            renderButton('RESTART_PROCESSING', _target, _version);
            $.ajax({
                url: '/xplatfe/api2/app_operate_v2',
                data: {
                    app_id: currentAppId,
                    target: _target,
                    app_version: _version
                },
                success: function (res) {
                    console.log(res);
                    if (res && res.code === 1) {
                        startTimer();
                    } else {
                        alert('重启失败, 原因' + (res && res.msg));
                        renderButton('RESTART_FAILED', _target, _version);
                    }
                }
            })
        });
        //重启历史
        btnAppHistory.bind('click', function () {
            if (!loading) {
                loading = $.myUtil.loading({
                    initShow: false,
                    parent: viewHistoryContent.find('.modal-body')
                })
            }
            loading.show();
            viewHistoryContent.modal();
            viewHistoryContent.find('table').html('');
            curPage = 1;
            getHistory(curPage);
        });
        //翻页
        historyPageContent.bind('pageChange', function (e, page) {
            loading.show();
            getHistory(page);
        })
    }

    init();

    function renderButton(state, target, version) {
        current = posElement(target, version);
        var match = state.match(/_[a-zA-Z\-0-9]+$/);
        if (!state) {
            console.warn('match state error, state:' + state);
            return;
        }
        switch (match[0]) {
        case '_PROCESSING':
            btnAppRestarts.attr('disabled', 'disabled');
            current && current.html('重启中...');
            break;
        case '_SUCCESS':
        case '_FAILED':
            btnAppRestarts.removeAttr('disabled');
            current && current.html('重启');
            break;

        }
    }

    function getHistory(_page, _size) {
        _size = _size || 10;
        $.ajax({
            url: autoPushApi + '/autopush/api/apps/operation/all/?app_id=' + currentAppId,
            data: {
                page: _page,
                size: _size
            },
            dataType: 'jsonp',
            success: function (res) {
                renderHistory(res);
                if (!pageObj && res) {
                    pageObj = $.myUtil.page({
                        current: _page,
                        len: Math.ceil(res["length"] / _size),
                        obj: historyPageContent
                    });
                }
                loading && loading.hide();
            }
        })
    }

    function renderHistory(res) {
        viewHistoryContent.find('table').html($.tmpl($('#tmplHistory').val(), {
            me: res.data
        }));
    };

    function posElement(target, version) {
        for (var i = 0; i < btnAppRestarts.length; i++) {
            var $this = btnAppRestarts.eq(i);
            if ($this.attr('data-target') === target && $this.attr('data-version') === version) {
                return $this;
            }
        }
        return null;
    }

    function getState(callback) {
        $.ajax({
            url: autoPushApi + '/autopush/api/apps/operation/' + currentAppId,
            dataType: 'jsonp',
            success: function (res) {
                console.log(res);
                callback && callback(res);
            }
        })
    };

    function startTimer() {
        timer = setInterval(function () {
            getState(function (res) {
                timer && renderButton(res.state, res.target, res.version);
                if (!res.state || res.state.indexOf('_PROCESSING') === -1) {
                    clearInterval(timer);
                    timer = null;
                    if (res.state.indexOf('_SUCCESS')) {
                        alert("重启成功!");
                        location.reload();
                    } else {
                        alert("重启失败!");
                    }
                }

            })
        }, 2000)
    };
}(jQuery))