﻿(function($, win, undeined){
/***********************************************************************************app列表****************/
	var AllSpace = function(opts){
		this.size = 5;
		this.pageContent = $("#page_content");
		this.pageUtil = $.myUtil.page({
			obj:this.pageContent,
			initShow:false,
			doRender:false
		})
		this.appList = {};
		this.clusters = null;
		this.init(opts);
	}
	AllSpace.prototype = {
		init:function(opts){
			console.log("List init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			this.pageContent.bind("pageChange", function(res,data){
                if(location.hash.indexOf("list") != -1){
                    location.hash="/list/"+data
                }
			})
			_opts.content.delegate(".btn_search_list", "click",function(){
				var data = _this.opts.formIns.getForm($(this));
				_this.doSearch(data.keyword, data.type)
			});
            _opts.content.delegate(".editorRole","click",function(){
                var data = JSON.parse($(this).parents("tr").attr("data-str"));
                var space_id = data.id;
                _this.renderSpaceAuthList(space_id);
            });
		},
		reload:function(){
			this.appList = {};
			location.hash = "#/list/1!r="+Math.random()
		},
        renderSpaceAuthList:function(space_id){
            var _this = this;
            _this.getSpaceAuthList(space_id, function(res){
                renderAuthList(_this.opts.content, res);
                _this.pageContent.hide();
            })
        },
		doSearch:function(keyword, type){
			var _this = this;
			this.getAppList(function(res){
				renderAppList(_this.opts.content, res);
				if(max_len > 1 && !res.key){
					_this.pageUtil.render({
						len:max_len,
						current:1
					})
					_this.pageContent.show();
				}else{
					_this.pageContent.hide();
				}
			},1,keyword,type);
		},
		render:function(panel, params){
			var page = parseInt(params[0])
			if(!page || page == "NaN"){
				page = 1;
			}
			var _this = this;
			this.getAppList(function(res){
				renderAppList(_this.opts.content, res);
				max_len = Math.ceil(res.len/_this.size)
				if(max_len > 1){
					_this.pageUtil.render({
						len:max_len,
						current:page
					})
					_this.pageContent.show();
				}else{
					_this.pageContent.hide();
				}
			},page);
		},
		getAppList:function(callback, page, keyword, type){		
			var _this = this;
            page = page || 1;
			var key = page+"|"+keyword+"|"+type;
			if(this.appList[key]){
				callback && callback(this.appList[key]);
			}else{
				this.opts.doajax(this.opts.actions.get_app_manager_info, {org_id:this.opts.org_id, size:this.size, page:page,keyword:keyword,type:type}, "json", function(res){
					if(res){
						_this.appList = {};
						_this.appList[key] = res;
						callback && callback(res);
					}else{
						alert("服务调整中，稍后再试");
					}
				})
			}
		},
        getSpaceAuthList:function(space_id, callback){
            var _this = this;
            this.opts.doajax(this.opts.actions.get_space_auth_list, {space_id:space_id}, "json", function(res){
                if(res && res["status"] == "ok"){
                    callback && callback(res);
                }else{
                    alert("服务调整中，稍后再试");
                }
            })
        },

	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderAppList(box, data){
		box.html($.tmpl($("#tmpl_appList").val(),{me:data}));
	}

    //auths list
    function renderAuthList(box, data){
        box.html($.tmpl($("#tmpl_authList").val(),{me:data}));
    }
	$.myUser = $.myUser || {};
	$.myUser.AllSpace = AllSpace;
 }(jQuery));