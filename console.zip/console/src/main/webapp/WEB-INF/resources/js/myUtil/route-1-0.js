/**
*@Require jQuery
*@Version 1-0
*@NameSpace $.myUtil.route
*/
; (function($){
	var Route = function(opt){
		var _default = {
			url:null,
			onLocationChange:function(){}
			//TODO
		};
		this._inited = false;
		this._opt = null;
		_default = $.extend(_default, opt);
		if(_default.url){
			this._init(_default);
		}
	};
	Route.prototype = {
		_init:function(opt){
			this._opt = opt;
			this._addEvent();
			this._inited = true;
		},
		_addEvent:function(){
			var _this = this;
			var defEvent = "hashChange";
			$(document).bind(defEvent, function(e){	
				_this._parseLocation(location.hash);
			});
			$(function(){
				$(document).trigger(defEvent);
			});
			$(document).delegate("a", "click", function(){
				var href = $(this).attr("href");
				if(href && href.indexOf("#") == 0){
					location.hash = href;
					$(document).trigger(defEvent);
					return false;
				}
			});
		},
		/**
		*url����
		*/
		_parseLocation:function(str){
			var url = this._opt.url;
			var reg;
			str = str.replace("#","");
			for(var i in url){
				reg = new RegExp(i);
				//ƥ�䵽����
				if(reg.test(str)){					
					var panel = url[i];
					console.log(panel);
					var param = this._parseSearch(location.search);
					//�ص�����panel,param
					this._opt.onLocationChange && this._opt.onLocationChange(panel, param);
					$(document).trigger("locationChange", [url[i],param]);
					break;
				}
			}
		},
		/**
		*location.search����,�磺?a=xx&b=xx -> {a:xx,b:xx}
		*/
		_parseSearch:function(search){
			var arr = [];
			var params = {};
			var keyVal = [];
			if(search){
				search = search.replace("?","");
				arr = search.split("&");
				for(var i = 0; i < arr.length; i++){
					keyVal = arr[i].split("=");
					if(keyVal){
						params[keyVal[0]] = keyVal[1];
					}
				}
			}
			return params;
		},
		//��ȡ����״̬���Ƿ��ʼ��
		getStatus:function(){
			return this._inited;
		}
	}
	$.myUtil = $.myUtil || {};
	$.myUtil.route = function(opt){
		return new Route(opt);
	}
}(jQuery))