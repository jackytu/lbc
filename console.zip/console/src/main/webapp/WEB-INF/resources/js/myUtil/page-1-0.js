﻿/**
 *@Require jQuery.js
 *@Require Tmpl.js
 *翻页组件
 *@Return $.myUtil.page.js
 * add by zzx
 */
; (function($){
	var templete = {
        page:'<ul class="pagination" style="margin:0;">\
        <li class="pages_prev"><a href="javascript:;"><</a></li>\
        <%if(me.current == 1){%>\
            <li class="active" data-index="1"><a href="javascript:;">1</a></li>\
        <%}else{%>\
            <li class="pages_item" data-index="1"><a href="javascript:;">1</a></li>\
        <%}%>\
        <%for(var i = 2; i <me.len; i++){var _me = me.len;var _sub = me.current - i;%>\
            <%if(_sub <= 2 && _sub >= -3){%>\
                <%if(_sub == 2 || _sub == -3){%>\
                    <li><a href="javascript:;">...</a></li>\
                <%}else if(_sub == 0){%>\
                    <li class="active" data-index="<%=i%>"><a href="javascript:;"><%=i%></a></li>\
                <%}else{%>\
                    <li class="pages_item" data-index="<%=i%>"><a href="javascript:;"><%=i%></a></li>\
                <%}%>\
            <%}%>\
        <%}%>\
        <%if(me.len > 1){%>\
            <%if(me.current == me.len){%>\
                <li class="active" data-index="<%=me.len%>"><a href="javascript:;"><%=me.len%></a></li>\
            <%}else{%>\
                <li class="pages_item" data-index="<%=me.len%>"><a href="javascript:;"><%=me.len%></a></li>\
            <%}%>\
        <%}%>\
        <li class="pages_next"><a href="javascript:;">></a></li>\
     </ul>',
	}
	var Page = function(opts){
		var _opts = {
            obj:null,
            len:1,
            current:1,
			initShow:true,
			doRender:true
		}
		$.extend(_opts, opts);
		this.opts = _opts;
		
		this.init();
	}
	Page.prototype = {
		init:function(){
			var _opts = this.opts;
			var _this = this;
            if(!_opts.obj || _opts.len < 1){
                return
            }
            var data = {
                len:_opts.len,
                current:_opts.current
            }
			this.addedEvent = false;
            _opts.initShow && this.render(data);    
		},
        addEvent:function(){
            var data = {
                len:this.opts.len,
                current:parseInt(this.opts.current)
            }
			this.addedEvent = true;
            var _this = this;
            this.opts.obj.delegate(".pages_item","click",function(){
                var index = $(this).attr("data-index");
                data["current"] = parseInt(index);
                _this.opts.doRender && _this.render(data);
                _this.opts.obj.trigger("pageChange",data["current"]);
            })
            this.opts.obj.delegate(".pages_prev","click",function(){
                if(data["current"] >= 2){
                    data["current"] = data["current"] - 1;
                    _this.opts.doRender && _this.render(data);
                    _this.opts.obj.trigger("pageChange",data["current"]);
                }
            })
            this.opts.obj.delegate(".pages_next","click",function(){
                if(data["current"]+1 <= _this.opts.len){
                    data["current"] = data["current"] + 1;
                   _this.opts.doRender &&  _this.render(data);
                    _this.opts.obj.trigger("pageChange",data["current"]);
                }
            })
        },
        render:function(data){
            this.opts.len = data.len;
			this.opts.current = data.current;
			if (!this.addedEvent){
				this.addEvent();
			}
            this.opts.obj.html($.tmpl(templete.page,{me:data}));
        }
        
	}
	$.myUtil = $.myUtil || {};
	$.myUtil.page = function(opts){
		return new Page(opts);
	}
}(jQuery))
