(function($, win, undeined){
/***********************************************container监控***********************************************************/
    var ContainerMinitor = function(opts){
		this.init(opts);
	}
	ContainerMinitor.prototype = {
        init:function(opts){
            console.log("container init");
            this.opts = opts;
            this.addEvent();
        },
        addEvent:function(){
        var _this = this;
        var _opts = _this.opts;
        //添加raw
        _opts.panelBox.delegate(".btn_add_container_raw","click",function(){
            var _rawKey = $(this).attr("data-rawKey");
            var _name = $(this).attr("data-name");
            var _target = $(this).attr("data-target");
            var _cycle = $(this).attr("data-cycle");
            if(_rawKey && _name){
                _this.rawKey = _rawKey;
                _this.rawName = _name;
                _this.target = _target;
                _this.cycle = _cycle;
                renderAddContainerRaw(_opts.panelBox, {
                    raw_key:_rawKey,
                    name:_name,
                    target:_target,
                    cycle:_cycle,
                    type:"mod"
                });
            }else{
                renderAddContainerRaw(_opts.panelBox);
            }
		})


        _opts.panelBox.delegate(".btn_render_raw_list","click",function(){
			_this.render(null);
		})
		//提交raw
		_opts.panelBox.delegate(".btn_submit_container_raw","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                _this.submitRaw(data);
            }
        });
        //提交alert
        _opts.panelBox.delegate(".btn_submit_container_alert","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                _this.submitAlert(data);
            }
        });
        //提交rule
        _opts.panelBox.delegate(".btn_submit_container_rule","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                data.disable_time = data.disable_time.replace(",","-");
                _this.submitRule(data);
            }
        });
        /*no need to mod raw
        //修改raw
        _opts.panelBox.delegate(".btn_mod_container_raw","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                _this.modRaw(data);
            }
        });
        */
        //获取raw
        _opts.panelBox.delegate(".btn_get_container_raw","click",function(){
            renderAddContainerRaw(_opts.panelBox, {
                raw_key:_this.rawKey,
                name:_this.rawName,
                target:_this.target,
                cycle:_this.cycle,
                type:"mod"
            });
        })
        //获取alert
        _opts.panelBox.delegate(".btn_get_container_alert","click",function(){
            _this.getAlert();
        })
        //获取rule list
        _opts.panelBox.delegate(".btn_get_container_rule","click",function(){
            var rawKey = $(this).attr("data-rawKey");
            var rawName = $(this).attr("data-name");
            var target = $(this).attr("data-target");
            var cycle = $(this).attr("data-cycle");
            if(rawKey && rawName){
                _this.rawKey = rawKey;
                _this.rawName = rawName;
                _this.target = target;
                _this.cycle = cycle;
            }
            _this.getRule();
        })
        //获取rule list item
        _opts.panelBox.delegate(".btn_get_container_ruleItem","click",function(){
            var rule = null;
            try{
                rule = JSON.parse($(this).attr("data-rule"));
            }catch(e){}
            renderAddContainerRule(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName,rule:rule});
        })
        //修改alert
        _opts.panelBox.delegate(".btn_mod_container_alert","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                _this.modAlert(data);
            }
        });
        //添加rule
        _opts.panelBox.delegate(".btn_add_container_rule","click",function(){
            renderAddContainerRule(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName});
        });
        //修改rule
        _opts.panelBox.delegate(".btn_mod_container_rule","click",function(){
            var data = _opts.formIns.getForm($(this));
            if(data){
                data.disable_time = data.disable_time.replace(",","-");
                _this.modRule(data);
            }
        });
        //删除raw
        _opts.panelBox.delegate(".btn_del_container_raw","click",function(){
            var rawKey = $(this).attr("data-rawKey");
            _this.delRaw(rawKey);
        });
        //删除alert
        _opts.panelBox.delegate(".btn_del_container_alert","click",function(){
            _this.delAlert(_this.rawKey);
        });
        //删除rule
        _opts.panelBox.delegate(".btn_del_container_rule","click",function(){
            var ruleKey = $(this).attr("data-ruleKey");
            _this.delRule(ruleKey);
        });

        },//end addEvent

        render:function(panel, params){
			this.rawKey = null;
			var _this = this;
			this.getMonitor(function(res){
				renderMonitorList(_this.opts.panelBox, {list:res.raws});
				_this.get_container_query_status(function(parentType){
				    _this.containerStatus(parentType);
				});
			});
		},
		get_container_query_status:function(callback){
		    this.opts.get_mon_query_status(function(res,parentType){
		        if(parentType == true){//整体是屏蔽的
		            $(".btn_container_mon_screen").attr("disabled",true);//log监控的屏蔽不可用
		            $(".btn_container_mon_screen").css("background","#ADADAD");
		            $(".btn_container_un_mon_screen").attr("disabled",true);//log监控的解除不可用
                    $(".btn_container_un_mon_screen").css("background","#ADADAD");
		        }else{
		            //NOTHINGTODO
		        }
                callback && callback(parentType);
		    });
		},
		containerStatus:function(parentType){
		    var app_key = $("#hiddenAppKey").val();
		    var rule_name;
		    var _this = this;
		    $(".btn_container_mon_status_query").each(function(i){
		        var $this = $(this);
		        rule_name = $this.attr("data-rule_name");
                _this.doContainerAjax($this, rule_name, app_key, parentType);
		    })
		},
		doContainerAjax:function(_this,rule_name,app_key, parentType){
		    $.ajax({
                url:"/xplatfe/monitor/monitor_status_query/",
                data:{"app_key":app_key,"rule_name":rule_name},
                success:function(res){
                    if(parentType != true){//外面是解除状态
                        if(res && res.msg.block == "yes"){
                            _this.parents(".my_container_item").find(".btn_container_mon_screen").attr("disabled",true);//使屏蔽按钮不可用
                            _this.parents(".my_container_item").find(".btn_container_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_container_item").find(".btn_container_un_mon_screen").removeAttr("disabled");//使解除按钮可用
                            _this.parents(".my_container_item").find(".container_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                        }else{
                            _this.parents(".my_container_item").find(".btn_container_mon_screen").removeAttr("disabled");//使屏蔽按钮可用
                            _this.parents(".my_container_item").find(".btn_container_un_mon_screen").attr("disabled",true);//使解除按钮不可用
                            _this.parents(".my_container_item").find(".btn_container_un_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_container_item").find(".container_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/started.png" alt="started" />');
                        }
                    }else{
                        _this.parents(".my_container_item").find(".container_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                    }
                }
            });
		},
		submitRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.add_container_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}else if(res.raw_key){
					_this.rawKey = res.raw_key;
					_this.rawName = _data.name;
				}
				if(callback){
					callback(res);
				}else{
					renderAddContainerRule(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		/*
		modRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.mod_container_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},*/
		modAlert:function(data, callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.mod_container_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_sel;
			this.opts.doNewAjax(this.opts.actions.mod_container_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		submitAlert:function(data, callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.add_container_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		submitRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_sel;
			this.opts.doNewAjax(this.opts.actions.add_container_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					renderAddContainerAlert(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
					//_this.getRule();
				}
			})
		},
		getAlert:function(callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.get_container_alert, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _alert = res && res.alert ? res.alert : null;
					if(_alert){
						_alert = $.extend({
							rawKey:_this.rawKey,
							name:_this.rawName,
							type:"mod"
						},_alert)
					}else{
						_alert = {
							rawKey:_this.rawKey,
							name:_this.rawName,
						}
					}
					renderAddContainerAlert(_this.opts.panelBox, _alert);
				}
			},true)
		},
		getRule:function(callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.get_container_rule, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _rule = res && res.rules ? res.rules : [];
					renderGetContainerRule(_this.opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						rule:_rule
					});
				}
			},true)
		},
		getMonitor:function(callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.get_container_monitor_by_app_key, {app_key:this.opts.appkey}, function(res){
				if(callback){
					callback(res);
				}else{
					renderMonitorList(_this.opts.panelBox, res);
				}
			},true)
		},
		delRaw:function(rawKey, callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.del_container_raw,{raw_key:rawKey},function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delAlert:function(rawKey, callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.del_container_alert, {raw_key:rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delRule:function(ruleKey, callback){
			var _this = this;
			this.opts.doNewAjax(this.opts.actions.del_container_rule, {rule_key:ruleKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		}
    }
    /***********************************************静态方法******************************************************/
	//输出列表
	function renderMonitorList(box, data){
		box.html($.tmpl($("#tmpl_container_monitorList").val(),{me:data}));
	}
	//添加raw
	function renderAddContainerRaw(box, data){
		data = data || {};
		box.html($.tmpl($("#tmpl_addContainerRaw").val(),{me:data}));
	}
	//添加alert
	function renderAddContainerAlert(box, data){
		box.html($.tmpl($("#tmpl_addContainerAlert").val(),{me:data}));
	}
	//添加Rule
	function renderAddContainerRule(box, data){
		box.html($.tmpl($("#tmpl_addContainerRule").val(),{me:data}));
	}
	//获取rule列表
	function renderGetContainerRule(box, data){
		box.html($.tmpl($("#tmpl_getContainerRule").val(),{me:data}));
	}
	/**********************************************end静态方法******************************************************/

	$.myMonitor = $.myMonitor || {};
	$.myMonitor.ContainerMinitor = ContainerMinitor;
}(jQuery));