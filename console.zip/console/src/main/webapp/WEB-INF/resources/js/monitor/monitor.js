﻿/**
* xPlat app detail 监控的代码
*@Require jQuery
*/
(function($, win, undeined){
	var APPKEY = $("#hiddenAppKey").val();
    var ORGNAME = $("#hiddenOrgName").val();
    var SPACENAME = $("#hiddenSpaceName").val();
    var APPNAME = $("#hiddenAppName").val();
    var CLUSTERNAME = $("#hiddenClusterName").val();
	var Url = {		
		"^\/process\/?$":"process",
		"^\/domain\/?$":"domain",
		"^\/log\/?$":"log",
        "^\/jvm\/?$":"jvm",
        "^\/httpud\/?$":"httpud",
		"^\/userdf\/?$":"userdf",
        "^\/insnum\/?$":"insnum",
        "^\/container\/?$":"container",
		"^.*$":"domain"
	}
	var HOST = "http://monitor.jpaas.baidu.com:8002";
	//数据接口
	var Actions = {
		//获取进程监控数据	
		"get_proc_monitor_by_app_key":HOST+"/proc_monitor/get_proc_monitor_by_app_key",
		"add_proc_raw":HOST+"/proc_monitor/add_raw",
		"add_proc_alert":HOST+"/proc_monitor/add_alert",
		"add_proc_rule":HOST + "/proc_monitor/add_rule",
		"mod_proc_raw":HOST + "/proc_monitor/update_raw",
		"get_proc_raw":HOST + "/proc_monitor/get_alert_by_raw_key",
		"get_proc_rule":HOST + "/proc_monitor/get_rules_by_raw_key",
		"mod_proc_alert":HOST + "/proc_monitor/update_alert",
		"mod_proc_rule":HOST + "/proc_monitor/update_rule",
		"del_proc_raw":HOST + "/proc_monitor/del_raw",
		"del_proc_alert":HOST + "/proc_monitor/del_alert",
		"del_proc_rule":HOST + "/proc_monitor/del_rule",
		//域名监控
		"get_domain_monitor_by_app_key":HOST+"/domain_monitor/get_domain_monitor_by_app_key",
		"get_domain_raw":HOST + "/domain_monitor/get_alert_by_raw_key",
		"get_domain_rule":HOST + "/domain_monitor/get_rules_by_item_key",
		"get_domain_item":HOST + "/domain_monitor/get_item_by_raw_key",
		"add_domain_raw":HOST+"/domain_monitor/add_raw",
		"add_domain_alert":HOST+"/domain_monitor/add_alert",
		"add_domain_rule":HOST + "/domain_monitor/add_rule",
		"add_domain_item":HOST + "/domain_monitor/add_item",
		"mod_domain_raw":HOST + "/domain_monitor/update_raw",
		"mod_domain_alert":HOST + "/domain_monitor/update_alert",
		"mod_domain_rule":HOST + "/domain_monitor/update_rule",
		"mod_domain_item":HOST + "/domain_monitor/update_item",
		"del_domain_raw":HOST + "/domain_monitor/del_raw",
		"del_domain_alert":HOST + "/domain_monitor/del_alert",
		"del_domain_rule":HOST + "/domain_monitor/del_rule",
		"del_domain_item":HOST + "/domain_monitor/del_item",
		//日志监控
		"get_log_monitor_by_app_key":HOST+"/log_monitor/get_log_monitor_by_app_key",//app_key
		"get_log_raw":HOST + "/log_monitor/get_alert_by_raw_key",//raw_key
		"get_log_rule":HOST + "/log_monitor/get_rules_by_item_key",//item_key
		"get_log_item":HOST + "/log_monitor/get_item_by_raw_key",//raw_key
		"add_log_raw":HOST+"/log_monitor/add_raw",//name, log_filepath
		"add_log_alert":HOST+"/log_monitor/add_alert",//raw_key, max_alert_times, remind_interval_second, mail, sms
		"add_log_rule":HOST + "/log_monitor/add_rule",//item_key, name, compare, threshold, filter, disable_time
		"add_log_item":HOST + "/log_monitor/add_item",//raw_key, name, cycle, match_str,filter_str,match_type
		"mod_log_raw":HOST + "/log_monitor/update_raw",//raw_key, name, log_filepath
		"mod_log_alert":HOST + "/log_monitor/update_alert",//raw_key, max_alert_times, remind_interval_second, mail, sms
		"mod_log_rule":HOST + "/log_monitor/update_rule",//rule_key, name, compare, threshold, filter, disable_time
		"mod_log_item":HOST + "/log_monitor/update_item",//item_key, name, cycle, match_str
		"del_log_raw":HOST + "/log_monitor/del_raw",//raw_key
		"del_log_alert":HOST + "/log_monitor/del_alert",//raw_key
		"del_log_rule":HOST + "/log_monitor/del_rule",//rule_key
		"del_log_item":HOST + "/log_monitor/del_item",//item_key
        //JVM监控
		"get_jvm_monitor_by_app_key":HOST+"/http_user_defined_monitor/get_http_user_defined_monitor_by_app_key",
		"add_jvm_raw":HOST+"/http_user_defined_monitor/add_raw",
		"add_jvm_alert":HOST+"/http_user_defined_monitor/add_alert",
		"add_jvm_rule":HOST + "/http_user_defined_monitor/add_rule",
		"mod_jvm_raw":HOST + "/http_user_defined_monitor/update_raw",
		"get_jvm_raw":HOST + "/http_user_defined_monitor/get_alert_by_raw_key",
		"get_jvm_rule":HOST + "/http_user_defined_monitor/get_rules_by_raw_key",
		"mod_jvm_alert":HOST + "/http_user_defined_monitor/update_alert",
		"mod_jvm_rule":HOST + "/http_user_defined_monitor/update_rule",
		"del_jvm_raw":HOST + "/http_user_defined_monitor/del_raw",
		"del_jvm_alert":HOST + "/http_user_defined_monitor/del_alert",
		"del_jvm_rule":HOST + "/http_user_defined_monitor/del_rule",
        //http自定义监控
        "get_httpud_monitor_by_app_key":HOST+"/http_user_defined_monitor/get_http_user_defined_monitor_by_app_key",
		"add_httpud_raw":HOST+"/http_user_defined_monitor/add_raw",
		"add_httpud_alert":HOST+"/http_user_defined_monitor/add_alert",
		"add_httpud_rule":HOST + "/http_user_defined_monitor/add_rule",
		"mod_httpud_raw":HOST + "/http_user_defined_monitor/update_raw",
		"get_httpud_raw":HOST + "/http_user_defined_monitor/get_alert_by_raw_key",
		"get_httpud_rule":HOST + "/http_user_defined_monitor/get_rules_by_raw_key",
		"mod_httpud_alert":HOST + "/http_user_defined_monitor/update_alert",
		"mod_httpud_rule":HOST + "/http_user_defined_monitor/update_rule",
		"del_httpud_raw":HOST + "/http_user_defined_monitor/del_raw",
		"del_httpud_alert":HOST + "/http_user_defined_monitor/del_alert",
		"del_httpud_rule":HOST + "/http_user_defined_monitor/del_rule",
        //自定义监控
		"get_userdf_monitor_by_app_key":HOST+"/user_defined_monitor/get_user_defined_monitor_by_app_key",
		"add_userdf_raw":HOST+"/user_defined_monitor/add_raw",
		"add_userdf_alert":HOST+"/user_defined_monitor/add_alert",
		"add_userdf_rule":HOST + "/user_defined_monitor/add_rule",
		"mod_userdf_raw":HOST + "/user_defined_monitor/update_raw",
		"get_userdf_raw":HOST + "/user_defined_monitor/get_alert_by_raw_key",
		"get_userdf_rule":HOST + "/user_defined_monitor/get_rules_by_raw_key",
		"mod_userdf_alert":HOST + "/user_defined_monitor/update_alert",
		"mod_userdf_rule":HOST + "/user_defined_monitor/update_rule",
		"del_userdf_raw":HOST + "/user_defined_monitor/del_raw",
		"del_userdf_alert":HOST + "/user_defined_monitor/del_alert",
		"del_userdf_rule":HOST + "/user_defined_monitor/del_rule",
        //运行实例数量监控
        "get_insnum_monitor":HOST + "/get_instance_num_monitor",
        "mod_insnum_monitor":HOST + "/update_instance_num_monitor",
        "add_insnum_monitor":HOST + "/add_instance_num_monitor",
        "del_insnum_monitor":HOST + "/delete_instance_num_monitor",
        //"tef_insnum_monitor":HOST + "/take_effect?app_key=c9832ed4fa4aa0163d0455e82acfcae8&no_jpaas=yes",

        //container资源监控
        "get_container_monitor_by_app_key":"/xplatfe/monitor/get_container_monitor_by_app_key/",
        "get_container_alert":"/xplatfe/monitor/get_container_alert_by_raw_key/",
		"get_container_rule":"/xplatfe/monitor/get_container_rules_by_raw_key/",

		"add_container_raw":"/xplatfe/monitor/add_container_raw/",
		"add_container_rule":"/xplatfe/monitor/add_container_rule/",
        "add_container_alert":"/xplatfe/monitor/add_container_alert/",

		// no need to update container raw
		"mod_container_rule":"/xplatfe/monitor/update_container_rule/",
		"mod_container_alert":"/xplatfe/monitor/update_container_alert/",

		"del_container_raw":"/xplatfe/monitor/del_container_raw/",
		"del_container_rule":"/xplatfe/monitor/del_container_rule/",
		"del_container_alert":"/xplatfe/monitor/del_container_alert/",

		//生效
		//"take_effect":HOST + "/take_effect",
		"all_monitor_status_query":"/xplatfe/monitor/all_monitor_status_query/"
	}
	var panelBox = $("#mon_content");
	var loading = $.myUtil.loading({parent:$("#mon_content_warp"),initShow:false});
	var formIns = $.myUtil.form();
	
	var opts = {
		actions:Actions,
		appkey:APPKEY,
        orgName:ORGNAME,
        spaceName:SPACENAME,
        appName:APPNAME,
        clusterName:CLUSTERNAME,
		panelBox:panelBox,
		formIns:formIns,
		doAjax:doAjax,
		doNewAjax:doNewAjax,
		get_mon_query_status:get_mon_query_status
	}
	var Monitor = {
		process:{
			init:function(){
				return new $.myMonitor.ProcessMinitor(opts);
			}
		},
		domain:{
			init:function(){
				return new $.myMonitor.DomainMinitor(opts);
			}
		},
		log:{
			init:function(){
				return new $.myMonitor.LogMinitor(opts);
			}
		},
        jvm:{
			init:function(){
				return new $.myMonitor.JvmMinitor(opts);
			}
		},
        httpud:{
            init:function(){
                return new $.myMonitor.HttpudMinitor(opts);
            }
        },
		userdf:{
			init:function(){
				return new $.myMonitor.UserdfMinitor(opts);
			}
		},
        insnum:{
            init:function(){
                return new $.myMonitor.InsnumMinitor(opts);
            }
        },
        container:{
            init:function(){
                return new $.myMonitor.ContainerMinitor(opts);
            }
        }
	};
	
	//主方法
	function main(){
		if(!APPKEY || APPKEY == "None"){
			return;
		}
		$.myUtil.route({ 
			url:Url,
			onLocationChange:function(panel, params){
				if(!panel && !Monitor[panel]){
					return;
				}
				if(!Monitor[panel].ins){
					Monitor[panel].ins = Monitor[panel].init();
				}
				if(panel){
					renderMenu({"panel":panel});
				}
				Monitor[panel].ins.render(panel, params);
			}
		});
		/*
		panelBox.delegate(".btn_take_effect","click",function(){
			take_effect();
		})*/
	}
    main();
	

	
	/*************************************************************************************自定义监控**************/
	var CustomMinitor = function(){
		this.init();
	}
	CustomMinitor.prototype = {
		init:function(){
			console.log("custom init");
		},
		render:function(panel, params){
			renderMenu({"panel":panel});
			console.log("custom render");
		}
	}
	
	
	//public ajax
	function doAjax(url, data, success, isGet){
		loading.show();
		$.ajax({
			url:url,
			data:data,
			dataType:'jsonp',
			success:function(res){
				console.log(res);
				if(!isGet){
					if(res && res.rescode == 0){
						success && success(res);
					}else{
						if(res.rescode == -1){
							alert("操作失败！原因："+res.msg);
						}else{
							alert("操作失败！");
						}
					}
				}else{
					success && success(res);
				}			
				loading.hide();
			},
			error:function(res){	
				//error && error(res);
				console.log(res);
				loading.hide();
			}
		})
		
	}
	//public new_ajax
	function doNewAjax(url,data,success, isGet){
	loading.show();
	$.ajax({
	    url:url,
	    data:data,
	    success:function(res){
	        if(!isGet){
                if(res && res.rescode == 0){
                    success && success(res);
                }else{
                    if(res.rescode == -1){
                        alert("操作失败！原因："+res.msg);
                    }else{
                        alert("操作失败！");
                    }
                }
            }else{
                success && success(res);
            }
        loading.hide();
	    }
	})
	}
	//输出菜单
	function renderMenu(data){
		$("#mon_menuBox").html($.tmpl($("#tmpl_menuBox").val(),{me:data}));
	}
	//公共监控生效方法
	/*
	function take_effect(){
		doAjax(Actions.take_effect,{app_key:APPKEY},function(res){
			alert("监控已生效")
		});
	}*/
	function get_mon_query_status(callback){
        $.ajax({
            url:Actions.all_monitor_status_query,
            data:{"app_key":APPKEY},
            success:function(res){
                if(res && res.msg.block == 'yes'){//屏蔽中
                    $(".btn_all_mon_screen").attr("disabled",true);//使屏蔽按钮不可用
                    $(".btn_all_mon_screen").css("background","#ADADAD");//使屏蔽按钮变灰
                    $(".btn_all_un_mon_screen").removeAttr("disabled");//使解除按钮可用
                    $(".all_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                    callback && callback(res, true);
                }else{//监控中
                    $(".btn_all_mon_screen").removeAttr("disabled");//使屏蔽按钮可用
                    $(".btn_all_un_mon_screen").attr("disabled",true);//使解除按钮不可用
                    $(".btn_all_un_mon_screen").css("background","gray");//使解除按钮变灰
                    $(".all_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/started.png" alt="started" />');
                    callback && callback(res, false);
                }
            }
        });
	}
 }(jQuery));