﻿/**
 * $.myUtil.formCheck.js
 * add by zzx
 */
(function($, win, undefined){
	var Form = function(opt){
		var _default = {
			box:".formBox",
			requireText:"带星号为必填项",
			group:".form-group",
			helpText:".formTip"
		}
		$.extend(_default, opt);
		this.opt = _default;
		this.init();
	}
	Form.prototype = {
		init:function(){
			
		},
		getForm:function(obj){
			var params = {};
			var flag = null;
			var _this = this;
			var box = obj.parents(this.opt.box);
			//input,textarea
			box.find("input[type='text'],textarea,input[type='hidden'],input[type='number']").each(function(){
				var itemFlag = null;
				var require = $(this).attr("data-require");
				var val = $(this).val().trim();
				var key = $(this).attr("name");
				var reg = $(this).attr("data-reg");
				var msg = $(this).attr("data-msg");
				if(reg){
					reg = new RegExp(reg);
				}
				if(require && require == "true"){
					if(!val){
						flag = true;
						itemFlag = true;
						$(this).parents(_this.opt.group).find(_this.opt.helpText).html(_this.opt.requireText).css("color","red");
						$(this).css("border","1px solid red");
						return;
					}
				}
				if(reg){
					if(!reg.test(val)){
						flag = true;
						itemFlag = true;
						$(this).parents(_this.opt.group).find(_this.opt.helpText).html(msg).css("color","red");
						$(this).css("border","1px solid red");
						return;
					}
				}
				if(!itemFlag){
					$(this).parents(_this.opt.group).find(_this.opt.helpText).html("").css("color","");
					$(this).css("border","1px solid #ccc");
				}
				if(key){
					if(!params[key]){
						params[key] = val;
					}else{
						params[key] += ","+val;
					}
				}
			});
			//select
			box.find("select").each(function(){
				var key = $(this).attr("name");
				if(key){
					params[key] = $(this).val();
				}
			});
			//checkbox
			box.find("input[type='checkbox']").each(function(){
				var val = $(this).val().trim();
				var key = $(this).attr("name");
				if($(this)[0].checked && key){
					if(!params[key]){
						params[key] = val;
					}else{
						params[key] += ","+val;
					}
				}
			});
			//radio
			box.find("input[type='radio']").each(function(){
				var val = $(this).val().trim();
				var key = $(this).attr("name");
				if($(this)[0].checked && key){
					params[key] = val;
				}
			});
			if(!flag){
				return params;
			}
			return null;
		}
	}
	
	$.myUtil = $.myUtil || {};
	$.myUtil.form = function(opt){
		return new Form(opt);
	};
}($, window))
