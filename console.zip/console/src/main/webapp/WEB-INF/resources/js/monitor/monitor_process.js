﻿(function($, win, undeined){
/***********************************************************************************进程监控****************/
	var ProcessMinitor = function(opts){
		this.init(opts);
		this.rawKey = null;
		this.rawName = null;
		this.params = null;
		this.cycle = null;
	}
	ProcessMinitor.prototype = {
		init:function(opts){
			console.log("process init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			//添加raw
			_opts.panelBox.delegate(".btn_add_process_raw","click",function(){
				var _rawKey = $(this).attr("data-rawKey");
				var _name = $(this).attr("data-name");
				var _params = $(this).attr("data-params"); 
				var _cycle = $(this).attr("data-cycle");
				if(_rawKey && _name){
					_this.rawKey = _rawKey;
					_this.rawName = _name;
					_this.params = _params;
					_this.cycle = _cycle;
					renderAddProcessRaw(_opts.panelBox, {
						raw_key:_rawKey,
						name:_name,
						params:_params,
						cycle:_cycle,
						type:"mod"
					});
				}else{
					renderAddProcessRaw(_opts.panelBox);
				}
			})
			_opts.panelBox.delegate(".btn_render_raw_list","click",function(){
				_this.render(null);
			})
			//提交raw
			_opts.panelBox.delegate(".btn_submit_process_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitRaw(data);
				}
			});
			//创建alert
			_opts.panelBox.delegate(".btn_submit_process_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitAlert(data);
				}
			});
			_opts.panelBox.delegate(".btn_submit_process_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					data.disable_time = data.disable_time.replace(",","-");
					_this.submitRule(data);
				}
			});
			//修改raw
			_opts.panelBox.delegate(".btn_mod_process_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modRaw(data);
				}
			});
			//获取raw
			_opts.panelBox.delegate(".btn_get_process_raw","click",function(){
				renderAddProcessRaw(_opts.panelBox, {
					raw_key:_this.rawKey,
					name:_this.rawName,
					params:_this.params,
					cycle:_this.cycle,
					type:"mod"
				});
			})
			//获取alert
			_opts.panelBox.delegate(".btn_get_process_alert","click",function(){
				_this.getAlert();
			})
			//获取rule list
			_opts.panelBox.delegate(".btn_get_process_rule","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var params = $(this).attr("data-params");
				var cycle = $(this).attr("data-cycle");
				if(rawKey && rawName){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.params = params;
					_this.cycle = cycle;
				}
				_this.getRule();
			})
			//获取rule list item
			_opts.panelBox.delegate(".btn_get_process_ruleItem","click",function(){
				var rule = null;
				try{
					rule = JSON.parse($(this).attr("data-rule"));
				}catch(e){}
				renderAddProcessRule(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName,rule:rule});
			})
			//修改alert
			_opts.panelBox.delegate(".btn_mod_process_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modAlert(data);
				}
			});
			//添加rule
			_opts.panelBox.delegate(".btn_add_process_rule","click",function(){
				renderAddProcessRule(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName});
			});
			//修改rule
			_opts.panelBox.delegate(".btn_mod_process_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					data.disable_time = data.disable_time.replace(",","-");
					_this.modRule(data);
				}
			});
			//删除raw
			_opts.panelBox.delegate(".btn_del_process_raw","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				_this.delRaw(rawKey);
			});
			//删除alert
			_opts.panelBox.delegate(".btn_del_process_alert","click",function(){
				_this.delAlert(_this.rawKey);
			});
			_opts.panelBox.delegate(".btn_del_process_rule","click",function(){
				var ruleKey = $(this).attr("data-ruleKey");
				_this.delRule(ruleKey);
			});
		},
		render:function(panel, params){
			this.rawKey = null;
			var _this = this;
			this.getMonitor(function(res){
				renderMonitorList(_this.opts.panelBox, {list:res.raws});
				_this.get_pro_query_status(function(parentType){
				    _this.proStatus(parentType);
				});
			});
		},
		get_pro_query_status:function(callback){
		    this.opts.get_mon_query_status(function(res,parentType){
		        if(parentType == true){//如果整体是屏蔽的
		            $(".btn_pro_mon_screen").attr("disabled",true);//进程监控的屏蔽不可用
                    $(".btn_pro_mon_screen").css("background","#ADADAD");
		            $(".btn_pro_un_mon_screen").attr("disabled",true);//进程监控的解除不可用
                    $(".btn_pro_un_mon_screen").css("background","#ADADAD");
		        }else{
		            //NOTHINGTODO
		        }
		        callback && callback(parentType);
		    });
		},
		proStatus:function(parentType){
		    var app_key = $("#hiddenAppKey").val();
		    var rule_name;
		    var _this = this;
		    $(".btn_pro_mon_status_query").each(function(i){
		        var $this = $(this);
		        rule_name = $this.attr("data-rule_name");
                _this.doProAjax($this, rule_name, app_key,parentType);
		    })
		},
		doProAjax:function(_this,rule_name,app_key,parentType){
		    $.ajax({
                url:"/xplatfe/monitor/monitor_status_query/",
                data:{"app_key":app_key,"rule_name":rule_name},
                success:function(res){
                    if(parentType != true){//外面是解除状态
                        if(res && res.msg.block == "yes"){//屏蔽中
                            $(".btn_pro_mon_screen").attr("disabled",true);//使屏蔽按钮不可用
                            $(".btn_pro_mon_screen").css("background","#ADADAD");
                            $(".btn_dpro_un_mon_screen").removeAttr("disabled");//使解除按钮可用
                            _this.parents(".my_pro_item").find(".pro_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" class="mon_stoped" />');
                        }else{
                            $(".btn_pro_mon_screen").removeAttr("disabled");//使屏蔽按钮可用
                            $(".btn_pro_un_mon_screen").attr("disabled",true);//使解除按钮不可用
                            $(".btn_pro_un_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_pro_item").find(".pro_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/started.png" alt="started" class="mon_started" />');
                        }
                    }else{
                        _this.parents(".my_pro_item").find(".pro_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                    }
                }
            });
		},
		submitRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_proc_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}else if(res.raw_key){
					_this.rawKey = res.raw_key;
					_this.rawName = _data.name;
				}
				if(callback){
					callback(res);
				}else{
					renderAddProcessRule(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		modRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_proc_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_proc_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_name + "_" + data.monitor_item_sel;
			this.opts.doAjax(this.opts.actions.mod_proc_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		submitAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_proc_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		submitRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_name + "_" + data.monitor_item_sel;
			this.opts.doAjax(this.opts.actions.add_proc_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					renderAddProcessAlert(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
					//_this.getRule();
				}
			})
		},
		getAlert:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_proc_raw, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _alert = res && res.alert ? res.alert : null;
					console.log(res)
					if(_alert){
						_alert = $.extend({
							rawKey:_this.rawKey,
							name:_this.rawName,
							type:"mod"
						},_alert)
					}else{
						_alert = {
							rawKey:_this.rawKey,
							name:_this.rawName,
						}
					}
					renderAddProcessAlert(_this.opts.panelBox, _alert);
				}
			},true)
		},
		getRule:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_proc_rule, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _rule = res && res.rules ? res.rules : [];
					renderGetProcessRule(_this.opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						rule:_rule
					});
				}
			},true)
		},
		getMonitor:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_proc_monitor_by_app_key, {app_key:this.opts.appkey}, function(res){
				if(callback){
					callback(res);
				}else{
					renderMonitorList(_this.opts.panelBox, res);
				}
			},true)
		},
		delRaw:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_proc_raw,{raw_key:rawKey},function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delAlert:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_proc_alert, {raw_key:rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delRule:function(ruleKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_proc_rule, {rule_key:ruleKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		}
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderMonitorList(box, data){
		box.html($.tmpl($("#tmpl_monitorList").val(),{me:data}));
	}
	//添加raw
	function renderAddProcessRaw(box, data){
		data = data || {};
		box.html($.tmpl($("#tmpl_addProcessRaw").val(),{me:data}));
	}
	//添加alert
	function renderAddProcessAlert(box, data){
		box.html($.tmpl($("#tmpl_addProcessAlert").val(),{me:data}));
	}
	//添加Rule
	function renderAddProcessRule(box, data){
		console.log(data);
		box.html($.tmpl($("#tmpl_addProcessRule").val(),{me:data}));
	}
	//获取rule列表
	function renderGetProcessRule(box, data){
		box.html($.tmpl($("#tmpl_getProcessRule").val(),{me:data}));
	}
	
	
	$.myMonitor = $.myMonitor || {};
	$.myMonitor.ProcessMinitor = ProcessMinitor;
 }(jQuery));