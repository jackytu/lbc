﻿(function($, win, undeined){
/***********************************************************************************app列表****************/
	var AppList = function(opts){
		this.size = 5;
		this.pageContent = $("#page_content");
		this.pageUtil = $.myUtil.page({
			obj:this.pageContent,
			initShow:false,
			doRender:false
		})
		this.appList = {};
		this.clusters = null;
		this.init(opts);
	}
	AppList.prototype = {
		init:function(opts){
			console.log("List init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			this.pageContent.bind("pageChange", function(res,data){
				console.log(data);
				location.hash="/list/"+data
			})
			_opts.content.delegate(".btn_search_list", "click",function(){
				var data = _this.opts.formIns.getForm($(this));
				_this.doSearch(data.keyword, data.type)
			});
			_opts.content.delegate(".btn_add_space", "click", function(){
				_this.getClusters(function(res){
					var obj = {}
					for(var i =0; i < res.length; i++){
						if(!obj[res[i].dep]){
							obj[res[i].dep] = []
						}
						obj[res[i].dep].push(res[i]);
					}
					renderAddSpace(_this.opts.content, obj);
					_this.pageContent.hide();
				})
			});
			_opts.content.delegate(".btn_submit_app", "click", function(){
                var data = _this.opts.formIns.getForm($(this));
                if(data){
                    _this.addApp(data, function(res){
                        if(res && res.status == "ok"){
                            alert("添加成功!");
							_this.reload();
                        }else if(res.code == -3){
                                alert("app已经存在，换一个吧!");
                        }else{
                            alert("添加app失败！"+res.msg)
                        }
                    })
                }
            });
            _opts.content.delegate(".delapp", "click", function(){
                var app_id = $(this).attr("data-appid");
                var app_name = $(this).attr("data-appname");
                var conf = window.confirm("确定要删除"+app_name+"吗?");
                if(conf){
                    _this.delApp({"app_id":app_id},function(res){
						console.log(res);
						if(res){
							if(res.status == "ok"){
								alert("删除成功!");
								_this.reload();
							}else{
								alert("删除失败！"+res.msg);
							}
						}else{
							alert("服务异常，稍后再试");
						}
					})
                }
            });
			_opts.content.delegate(".change_version","change",function(){
				var val = $(this).val();
				$(this).parents(".formBox").find(".form-group").each(function(){
					var tag = $(this).attr("data-tag");
					if(!tag){
						return;
					}
					if('v'+val == tag){
						$(this).show();
					}else{
						$(this).hide();
					}
					
				})
			});
            _opts.content.delegate(".btn_add_user_auth","click",function(){
                var data = _this.opts.formIns.getForm($(this));
                var space_id = data.space_id;
                if(data){
                    _this.editorSpaceAuth(data, function(res){
                        if(res && res.status == "ok"){
                            _this.renderSpaceAuthList(space_id);
                        }else{
                            alert("添加失败，原因:"+res.msg);
                        }
                    })
                }
            });
            _opts.content.delegate(".btn_add_admin_auth","click",function(){
                var data = _this.opts.formIns.getForm($(this));
                var space_id = data.space_id;
                if(data){
                    _this.editorSpaceAuth(data, function(res){
                        console.log(res)
                        if(res && res.status == "ok"){
                            _this.renderSpaceAuthList(space_id);
                        }else{
                            alert("添加失败");
                        }
                    })
                }
            });
            _opts.content.delegate(".btn_delete_space_auth","click",function(){
               var tr = $(this).parents("tr");
               var space_id = tr.attr("data-spaceid");
               var user = tr.attr("data-user");
               var role = tr.attr("data-role");
               _this.deleteSpaceAuth({user:user,space_id:space_id,type:role}, function(res){
                    console.log(res);
                    if(res && res.status == "ok"){
                        _this.renderSpaceAuthList(space_id);
                    }else{
                        alert("删除失败");
                    }
               })
            });
			_opts.content.delegate(".editorRole","click",function(){
                var data = JSON.parse($(this).parents("tr").attr("data-str"));
                var space_id = data.id;
                _this.renderSpaceAuthList(space_id);
            });
			_opts.content.delegate(".btn_submit_space","click",function(){
				var data = _this.opts.formIns.getForm($(this));
				if(data){
					if(data.version == 2){
						data.cf_user = _this.opts.user_name;
						if(!data.clusters){
							alert("请选择集群!");
							return;
						}
					}else if(data.version == 1){
						data.clusters = "1,2";
						if(!data.cf_user){
							alert("JPaaS用户不能为空!");
							return;
						}
						data.cf_user = data.cf_user.split("@")[0];
					}
					_this.addSpace(data, function(res){
						console.log(res);
						if(res){
							if(res.status == "ok"){
								alert("添加成功!");
								_this.reload();
							}else if(res.code == -3){
                                alert("space已经存在，换一个吧!");
                            }else{
								alert("创建space失败！"+res.msg);
							}
						}else{
							alert("服务异常，稍后再试");
						}
					})
				}
			})
			
			_opts.content.delegate(".delspace","click",function(){
				var data = JSON.parse($(this).parents("tr").attr("data-str"));
				var space_id = data.id;
				var org_id = data.org;
				var space_name = data.name;
				var conf = window.confirm("确定要删除"+space_name+"吗?");
				if(org_id && space_id && conf){
					_this.delSpace({"org_id":org_id,"space_id":space_id},function(res){
						console.log(res);
						if(res){
							if(res.status == "ok"){
								alert("删除成功!");
								_this.reload();
							}else{
								alert("删除失败！"+res.msg);
							}
						}else{
							alert("服务异常，稍后再试");
						}
					})
				}
			});
			
			_opts.content.delegate(".addapp", "click", function(){
				var data = JSON.parse($(this).parents("tr").attr("data-str"));
                _this.getAppList(function(res){
                    var _data = {
                        spaces:res.spaces_all,
                        space_id:data.id,
                        org_id:data.org
                    }
                    renderAddApp(_this.opts.content, _data);
                    _this.pageContent.hide();
                })
			})
		},
		reload:function(){
			this.appList = {};
			location.hash = "#/list/1!r="+Math.random()
		},
        renderSpaceAuthList:function(space_id){
            var _this = this;
            _this.getSpaceAuthList(space_id, function(res){
                renderAuthList(_this.opts.content, res);
                _this.pageContent.hide();
            })
        },
		doSearch:function(keyword, type){
			var _this = this;
			this.getAppList(function(res){
				renderAppList(_this.opts.content, res);
				if(max_len > 1 && !res.key){
					_this.pageUtil.render({
						len:max_len,
						current:1
					})
					_this.pageContent.show();
				}else{
					_this.pageContent.hide();
				}
			},1,keyword,type);
		},
		render:function(panel, params){
			var page = parseInt(params[0])
			if(!page || page == "NaN"){
				page = 1;
			}
			var _this = this;
			this.getAppList(function(res){
				renderAppList(_this.opts.content, res);
				max_len = Math.ceil(res.len/_this.size)
				if(max_len > 1){
					_this.pageUtil.render({
						len:max_len,
						current:page
					})
					_this.pageContent.show();
				}else{
					_this.pageContent.hide();
				}
			},page);
		},
		getAppList:function(callback, page, keyword, type){		
			var _this = this;
            page = page || 1;
			var key = page+"|"+keyword+"|"+type;
			if(this.appList[key]){
				callback && callback(this.appList[key]);
			}else{
				this.opts.doajax(this.opts.actions.get_app_manager_info, {org_id:this.opts.org_id, size:this.size, page:page,keyword:keyword,type:type}, "json", function(res){
					if(res){
						_this.appList = {};
						_this.appList[key] = res;
						callback && callback(res);
					}else{
						alert("服务调整中，稍后再试");
					}
				})
			}
		},
        getSpaceAuthList:function(space_id, callback){
            var _this = this;
            this.opts.doajax(this.opts.actions.get_space_auth_list, {space_id:space_id}, "json", function(res){
                if(res && res["status"] == "ok"){
                    callback && callback(res);
                }else{
                    alert("服务调整中，稍后再试");
                }
            })
        },
		getClusters:function(callback){
			var _this = this;
			if(this.clusters){
				callback && callback(this.clusters);
			}else{
				this.opts.doajax(this.opts.actions.get_clusters,{},'json',function(res){
					if(res){
						_this.clusters = res;
						callback && callback(res);
					}else{
						alert("服务调整中，稍后再试");
					}
				})
			}
		},
        editorSpaceAuth:function(data, callback){
            var _this = this;
            this.opts.doajax(this.opts.actions.editor_space_auths, data, 'json', function(res){
				callback && callback(res);
			})
        },
        deleteSpaceAuth:function(data, callback){
            var _this = this;
            this.opts.doajax(this.opts.actions.delete_space_auths, data, 'json', function(res){
				callback && callback(res);
			})
        },
		addSpace:function(data, callback){
			var _this = this;
			this.opts.doajax(this.opts.actions.add_space, data, 'json', function(res){
				callback && callback(res);
			})
		},
        addApp:function(data, callback){
            var _this = this;
			this.opts.doajax(this.opts.actions.add_app, data, 'json', function(res){
				callback && callback(res);
			})
        },
		delSpace:function(data, callback){
			var _this = this;
			this.opts.doajax(this.opts.actions.del_space, data, 'json', function(res){
				callback && callback(res);
			})
		},
        delApp:function(data, callback){
            var _this = this;
			this.opts.doajax(this.opts.actions.del_app, data, 'json', function(res){
				callback && callback(res);
			})
        }
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderAppList(box, data){
		box.html($.tmpl($("#tmpl_appList").val(),{me:data}));
	}
	//add space
	function renderAddSpace(box, data){
		box.html($.tmpl($("#tmpl_addSpace").val(),{me:data}));
	}
	//add app
	function renderAddApp(box, data){
		box.html($.tmpl($("#tmpl_addApp").val(),{me:data}));
	}
    //auths list
    function renderAuthList(box, data){
        box.html($.tmpl($("#tmpl_authList").val(),{me:data}));
    }
	$.myAdmin = $.myAdmin || {};
	$.myAdmin.AppList = AppList;
 }(jQuery));