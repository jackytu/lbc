﻿(function($, win, undeined){
/***********************************************************************************org管理员列表****************/
    var lang = {
        "-2":"产品线关联的集群不存在，请先添加关联集群!"
    }
	var ManagerList = function(opts){
		this.init(opts);
	}
	ManagerList.prototype = {
		init:function(opts){
			console.log("manager list init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
            
            _opts.content.delegate(".btn_add_org_auth","click", function(){
                var data = _this.opts.formIns.getForm($(this));
                if(data && data.user){
                    _this.editor_manager_auth(data.user, function(res){
                        if(res && res.status == "ok"){
                            _this.reload();
                        }else{
                            var msg = lang[res.code] || res.msg;
                            alert("添加失败！原因"+msg);
                            _this.opts.loading.hide();
                        }
                    })
                }
                
            })
            
            _opts.content.delegate(".btn_delete_org_auth","click", function(){
                var user = $(this).parents("tr").attr("data-user");
                var r = window.confirm("确定要删除"+user+"吗?");
                if(user && r){
                    _this.delete_manager_auth(user, function(res){
                        if(res && res.status == "ok"){
                            _this.reload();
                        }else{
                            alert("删除失败！原因"+res.msg);
                            _this.opts.loading.hide();
                        }
                    })
                }
            })
		},
		reload:function(){
			location.hash = "#/manager/!r="+Math.random()
		},
        get_manager_list:function(callback){
            this.opts.doajax(this.opts.actions.get_org_auth_list, {org_id:this.opts.org_id}, "json", function(res){
                if(res){
                    callback && callback(res);
                }else{
                    alert("服务调整中，稍后再试");
                }
            })
        },
        editor_manager_auth:function(user, callback){
            var _this = this;
            this.opts.loading.show();
            this.opts.doajax(this.opts.actions.editor_org_auths, {org_id:this.opts.org_id, user:user}, "json", function(res){
                if(res){
                    callback && callback(res);
                }else{
                    alert("服务调整中，稍后再试");
                    _this.opts.loading.show();
                }
            },true)
        },
        delete_manager_auth:function(user, callback){
            var _this = this;
            this.opts.loading.show();
            this.opts.doajax(this.opts.actions.delete_org_auths, {org_id:this.opts.org_id, user:user}, "json", function(res){
                if(res){
                    callback && callback(res);
                }else{
                    alert("服务调整中，稍后再试");
                    _this.opts.loading.show();
                }
            },true)
        },
		render:function(panel, params){
			var _this = this;
            console.log("manager list render")
            this.get_manager_list(function(res){
                console.log(res);
                renderManagerList(_this.opts.content,res);
                $("#page_content").hide();
            })
		}
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderManagerList(box, data){
		box.html($.tmpl($("#tmpl_managerList").val(),{me:data}));
	}
	
	$.myAdmin = $.myAdmin || {};
	$.myAdmin.ManagerList = ManagerList;
 }(jQuery));
