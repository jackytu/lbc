﻿(function($, win, undeined){
/***********************************************************************************历史上线****************/
	var HistoryAutopush = function(opts){
		this.init(opts);
	}
	HistoryAutopush.prototype = {
		init:function(opts){
			console.log("history init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
		},
		render:function(panel, params){
			var _this = this;
            _this.opts.log.hide();
			_this.getHistory();
		},
		getHistory:function(){
			var _this = this;
			this.opts.doajax(this.opts.actions.getHistory, null, 'jsonp', function(res){
				renderList(_this.opts.content, res, _this.opts.lang)
			})
		}
	}
	/***************************************************************************************静态方法**************/
	function renderList(box, data, lang){
		box.html($.tmpl($("#history_tmpl_list").val(), {"me":data, "lang":lang}))
		$("#current_menu_box").html("");
	}
	
	$.myAutopush = $.myAutopush || {};
	$.myAutopush.historyAutopush = HistoryAutopush;
 }(jQuery));