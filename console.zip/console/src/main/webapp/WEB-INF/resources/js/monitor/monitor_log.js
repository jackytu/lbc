﻿(function($, win, undeined){
/***********************************************************************************日志监控****************/
	var LogMinitor = function(opts){
		this.init(opts);
		this.rawKey = null;
		this.rawName = null;
		this.itemKey = null;
		this.itemName = null;
		this.log_filepath = null;
	}
	LogMinitor.prototype = {
		init:function(opts){
			console.log("log init");
			this.opts = opts;
			this.addEvent();
		},
		addEvent:function(){
			var _this = this;
			var _opts = _this.opts;
			//添加raw
			_opts.panelBox.delegate(".btn_add_log_raw","click",function(){
				var _rawKey = $(this).attr("data-rawKey");
				var _name = $(this).attr("data-name");
				var _log_filepath = $(this).attr("data-log_filepath"); 
				if(_rawKey && _name){
					_this.rawKey = _rawKey;
					_this.rawName = _name;
					_this.log_filepath = _log_filepath;
					renderAddLogRaw(_opts.panelBox, {
						raw_key:_rawKey,
						name:_name,
						log_filepath:_log_filepath,
						type:"mod"
					});
				}else{
					renderAddLogRaw(_opts.panelBox);
				}
			})
			_opts.panelBox.delegate(".btn_render_raw_list","click",function(){
				_this.render(null);
			})
			//提交raw
			_opts.panelBox.delegate(".btn_submit_log_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitRaw(data);
				}
			});
			
			//创建alert
			_opts.panelBox.delegate(".btn_submit_log_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitAlert(data);
				}
			});
			//创建rule
			_opts.panelBox.delegate(".btn_submit_log_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitRule(data);
				}
			});
			//创建alert
			_opts.panelBox.delegate(".btn_submit_log_item","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.submitItem(data);
				}
			});
			//修改raw
			_opts.panelBox.delegate(".btn_mod_log_raw","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modRaw(data);
				}
			});
			//获取raw
			_opts.panelBox.delegate(".btn_get_log_raw","click",function(){
				renderAddLogRaw(_opts.panelBox, {
					raw_key:_this.rawKey,
					name:_this.rawName,
					log_filepath:_this.log_filepath,
					type:"mod"
				});
			})
			//获取alert
			_opts.panelBox.delegate(".btn_get_log_alert","click",function(){
				_this.getAlert();
			})
			//获取rule list
			_opts.panelBox.delegate(".btn_get_log_rule","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var itemKey = $(this).attr("data-itemKey");
				var itemName = $(this).attr("data-itemName");
				var log_filepath = $(this).attr("data-log_filepath");
				if(rawKey && rawName){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.log_filepath = log_filepath;	
				}
				if(itemKey){
					_this.getRule(null, {item_key:itemKey,name:itemName});
				}else{
					_this.getRule();
				}
			})
			//获取item list
			_opts.panelBox.delegate(".btn_get_log_item","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var log_filepath = $(this).attr("data-log_filepath");
				if(rawKey && rawName){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.log_filepath = log_filepath;
				}
				_this.getItem();
			})
			//获取rule list item
			_opts.panelBox.delegate(".btn_get_log_ruleItem","click",function(){
				var rule = null;
				try{
					rule = JSON.parse($(this).attr("data-rule"));
				}catch(e){}
				_this.itemKey = rule.item_key;
				_this.itemName = rule.item_name;
				renderAddLogRule(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						itemKey:_this.itemKey, 
						itemName : _this.itemName,
						rule:rule
					}
				);
			});
			//获取item list item
			_opts.panelBox.delegate(".btn_get_log_itemItem","click",function(){
				var item = null;
				try{
					item = JSON.parse($(this).attr("data-item"));
				}catch(e){}
				_this.itemKey = item.item_key;
				_this.itemName = item.name;
				renderAddLogItem(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						item:item
					}
				);
			});
			//修改alert
			_opts.panelBox.delegate(".btn_mod_log_alert","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modAlert(data);
				}
			});
			
			//添加rule
			_opts.panelBox.delegate(".btn_add_log_rule","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				var rawName = $(this).attr("data-name");
				var itemKey = $(this).attr("data-itemKey");
				var itemName = $(this).attr("data-itemName");
				var log_filepath = $(this).attr("data-log_filepath");
				if(rawKey && itemKey){
					_this.rawKey = rawKey;
					_this.rawName = rawName;
					_this.log_filepath = log_filepath;
					_this.itemKey = itemKey;
					_this.itemName = itemName;
				}
				renderAddLogRule(
					_opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						itemKey:_this.itemKey,
						itemName:_this.itemName
					}
				);
			});
			//添加item
			_opts.panelBox.delegate(".btn_add_log_item","click",function(){
				renderAddLogItem(_opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName});
			});
			//修改rule
			_opts.panelBox.delegate(".btn_mod_log_rule","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modRule(data);
				}
			});
			//修改item
			_opts.panelBox.delegate(".btn_mod_log_item","click",function(){
				var data = _opts.formIns.getForm($(this));
				if(data){
					_this.modItem(data);
				}
			});
			//删除raw
			_opts.panelBox.delegate(".btn_del_log_raw","click",function(){
				var rawKey = $(this).attr("data-rawKey");
				_this.delRaw(rawKey);
			});
			//删除alert
			_opts.panelBox.delegate(".btn_del_log_alert","click",function(){
				_this.delAlert(_this.rawKey);
			});
			//删除rule
			_opts.panelBox.delegate(".btn_del_log_rule","click",function(){
				var ruleKey = $(this).attr("data-ruleKey");
				_this.delRule(ruleKey);
			});
			//删除item
			_opts.panelBox.delegate(".btn_del_log_item","click",function(){
				var itemKey = $(this).attr("data-itemKey");
				_this.delItem(itemKey);
			});
			//选择rule
			_opts.panelBox.delegate(".get_rule_by_select","change", function(){
				var item = {};
				try{
					item = JSON.parse($(this).val());
				}catch(e){}
				if(item && item.item_key){
					_this.getRule(null, item);
				}
			})
		},
		render:function(panel, params){
			this.rawKey = null;
			var _this = this;
			this.getMonitor(function(res){
				renderMonitorList(_this.opts.panelBox, {list:res.raw});
				_this.get_log_query_status(function(parentType){
				    _this.logStatus(parentType);
				});
			});
		},
		get_log_query_status:function(callback){
		    this.opts.get_mon_query_status(function(res,parentType){
		        if(parentType == true){//整体是屏蔽的
		            $(".btn_log_mon_screen").attr("disabled",true);//log监控的屏蔽不可用
		            $(".btn_log_mon_screen").css("background","#ADADAD");
		            $(".btn_log_un_mon_screen").attr("disabled",true);//log监控的解除不可用
                    $(".btn_log_un_mon_screen").css("background","#ADADAD");
		        }else{
		            //NOTHINGTODO
		        }
                callback && callback(parentType);
		    });
		},
		logStatus:function(parentType){
		    var app_key = $("#hiddenAppKey").val();
		    var rule_name;
		    var _this = this;
		    $(".btn_log_mon_status_query").each(function(i){
		        var $this = $(this);
		        rule_name = $this.attr("data-rule_name");
                _this.doLogAjax($this, rule_name, app_key, parentType);
		    })
		},
		doLogAjax:function(_this,rule_name,app_key, parentType){
		     $.ajax({
                url:"/xplatfe/monitor/monitor_status_query/",
                data:{"app_key":app_key,"rule_name":rule_name},
                success:function(res){
                    //console.log(res)
                    //console.log("parent:"+parentType);
                    if(parentType != true){//外面是解除状态
                        if(res && res.msg.block == "yes"){
                            _this.parents(".my_log_item").find(".btn_log_mon_screen").attr("disabled",true);//使屏蔽按钮不可用
                            _this.parents(".my_log_item").find(".btn_log_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_log_item").find(".btn_log_un_mon_screen").removeAttr("disabled");//使解除按钮可用
                            _this.parents(".my_log_item").find(".log_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                        }else{
                            _this.parents(".my_log_item").find(".btn_log_mon_screen").removeAttr("disabled");//使屏蔽按钮可用
                            _this.parents(".my_log_item").find(".btn_log_un_mon_screen").attr("disabled",true);//使解除按钮不可用
                            _this.parents(".my_log_item").find(".btn_log_un_mon_screen").css("background","#ADADAD");
                            _this.parents(".my_log_item").find(".log_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/started.png" alt="started" />');
                        }
                    }else{//外面是屏蔽状态
                        _this.parents(".my_log_item").find(".log_mon_status_query").html('<img style="height:20px;width:20px" src="/site_media/img/stoped.png" alt="stoped" />');
                    }
                }
            });
		},
		submitRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_log_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}else if(res.raw_key){
					_this.rawKey = res.raw_key;
					_this.rawName = _data.name;
				}
				if(callback){
					callback(res);
				}else{
					renderAddLogItem(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		modRaw:function(data, callback){
			var _data = $.extend({app_key:this.opts.appkey},data);
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_log_raw, _data, function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_log_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		modRule:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_log_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		modItem:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.mod_log_item,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("修改失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.getItem();
				}
			})
		},
		submitAlert:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_log_alert,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		submitRule:function(data, callback){
			var _this = this;
			data.monitor_item = data.monitor_item_name + "_" + data.monitor_item_sel;
			this.opts.doAjax(this.opts.actions.add_log_rule,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				if(callback){
					callback(res);
				}else{
					renderAddLogAlert(_this.opts.panelBox, {rawKey:_this.rawKey,name:_this.rawName})
				}
			})
		},
		submitItem:function(data, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.add_log_item,data,function(res){
				if(!res || res.rescode == -1){
					var msg = res ? res.msg : "";
					alert("添加失败！"+msg);
					return;
				}
				_this.itemKey = res.item_key;
				_this.itemName = data.name;
				if(callback){
					callback(res);
				}else{
					renderAddLogRule(
						_this.opts.panelBox, {
							rawKey:_this.rawKey,
							name:_this.rawName, 
							itemKey:_this.itemKey, 
							itemName : _this.itemName
						}
					)
				}
			})
		},
		getAlert:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_log_raw, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _alert = res && res.alert ? res.alert : null;
					console.log(res)
					if(_alert){
						_alert = $.extend({
							rawKey:_this.rawKey,
							name:_this.rawName,
							type:"mod"
						},_alert)
					}else{
						_alert = {
							rawKey:_this.rawKey,
							name:_this.rawName,
						}
					}
					renderAddLogAlert(_this.opts.panelBox, _alert);
				}
			},true)
		},
		getRule:function(callback, curItem){
			var _this = this;
			this.getItem(function(item){
				var _item = item && item.items ? item.items : [];
				var _curItem = curItem || _item[0];
				if(!_curItem || !_curItem.item_key){
					alert("请先添加一个监控项！");
					return;
				}
				_this.itemKey = _curItem.item_key;
				_this.itemName = _curItem.name;
				_this.opts.doAjax(_this.opts.actions.get_log_rule, {item_key:_curItem.item_key}, function(res){
					if(callback){
						callback(res);
					}else{
						var _rule = res && res.rules ? res.rules : [];
						renderGetLogRule(_this.opts.panelBox, {
							rawKey:_this.rawKey,
							name:_this.rawName,
							rule:_rule,
							item:_curItem,
							itemList:_item
						});
					}
				},true)
			})
		},
		getItem:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_log_item, {raw_key:this.rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					var _item = res && res.items ? res.items : [];
					renderGetLogItem(_this.opts.panelBox, {
						rawKey:_this.rawKey,
						name:_this.rawName,
						item:_item
					});
				}
			},true)
		},
		getMonitor:function(callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.get_log_monitor_by_app_key, {app_key:this.opts.appkey}, function(res){
				if(callback){
					callback(res);
				}else{
					renderMonitorList(_this.opts.panelBox, res);
				}
			},true)
		},
		delRaw:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_log_raw,{raw_key:rawKey},function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delAlert:function(rawKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_log_alert, {raw_key:rawKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.render();
				}
			})
		},
		delRule:function(ruleKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_log_rule, {rule_key:ruleKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getRule();
				}
			})
		},
		delItem:function(itemKey, callback){
			var _this = this;
			this.opts.doAjax(this.opts.actions.del_log_item, {item_key:itemKey}, function(res){
				if(callback){
					callback(res);
				}else{
					_this.getItem();
				}
			})
		}
	}
	/***************************************************************************************静态方法**************/
	//输出列表
	function renderMonitorList(box, data){
		box.html($.tmpl($("#tmpl_log_monitorList").val(),{me:data}));
	}
	//添加raw
	function renderAddLogRaw(box, data){
		data = data || {};
		box.html($.tmpl($("#tmpl_addLogRaw").val(),{me:data}));
	}
	//添加alert
	function renderAddLogAlert(box, data){
		box.html($.tmpl($("#tmpl_addLogAlert").val(),{me:data}));
	}
	//添加Rule
	function renderAddLogRule(box, data){
		box.html($.tmpl($("#tmpl_addLogRule").val(),{me:data}));
	}
	//添加Item
	function renderAddLogItem(box, data){
		box.html($.tmpl($("#tmpl_addLogItem").val(),{me:data}));
	}
	//获取rule列表
	function renderGetLogRule(box, data){
		box.html($.tmpl($("#tmpl_getLogRule").val(),{me:data}));
	}
	function renderGetLogItem(box, data){
		box.html($.tmpl($("#tmpl_getLogItem").val(),{me:data}));
	}
	
	$.myMonitor = $.myMonitor || {};
	$.myMonitor.LogMinitor = LogMinitor;
 }(jQuery));