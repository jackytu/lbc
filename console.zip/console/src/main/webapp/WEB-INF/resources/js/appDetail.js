﻿/**
* xPlat app v1 detail 业务逻辑代码
*@Require jQuery
*/
(function($, win, undeined){  
	var tabCount = 1;
    var tab_dict = {};
    var need_add_height = true;
    function myload(){
        $("#info").text("The DOM is now loaded and can be manipulated.");
    }
    /*function auto_height() {
        var iframes = document.getElementsByName("tab_iframe");
        var ifm, newheight, origin_height;
        for (var i=0; i<iframes.length; i++) {
            ifm = iframes[i];
            origin_height = ifm.contentWindow.document.documentElement.scrollHeight;
            new_height = origin_height + 100;
            $("#" + ifm.id).attr("height", new_height);

        }
    }*/

    function del_monitor(app_name, app_id, _type, user, kind, monitor_key) {                                                     
        c = confirm('确定删除' + _type + ' ' + kind + '监控吗？');                                       
        if (c) {                                                                
            var url = "/xplatfe/app/monitor?action=delete&app_name=" + app_name +
            '&type=' + _type +
            '&app_id=' + app_id +
            '&user=' + user +
            '&monitor_key=' + monitor_key +
            '&kind=' + kind;
            location.replace(url);                                              
        }                                                                       
    }            


    /*$(function() {
        var tabs = $( "#tabs" ).tabs();

        // close icon: removing the tab on click
        tabs.delegate( "span.ui-icon-close", "click", function() {
            var panelId = $( this ).closest( "li" ).remove().attr( "aria-controls" );
            //console.log('panelId=' + panelId);
            var iframe_id = "#iframe_" + panelId;
            $(iframe_id).attr('src', '');
            tabCount--;
            tabs.tabs( "refresh" );
            $( "#tabs" ).tabs( "option", "active", tabCount );
            // update tab_dict
            var old_num = tab_dict[iframe_id];
            var tmp_num;
            for (var key in tab_dict) {
                tmp_num = tab_dict[key];
                if (tmp_num > old_num) {
                    tmp_num--;
                    tab_dict[key] = tmp_num;
                }
            }
            tab_dict[iframe_id] = -1;
        });
    });

    function addTab(tabTitle, tabId, iframe_height, uri) {
       var iframe_id = "#iframe_" + tabId;
       if (tab_dict[iframe_id] && tab_dict[iframe_id] != -1) {
           var tab_num = tab_dict[iframe_id];
           $( "#tabs" ).tabs( "option", "active", tab_num);
       } else {
           var tabTemplate = "<li><a href='#{href}'>#{label}</a> <span class='ui-icon ui-icon-close' role='presentation'>Remove Tab</span></li>";
           var tabs = $( "#tabs" ).tabs();
           var label = tabTitle;
           var id = tabId;
           var li = $( tabTemplate.replace( /#\{href\}/g, "#" + id ).replace( /#\{label\}/g, label ) );
           $("#tabHeaders").append( li );
           $(iframe_id).attr("src", uri);
           $(iframe_id).show();
           tabs.tabs( "refresh" );
           tab_dict[iframe_id] = tabCount;
           $( "#tabs" ).tabs( "option", "active", tabCount );
           tabCount++;
       }
    }
	
	
	win.addTab = addTab;*/
	win.del_monitor = del_monitor;
	//win.auto_height = auto_height;
	win.myload = myload;
}(jQuery, window))
//app重启
//require tmpl.js
//require loading.js
//require jquery
//require page.js

; (function($){
	var btnAppStart = $("#btnAppStart");
	var btnAppRestart = $("#btnAppRestart");
	var btnAppRestarts = $(".btnAppRestart");
	var btnAppStop = $("#btnAppStop");
	var btnAppHistory = $("#btnAppHistory");
	var appOperState = $("#appOperState");
	var appOperate = $(".appOperate");
	var historyPageContent = $("#historyPageContent");
	var viewHistoryContent = $("#viewHistoryContent");
	var autoPushApi = $("#hidden_autoPushApi").attr("value");
	var app_id = $("#hidden_appid").attr("value");
	var isProcessing = /^.*_PROCESSING$/;
	var isSuccess = /^.*_SUCCESS$/;
	var isFailed = /^.*_FAILED$/;
	var isStoped = /^.*_STOPED$/;
	var isStarted = /^.*_STARTED$/;
	var loading = null;
	var timer = null;
	var pageObj = null;
	var curPage = 1;
	var _states = {
		START_PROCESSING:"正在启动",
		START_FAILED:"启动失败",
		START_ALREADY_STARTED:"检测已经启动",
		START_SUCCESS:"启动成功",
		LOCKED:"操作被锁,请联系OP解决",
		NO_REGISTERED:"app未注册",
		STOP_PROCESSING:"正在停服",
		STOP_FAILED:"停服失败",
		STOP_ALREADY_STOPPED:"检测已经停服",
		STOP_SUCCESS:"停服成功",
		RESTART_PROCESSING:"正在重启",
		RESTART_FAILED:"重启失败",
		RESTART_TRANSFER_FAILED:"重启切流量失败",
		RESTART_STOP_FAILED:"重启过程中停服失败",
		RESTART_START_FAILED:"重启过程中启动失败",
		RESTART_SUCCESS:"重启成功"
	};
	var _lang = {
		"start":"启动app",
		"restart":"重启app",
		"stop":"停服",
		"jpaas.baidu.com":"01集群",
		"jpaas02.baidu.com":"02集群",
		"jpaas.baidu.com,jpaas02.baidu.com":"01集群,02集群"
	}
	var Actions = {
		getState:autoPushApi+"/autopush/api/apps/operation/"+app_id,
		restart:"/xplatfe/api2/app_operate?app_id="+app_id+"&type=restart",
		start:"/xplatfe/api2/app_operate?app_id="+app_id+"&type=start",
		stop:"/xplatfe/api2/app_operate?app_id="+app_id+"&type=stop",
		history:autoPushApi+"/autopush/api/apps/operation/all/?app_id="+app_id
	};
	getState(function(res){
		renderButton(res.state,true);
		addEvent();
		if(res.state && isProcessing.test(res.state)){
			startTimer();
		}
	});
	function startTimer(){
		timer = setInterval(function(){
			getState(function(res){
				timer && renderButton(res.state,false);
				if(!res.state || !isProcessing.test(res.state)){
					clearInterval(timer);
					timer = null;
				}
				
			})
		},2000)
	};
	function addEvent(){
		btnAppStart.bind("click", function(){
			var _st = "START_PROCESSING";
			renderButton(_st,false);
			renderOperState(_st, false);
			$.ajax({
				url:Actions.start,
				success:function(res){
					startTimer();
				},
				error:function(){
					renderButton("START_FAILED",false);
				}
			})
		})
		btnAppRestarts.bind("click", function(){
			var _text = $(this).text();
			if(!window.confirm("确定要切流量重启"+_text+"吗？")){
				return false;
			}
			var _st = "RESTART_PROCESSING";
			var _target = $(this).attr("data-target");
			var _url = Actions.restart+"&target="+_target;
			renderButton(_st,false);
			renderOperState(_st, false);
			$.ajax({
				url:_url,
				success:function(res){
					startTimer();
				},
				error:function(){
					renderButton("RESTART_FAILED",false);
				}
			})
		})
		btnAppStop.bind("click", function(){
			var _st = "STOP_PROCESSING";
			if(!window.confirm("确定要停止服务吗？")){
				return false;
			}
			renderButton(_st,false);
			renderOperState(_st, false);
			$.ajax({
				url:Actions.stop,
				success:function(res){
					startTimer();
				},
				error:function(){
					renderButton("STOP_FAILED",false);
				}
			})
		});
		btnAppHistory.bind("click", function(){
			if(!loading){
				loading = $.myUtil.loading({
					initShow:false,
					parent:viewHistoryContent.find(".modal-body")
				})
			}
			loading.show();
			viewHistoryContent.modal();
			viewHistoryContent.find("table").html("");
			curPage = 1;
			getHistory(curPage);
		})
		historyPageContent.bind("pageChange",function(e, page){
			console.log(page);
			loading.show();
			getHistory(page);
		})
	};
	function getHistory(_page, _size){
		_size = _size || 10;
		$.ajax({
			url:Actions.history,
			data:{page:_page, size:_size},
			dataType:"jsonp",
			success:function(res){
				console.log(res);
				renderHistory(res);
				if(!pageObj && res){
					pageObj = $.myUtil.page({
						current:_page,
						len:Math.ceil(res["length"]/_size),
						obj:historyPageContent
					});	
				}
				loading && loading.hide();
			}
		})
	}
	function renderHistory(res){	
		viewHistoryContent.find("table").html($.tmpl($("#tmplHistory").val(), {me:res.data,states:_states,lang:_lang,isSuccess:isSuccess}));
	};
	function renderButton(state,inited){
		var operate = null;
		var instanceState = $(".instanceState");
		var isRunning = instanceState[0] && instanceState.eq(0).attr("data-state") == "RUNNING" ? true : false;
		//没有最近的操作，就以实例状态为准
		if(inited){
			if(state && isProcessing.test(state)){
				operate = state.toLocaleLowerCase();
			}
		}else if(state){
			//运行中
			var toLower = state.split("_")[0].toLocaleLowerCase();
			if(isProcessing.test(state)){
				operate = state.toLocaleLowerCase(); //restart_processing stop_processing start_processing
			}else if(isSuccess.test(state) || isStoped.test(state) || isStarted.test(state)){
				operate = toLower;//start restart stop
			}else if(isFailed.test(state)){
				if(toLower == "start"){
					operate = "stop";
				}else if(toLower == "stop"){
					operate = "start";
				}
			}
		}
		if(!operate){
			operate = isRunning ? "start" : "stop"; //stop start
		}
		btnAppStart.hide().val("启动").removeAttr("disabled");
		btnAppRestart.hide().val("重启").removeAttr("disabled");
		btnAppStop.hide().val("停止").removeAttr("disabled");
		switch(operate){
			case "restart":;
			case "start":
				btnAppRestart.show();
				btnAppStop.show();
				break;
			case "stop":
				btnAppStart.show();
				break;
			case "restart_processing":
				btnAppRestart.show().val("重启中..").attr("disabled","disabled");
				btnAppStop.show().attr("disabled","disabled");
				break;
			case "start_processing":
				btnAppStart.show().val("启动中..").attr("disabled","disabled");
				break;
			case "stop_processing":
				btnAppStop.show().val("停止中..").attr("disabled","disabled");
				btnAppRestart.show().attr("disabled","disabled");
				break;
		}
		renderOperState(state, inited);
	};
	function renderOperState(state, inited){
		var st = _states[state];
		var html = "";
		if(st && state && (!inited || isProcessing.test(state))){
			if(isProcessing.test(state)){
				html = '<img src="/site_media/img/loading.gif"><span style="color:rgb(245, 160, 33);">'+st+'</span>';
			}else if(isSuccess.test(state) || isStoped.test(state) || isStarted.test(state)){
				html = '<span style="color:green;">'+st+'</span>';
			}else if(isFailed.test(state)){
				html = '<span style="color:red;">'+st+'</span>';
			}else{
				html = '<span style="color:red;">'+st+'</span>';
			}		
		}
		appOperState.html(html);
	};
	function getState(callback){
		$.ajax({
			url:Actions.getState,
			dataType:"jsonp",
			success:function(res){
				console.log(res);
				callback && callback(res);
			}
		})
	};
}(jQuery))