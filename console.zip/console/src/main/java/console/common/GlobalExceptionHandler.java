package console.common;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

@RestController
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(DuplicateKeyException.class)
    public RestResponse<String> handleSQLException(HttpServletRequest request, Exception ex) {
        logger.info("DuplicateKeyException Occured, URL:" + request.getRequestURL());
        RestResponse<String> result = new RestResponse<String>();
        result.setCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
        result.setMessage("重复记录错误");
        result.setData(ex.getMessage());
        return result;
    }

    @ExceptionHandler(UnauthorizedException.class)
    public RestResponse<String> handleUnauthorizedException(HttpServletRequest request, Exception ex) {
        logger.info("UnauthorizedException Occured, URL:" + request.getRequestURL());
        RestResponse<String> result = new RestResponse<String>();
        result.setCode(HttpStatus.SC_FORBIDDEN);
        result.setMessage("无权限");
        return result;
    }

}
