package console.common;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * babel客户端，主要获取公司人员信息
 * 
 * @author wuwei03
 * 
 */
@Component
public class BabelClient {
    private static Logger log = LoggerFactory.getLogger(BabelClient.class);
    private static final String HOST = "babel.baidu.com";

    public RestResponse<List<Map<String, String>>> getUserInfo(String keyword) {
        String url = "http://" + HOST + "/web/api/uniform/suggest/address?word=" + keyword;
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        RestResponse<List<Map<String, String>>> result = new RestResponse<List<Map<String, String>>>();
        HttpResponse response;
        try {
            response = httpclient.execute(httpGet);
            final StatusLine status = response.getStatusLine();
            final String rtn = EntityUtils.toString(response.getEntity());
            httpGet.releaseConnection();
            if (status.getStatusCode() != HttpStatus.SC_OK) {
                log.error("get icafe module failed,url: " + url);
                result.setCode(status.getStatusCode());
                result.setMessage("request babel failed!");
                return result;
            }
            result.setCode(HttpStatus.SC_OK);
            Gson gson = new Gson();
            List<Map<String, String>> data = gson.fromJson(rtn, new TypeToken<List<Map<String, String>>>() {
            }.getType());
            result.setData(data);
        } catch (ClientProtocolException e) {
            result.setCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            result.setMessage(e.getMessage());
            e.printStackTrace();
        } catch (IOException e) {
            result.setCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            result.setMessage(e.getMessage());
            e.printStackTrace();
        }
        return result;
    }
}
