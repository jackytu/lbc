package console.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.time.DateUtils;

public class DateTools {
    public static String yesterday(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        Date date = DateUtils.addDays(new Date(), -1);
        return dateFormat.format(date);
    }
}
