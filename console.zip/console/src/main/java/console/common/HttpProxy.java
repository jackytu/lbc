package console.common;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

/**
 * Http代理类，用于请求公共模块（console-api）的请求
 * 
 * @author wuwei03
 * 
 */
public class HttpProxy {
    private static Logger log = LoggerFactory.getLogger(HttpProxy.class);
    private static final String TOKEN = "3FCPpbFZ5fAmES4YuMmtg1vGiT70vOgL3URTZmfb";

    public static String getHttpGet(String url) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        HttpResponse response;
        try {
            response = httpclient.execute(httpGet);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpGet.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpGet(String url, String token) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader("Content-Type", "application/json");
        httpGet.setHeader("Authorization", token);
        HttpResponse response;
        try {
            response = httpclient.execute(httpGet);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpGet.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpPost(String url, String body) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setHeader("Authorization", TOKEN);
        HttpResponse response;
        try {
            httpPost.setEntity(new StringEntity(body));
            response = httpclient.execute(httpPost);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpPost.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpPost(String url, String body, String token) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(url);
        httpPost.setHeader("Content-Type", "application/json");
        httpPost.setHeader("Authorization", token);
        HttpResponse response;
        try {
            httpPost.setEntity(new StringEntity(body));
            response = httpclient.execute(httpPost);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpPost.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpDel(String url, String params) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpDelete httpDelete = new HttpDelete(url + "?" + params);
        httpDelete.setHeader("Authorization", TOKEN);
        HttpResponse response;
        try {
            response = httpclient.execute(httpDelete);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpDelete.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpDel(String url, String params, String token) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpDelete httpDelete = new HttpDelete(url + "?" + params);
        httpDelete.setHeader("Authorization", token);
        HttpResponse response;
        try {
            response = httpclient.execute(httpDelete);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpDelete.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getHttpPut(String url, String body, String token) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        HttpPut httpPut = new HttpPut(url);
        httpPut.setHeader("Content-Type", "application/json");
        httpPut.setHeader("Authorization", token);
        HttpResponse response;
        try {
            httpPut.setEntity(new StringEntity(body));
            response = httpclient.execute(httpPut);
            final StatusLine status = response.getStatusLine();
            final String result = EntityUtils.toString(response.getEntity());
            httpPut.releaseConnection();
            if (status.getStatusCode() != HttpStatus.OK.value()) {
                log.error("call api failed,url: " + url);
                return null;
            }
            return result;
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
