package console.common;


/**
 * API返回标准类，统一返回格式，简化前端处理逻辑
 * 
 * @author wuwei03
 * 
 * @param <T>
 */
public class RestResponse<T> {
    /**
     * 与HTTP状态码保持一致 
     * 200：成功 
     * 201：创建自有成功 
     * 404：不存在 
     * 500：内部错误 
     * 403：无权限
     */
    private int code;

    /**
     * 错误信息，如果返回状态不正确
     */
    private String message;

    /**
     * 返回数据
     */
    private T data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

}
