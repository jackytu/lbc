package console.entity;

import java.util.List;

import console.entity.app.AppNode;

public class SpaceNode {
    private int spaceId;
    private String spaceName;
    private List<AppNode> apps;

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getSpaceName() {
        return spaceName;
    }

    public void setSpaceName(String spaceName) {
        this.spaceName = spaceName;
    }

    public List<AppNode> getApps() {
        return apps;
    }

    public void setApps(List<AppNode> apps) {
        this.apps = apps;
    }

}
