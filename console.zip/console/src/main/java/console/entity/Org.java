package console.entity;

public class Org {
    private int id;
    private String name;
    private String cnName;

    public Org() {

    }

    public Org(int id, String name, String cnName) {
        this.id = id;
        this.name = name;
        this.cnName = cnName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCnName() {
        return cnName;
    }

    public void setCnName(String cnName) {
        this.cnName = cnName;
    }

}
