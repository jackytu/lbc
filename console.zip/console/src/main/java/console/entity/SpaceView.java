package console.entity;

import java.util.List;

import console.entity.app.App;

public class SpaceView {
    private int id;
    private String name;
    private int orgId;
    private String orgName;
    private List<App> apps;
    private List<User> ops;
    private List<User> rds;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public List<App> getApps() {
        return apps;
    }

    public void setApps(List<App> apps) {
        this.apps = apps;
    }

    public List<User> getOps() {
        return ops;
    }

    public void setOps(List<User> ops) {
        this.ops = ops;
    }

    public List<User> getRds() {
        return rds;
    }

    public void setRds(List<User> rds) {
        this.rds = rds;
    }

}
