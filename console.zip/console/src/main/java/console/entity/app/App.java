package console.entity.app;

import java.util.Date;

/**
 * APP基础信息，对应表app
 * 
 * @author wuwei03
 * 
 */
public class App {
    private int id;
    private String name;
    private int org;
    private int space;
    private String svn;
    private String alarm;
    private String language;
    private String framework;
    private String accessLog;
    private Date time;
    private Date onlinetime;
    private Date offtime;

    private AppRegistryInfo info;

    public App() {

    }

    public App(String name, int org, int space, String svn, String alarm,
            String language, String framework) {
        this.name = name;
        this.org = org;
        this.space = space;
        this.svn = svn;
        this.alarm = alarm;
        this.language = language;
        this.framework = framework;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrg() {
        return org;
    }

    public void setOrg(int org) {
        this.org = org;
    }

    public int getSpace() {
        return space;
    }

    public void setSpace(int space) {
        this.space = space;
    }

    public String getSvn() {
        return svn;
    }

    public void setSvn(String svn) {
        this.svn = svn;
    }

    public String getAlarm() {
        return alarm;
    }

    public void setAlarm(String alarm) {
        this.alarm = alarm;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getFramework() {
        return framework;
    }

    public void setFramework(String framework) {
        this.framework = framework;
    }

    public String getAccessLog() {
        return accessLog;
    }

    public void setAccessLog(String accessLog) {
        this.accessLog = accessLog;
    }

    public Date getOnlinetime() {
        return onlinetime;
    }

    public void setOnlinetime(Date onlinetime) {
        this.onlinetime = onlinetime;
    }

    public Date getOfftime() {
        return offtime;
    }

    public void setOfftime(Date offtime) {
        this.offtime = offtime;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        App other = (App) obj;
        if (id != other.id) {
            return false;
        }

        return true;
    }

    public AppRegistryInfo getInfo() {
        return info;
    }

    public void setInfo(AppRegistryInfo info) {
        this.info = info;
    }

}
