package console.entity.app;

/**
 * APP监控信息，包含org及space的名字，用于监控相关功能
 * 
 * @author wuwei03
 * 
 */
public class AppMonitor {
    private int orgId;
    private String orgName;
    private int spaceId;
    private String spaceName;
    private int id;
    private String name;

    public AppMonitor() {
    }

    public AppMonitor(int orgId, String orgName, int spaceId, String spaceName, int appId, String appName) {
        this.orgId = orgId;
        this.orgName = orgName;
        this.spaceId = spaceId;
        this.spaceName = spaceName;
        this.id = appId;
        this.name = appName;
    }

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public int getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(int spaceId) {
        this.spaceId = spaceId;
    }

    public String getSpaceName() {
        return spaceName;
    }

    public void setSpaceName(String spaceName) {
        this.spaceName = spaceName;
    }

    public int getId() {
        return id;
    }

    public void setId(int appId) {
        this.id = appId;
    }

    public String getName() {
        return name;
    }

    public void setName(String appName) {
        this.name = appName;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        AppMonitor other = (AppMonitor) obj;
        if (id != other.id) {
            return false;
        }

        return true;
    }

}
