package console.entity.app;

import java.util.List;

import console.entity.Cluster;

public class AppView {
    private int id;
    private String name;
    private int pv;
    private int qps;
    private double sla;
    private String svn;
    private String language;
    private String framework;
    private List<Cluster> clusters;

    public AppView(App app) {
        id = app.getId();
        name = app.getName();
        pv = 0;
        qps = 0;
        sla = 99.99;
    }

    public AppView(App app, List<Cluster> clusters, AppQuality appQuality) {
        this.id = app.getId();
        this.name = app.getName();
        this.language = app.getLanguage();
        this.svn = app.getSvn();
        this.framework = app.getFramework();
        this.pv = appQuality.getPv();
        this.qps = appQuality.getQps();
        this.sla = appQuality.getSla() * 100;
        this.clusters = clusters;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPv() {
        return pv;
    }

    public void setPv(int pv) {
        this.pv = pv;
    }

    public double getQps() {
        return qps;
    }

    public void setQps(int qps) {
        this.qps = qps;
    }

    public double getSla() {
        return sla;
    }

    public void setSla(double sla) {
        this.sla = sla;
    }

    public String getSvn() {
        return svn;
    }

    public void setSvn(String svn) {
        this.svn = svn;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getFramework() {
        return framework;
    }

    public void setFramework(String framework) {
        this.framework = framework;
    }

    public List<Cluster> getClusters() {
        return clusters;
    }

    public void setClusters(List<Cluster> clusters) {
        this.clusters = clusters;
    }

}
