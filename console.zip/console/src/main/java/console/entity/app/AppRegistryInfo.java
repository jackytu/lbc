package console.entity.app;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AppRegistryInfo {
    @JsonProperty("app_id")
    private int app_id;
    @JsonProperty("app_name")
    private String app_name;
    private String runtime;
    private String framework;
    private String command;
    private int memory;
    private int instances;
    @JsonProperty("max_instances")
    private int max_instances;
    private String uris;
    private String target;
    @JsonProperty("rmi_port")
    private String rmi_port;
    private int state;
    private String bns;
    @JsonProperty("SmartBns")
    private boolean SmartBns;
    @JsonProperty("auto_check")
    private boolean auto_check;
    @JsonProperty("health_page")
    private String health_page;
    @JsonProperty("health_page_ret")
    private String health_page_ret;
    @JsonProperty("shutdown_delay")
    private int shutdown_delay;
    @JsonProperty("flow_switch_strategy")
    private String flow_switch_strategy;
    @JsonProperty("target_ids")
    private List<Integer> target_ids;
    private List<Integer> units;

    public int getApp_id() {
        return app_id;
    }

    public void setApp_id(int app_id) {
        this.app_id = app_id;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public String getRuntime() {
        return runtime;
    }

    public void setRuntime(String runtime) {
        this.runtime = runtime;
    }

    public String getFramework() {
        return framework;
    }

    public void setFramework(String framework) {
        this.framework = framework;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public int getMemory() {
        return memory;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public int getInstances() {
        return instances;
    }

    public void setInstances(int instances) {
        this.instances = instances;
    }

    public int getMax_instances() {
        return max_instances;
    }

    public void setMax_instances(int max_instances) {
        this.max_instances = max_instances;
    }

    public String getUris() {
        return uris;
    }

    public void setUris(String uris) {
        this.uris = uris;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public String getRmi_port() {
        return rmi_port;
    }

    public void setRmi_port(String rmi_port) {
        this.rmi_port = rmi_port;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getBns() {
        return bns;
    }

    public void setBns(String bns) {
        this.bns = bns;
    }

    public boolean isSmartBns() {
        return SmartBns;
    }

    public void setSmartBns(boolean smartBns) {
        SmartBns = smartBns;
    }

    public boolean isAuto_check() {
        return auto_check;
    }

    public void setAuto_check(boolean auto_check) {
        this.auto_check = auto_check;
    }

    public String getHealth_page() {
        return health_page;
    }

    public void setHealth_page(String health_page) {
        this.health_page = health_page;
    }

    public String getHealth_page_ret() {
        return health_page_ret;
    }

    public void setHealth_page_ret(String health_page_ret) {
        this.health_page_ret = health_page_ret;
    }

    public int getShutdown_delay() {
        return shutdown_delay;
    }

    public void setShutdown_delay(int shutdown_delay) {
        this.shutdown_delay = shutdown_delay;
    }

    public String getFlow_switch_strategy() {
        return flow_switch_strategy;
    }

    public void setFlow_switch_strategy(String flow_switch_strategy) {
        this.flow_switch_strategy = flow_switch_strategy;
    }

    public List<Integer> getTarget_ids() {
        return target_ids;
    }

    public void setTarget_ids(List<Integer> target_ids) {
        this.target_ids = target_ids;
    }

    public List<Integer> getUnits() {
        return units;
    }

    public void setUnits(List<Integer> units) {
        this.units = units;
    }

}
