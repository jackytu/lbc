package console.entity.app;

/**
 * APP节点信息，用于APP树结构
 * 
 * @author wuwei03
 * 
 */
public class AppNode {
    private int appId;
    private String appName;

    public int getAppId() {
        return appId;
    }

    public void setAppId(int appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

}
