package console.entity;

import java.util.List;

public class OrgNode {
    private int orgId;
    private String orgName;
    private List<SpaceNode> spaces;

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public List<SpaceNode> getSpaces() {
        return spaces;
    }

    public void setSpaces(List<SpaceNode> spaces) {
        this.spaces = spaces;
    }

}
