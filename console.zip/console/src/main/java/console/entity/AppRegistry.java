package console.entity;

public class AppRegistry {
    private Integer id;
    private String name;
    private Integer memory;
    private Integer instances;
    private String uris;
    private String target;
    private Integer bns;
    private String strategy;
    private int delay;
    private int smart;
    private int check;

    private String healthPage;
    private String healthRet;

    public AppRegistry() {

    }

    public AppRegistry(int id, String name, int memory, int instances, String uris,
            String target, String rmi, int bns, String strategy, int delay, int smart,
            int check,
            String healthPage, String healthRet) {
        this.id = id;
        this.name = name;
        this.memory = memory;
        this.instances = instances;
        this.uris = uris;
        this.target = target;
        this.bns = bns;
        this.strategy = strategy;
        this.delay = delay;
        this.smart = smart;
        this.check = check;
        this.healthPage = healthPage;
        this.healthRet = healthRet;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMemory() {
        return memory;
    }

    public void setMemory(Integer memory) {
        this.memory = memory;
    }

    public Integer getInstances() {
        return instances;
    }

    public void setInstances(Integer instances) {
        this.instances = instances;
    }

    public String getUris() {
        return uris;
    }

    public void setUris(String uris) {
        this.uris = uris;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    public Integer getBns() {
        return bns;
    }

    public void setBns(Integer bns) {
        this.bns = bns;
    }

    public String getStrategy() {
        return strategy;
    }

    public void setStrategy(String strategy) {
        this.strategy = strategy;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getSmart() {
        return smart;
    }

    public void setSmart(int smart) {
        this.smart = smart;
    }

    public int getCheck() {
        return check;
    }

    public void setCheck(int check) {
        this.check = check;
    }

    public String getHealthPage() {
        return healthPage;
    }

    public void setHealthPage(String healthPage) {
        this.healthPage = healthPage;
    }

    public String getHealthRet() {
        return healthRet;
    }

    public void setHealthRet(String healthRet) {
        this.healthRet = healthRet;
    }

}
