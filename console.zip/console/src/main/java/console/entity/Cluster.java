package console.entity;

public class Cluster {
    private int id;
    private String name;
    private String shortname;
    private String idc;
    private String target;
    private String pushmanager;
    private int isPrivate;

    public Cluster() {
    }

    public Cluster(String name, String shortname, String idc, String target, String pushmanager) {
        this.name = name;
        this.shortname = shortname;
        this.idc = idc;
        this.target = target;
        this.pushmanager = pushmanager;
    }

    public Cluster(int id, String name, String shortname, String idc, String target, String pushmanager) {
        this.id = id;
        this.name = name;
        this.shortname = shortname;
        this.idc = idc;
        this.target = target;
        this.pushmanager = pushmanager;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortname() {
        return shortname;
    }

    public void setShortname(String shortname) {
        this.shortname = shortname;
    }

    public String getIdc() {
        return idc;
    }

    public void setIdc(String idc) {
        this.idc = idc;
    }

    public String getTarget() {
        return target;
    }

    public String getShortTarget() {
        if (target.startsWith("http://api2.")) {
            return target.substring("http://api2.".length());
        }
        return null;
    }

    public void setTarget(String target) {
        this.target = target;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + id;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (getClass() != obj.getClass()) {
            return false;
        }

        Cluster other = (Cluster) obj;
        if (id != other.id) {
            return false;
        }

        return true;
    }

    public String getPushmanager() {
        return pushmanager;
    }

    public void setPushmanager(String pushmanager) {
        this.pushmanager = pushmanager;
    }

    public int getIsPrivate() {
        return isPrivate;
    }

    public void setIsPrivate(int isPrivate) {
        this.isPrivate = isPrivate;
    }

}
