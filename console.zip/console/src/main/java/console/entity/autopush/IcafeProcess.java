package console.entity.autopush;

import java.util.Date;

public class IcafeProcess {
    private int id;
    private int icafeId;
    private String version;
    private Date createTime;
    private String starter;
    private String group;
    private String module;
    private String optime;
    private String rdmanager;
    private String qamanager;
    private String opmanager;
    private int appId;
    private String comment;

    public IcafeProcess(int icafeId, String starter, String group,
            String module, String version, String appointOperationTime,
            String rdmanager, String opmanager, Date createTime, int appId,
            String comment) {
        this.icafeId = icafeId;
        this.starter = starter;
        this.group = group;
        this.module = module;
        this.version = version;
        this.optime = appointOperationTime;
        this.rdmanager = rdmanager;
        this.opmanager = opmanager;
        this.createTime = createTime;
        this.appId = appId;
        this.comment = comment;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIcafeId() {
        return icafeId;
    }

    public void setIcafeId(int icafeId) {
        this.icafeId = icafeId;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getStarter() {
        return starter;
    }

    public void setStarter(String starter) {
        this.starter = starter;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getOptime() {
        return optime;
    }

    public void setOptime(String optime) {
        this.optime = optime;
    }

    public String getRdmanager() {
        return rdmanager;
    }

    public void setRdmanager(String rdmanager) {
        this.rdmanager = rdmanager;
    }

    public String getQamanager() {
        return qamanager;
    }

    public void setQamanager(String qamanager) {
        this.qamanager = qamanager;
    }

    public String getOpmanager() {
        return opmanager;
    }

    public void setOpmanager(String opmanager) {
        this.opmanager = opmanager;
    }

    public int getAppId() {
        return appId;
    }

    public void setAppId(int appId) {
        this.appId = appId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}
