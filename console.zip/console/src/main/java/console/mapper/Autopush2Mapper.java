package console.mapper;

import console.entity.autopush.IcafeProcess;

public interface Autopush2Mapper {

    public IcafeProcess getProcessByAppid(int appId);

    public void addIcafeProcess(IcafeProcess process);

}
