package console.mapper;

import console.entity.AppRegistry;

public interface AppRegistryMapper {
    public AppRegistry getAppRegistryById(int id);

    public void insertAppRegistry(AppRegistry appRegistry);

    public void updateAppRegistry(AppRegistry appRegistry);

}
