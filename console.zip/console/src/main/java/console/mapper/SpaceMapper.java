package console.mapper;

import java.util.List;

import console.entity.Cluster;
import console.entity.Space;
import console.entity.User;
import console.entity.app.App;

public interface SpaceMapper {
    public void insertSpace(Space space);

    public Space getSpaceById(int id);

    public Space getSpaceByName(int orgid, String name);

    public List<Space> getAllSpaces();

    public List<Space> getIdeaSpaces();

    public void updateSpace(Space space);

    public void deleteSpace(int spaceId);

    public List<User> getSpaceUsers(int spaceId);

    public List<User> getSpaceOPs(int spaceId);

    public List<User> getSpaceRDs(int spaceId);

    public void insertSpaceUser(int spaceid, String username);

    public void addSpaceOPUser(int spaceid, String username);

    public void deleteSpaceOPUser(int spaceid, String username);

    public void addSpaceRDUser(int spaceid, String username);

    public void deleteSpaceRDUser(int spaceid, String username);

    public void insertSpaceCluster(int spaceid, int clusterid);

    public List<App> getApps(int id);

    public List<Cluster> getClusters(int id);

}
