package console.mapper;

import java.util.List;

import console.entity.Cluster;
import console.entity.Org;
import console.entity.Space;
import console.entity.User;

public interface OrgMapper {
    public Org getOrgById(int id);

    public Org getOrgByName(String name);

    public long getOrgQuota(int id);

    public long getOrgIns(int id);

    public List<Org> getAllOrgs();

    public void insertOrg(Org org);

    public List<Space> getOrgSpaces(int id);

    public void insertOrgCluster(int orgId, int clusterId);

    public void delOrgCluster(int orgId, int clusterId);

    public void updateOrg(Org org);

    public void delOrg(int id);

    public List<User> getOrgUsers(int id);

    public void insertOrgUser(int orgId, String username);

    public void delOrgUser(int orgId, String username);

    public List<Cluster> getClusters(int orgId);
}
