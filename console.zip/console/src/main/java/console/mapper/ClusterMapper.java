package console.mapper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import console.entity.Cluster;

public interface ClusterMapper {
    public Cluster getClusterById(int id);

    public List<Cluster> getAllClusters();

    public void insertCluster(Cluster cluster);

    public void updateCluster(Cluster cluster);

    public void deleteCluster(int id);

    public Map<String, Object> getClusterOnoffState();

    public void updateClusterOnoffState(@Param("state") String state,
            @Param("description") String description,
            @Param("date") Date date);
}
