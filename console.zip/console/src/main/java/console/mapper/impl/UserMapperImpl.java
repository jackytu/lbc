package console.mapper.impl;

import java.util.List;

import console.entity.OrgNode;
import console.entity.User;
import console.mapper.UserMapper;

public class UserMapperImpl implements UserMapper {
    private UserMapper userMapper;

    @Override
    public User getUserById(String username) {
        return userMapper.getUserById(username);
    }

    @Override
    public List<User> getAllUsers() {
        return userMapper.getAllUsers();
    }

    @Override
    public void deleteUser(String username) {
        userMapper.deleteUser(username);
    }

    @Override
    public void updateUser(User user) {
        userMapper.updateUser(user);
    }

    @Override
    public void insertUser(User user) {
        userMapper.insertUser(user);
    }

    @Override
    public List<OrgNode> getOrgsByAdmin(String username) {
        return userMapper.getOrgsByAdmin(username);
    }

    @Override
    public List<OrgNode> getOrgsByUser(String username) {
        return userMapper.getOrgsByUser(username);
    }

}
