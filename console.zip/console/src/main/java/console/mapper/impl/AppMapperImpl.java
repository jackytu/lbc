package console.mapper.impl;

import java.util.List;

import console.entity.app.App;
import console.entity.app.AppMonitor;
import console.mapper.AppMapper;

public class AppMapperImpl implements AppMapper {
    private AppMapper appMapper;

    @Override
    public void insertApp(App app) {
        appMapper.insertApp(app);
    }

    @Override
    public App getAppById(int id) {
        return appMapper.getAppById(id);
    }

    @Override
    public List<App> getAllApps() {
        return appMapper.getAllApps();
    }

    @Override
    public App getAppByName(String name) {
        return appMapper.getAppByName(name);
    }

    @Override
    public void updateApp(App app) {
        appMapper.updateApp(app);
    }

    @Override
    public void deleteApp(int id) {
        appMapper.deleteApp(id);
    }

    @Override
    public App queryAppByName(String name) {
        return appMapper.queryAppByName(name);
    }

    @Override
    public AppMonitor getAppMonitorById(int id) {
        return appMapper.getAppMonitorById(id);
    }

    @Override
    public List<AppMonitor> searchApp(String name) {
        return appMapper.searchApp(name);
    }

}
