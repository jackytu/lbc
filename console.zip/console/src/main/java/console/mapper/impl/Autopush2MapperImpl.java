package console.mapper.impl;

import console.entity.autopush.IcafeProcess;
import console.mapper.Autopush2Mapper;

public class Autopush2MapperImpl implements Autopush2Mapper {

    private Autopush2Mapper autopush2Mapper;

    @Override
    public IcafeProcess getProcessByAppid(int appId) {
        return autopush2Mapper.getProcessByAppid(appId);
    }

    @Override
    public void addIcafeProcess(IcafeProcess process) {
        autopush2Mapper.addIcafeProcess(process);
    }

}
