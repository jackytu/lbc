package console.mapper.impl;

import java.util.List;

import console.entity.Cluster;
import console.entity.Org;
import console.entity.Space;
import console.entity.User;
import console.mapper.OrgMapper;

public class OrgMapperImpl implements OrgMapper {
    private OrgMapper orgMapper;

    @Override
    public Org getOrgById(int id) {
        return orgMapper.getOrgById(id);
    }

    @Override
    public long getOrgQuota(int id) {
        return orgMapper.getOrgQuota(id);
    }

    @Override
    public List<Org> getAllOrgs() {
        return orgMapper.getAllOrgs();
    }

    @Override
    public long getOrgIns(int id) {
        return orgMapper.getOrgIns(id);
    }

    @Override
    public void insertOrg(Org org) {
        orgMapper.insertOrg(org);
    }

    @Override
    public List<Space> getOrgSpaces(int id) {
        return orgMapper.getOrgSpaces(id);
    }

    @Override
    public Org getOrgByName(String name) {
        return orgMapper.getOrgByName(name);
    }

    @Override
    public void insertOrgCluster(int orgId, int clusterId) {
        orgMapper.insertOrgCluster(orgId, clusterId);
    }

    @Override
    public void delOrgCluster(int orgId, int clusterId) {
        orgMapper.delOrgCluster(orgId, clusterId);
    }

    @Override
    public void updateOrg(Org org) {
        orgMapper.updateOrg(org);
    }

    @Override
    public void delOrg(int id) {
        orgMapper.delOrg(id);
    }

    @Override
    public List<User> getOrgUsers(int id) {
        return orgMapper.getOrgUsers(id);
    }

    @Override
    public void insertOrgUser(int orgId, String username) {
        orgMapper.insertOrgUser(orgId, username);
    }

    @Override
    public void delOrgUser(int orgId, String username) {
        orgMapper.delOrgUser(orgId, username);
    }

    @Override
    public List<Cluster> getClusters(int orgId) {
        return orgMapper.getClusters(orgId);
    }

}
