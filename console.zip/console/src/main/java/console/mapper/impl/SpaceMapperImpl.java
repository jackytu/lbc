package console.mapper.impl;

import java.util.List;

import console.entity.Cluster;
import console.entity.Space;
import console.entity.User;
import console.entity.app.App;
import console.mapper.SpaceMapper;

public class SpaceMapperImpl implements SpaceMapper {
    private SpaceMapper spaceMapper;

    @Override
    public void insertSpace(Space space) {
        spaceMapper.insertSpace(space);
    }

    @Override
    public Space getSpaceById(int id) {
        return spaceMapper.getSpaceById(id);
    }

    @Override
    public List<Space> getAllSpaces() {
        return spaceMapper.getAllSpaces();
    }

    @Override
    public List<Space> getIdeaSpaces() {
        return spaceMapper.getIdeaSpaces();
    }

    @Override
    public void updateSpace(Space space) {
        spaceMapper.updateSpace(space);
    }

    @Override
    public void deleteSpace(int spaceId) {
        spaceMapper.deleteSpace(spaceId);
    }

    @Override
    public List<User> getSpaceUsers(int spaceId) {
        return spaceMapper.getSpaceUsers(spaceId);
    }

    @Override
    public void insertSpaceUser(int spaceid, String username) {
        spaceMapper.insertSpaceUser(spaceid, username);
    }

    @Override
    public void insertSpaceCluster(int spaceid, int clusterid) {
        spaceMapper.insertSpaceCluster(spaceid, clusterid);
    }

    @Override
    public Space getSpaceByName(int orgid, String name) {
        return spaceMapper.getSpaceByName(orgid, name);
    }

    @Override
    public List<User> getSpaceOPs(int spaceId) {
        return spaceMapper.getSpaceOPs(spaceId);
    }

    @Override
    public List<User> getSpaceRDs(int spaceId) {
        return spaceMapper.getSpaceRDs(spaceId);
    }

    @Override
    public void addSpaceOPUser(int spaceid, String username) {
        spaceMapper.addSpaceOPUser(spaceid, username);
    }

    @Override
    public void addSpaceRDUser(int spaceid, String username) {
        spaceMapper.addSpaceRDUser(spaceid, username);
    }

    @Override
    public List<App> getApps(int id) {
        return spaceMapper.getApps(id);
    }

    @Override
    public void deleteSpaceOPUser(int spaceid, String username) {
        spaceMapper.deleteSpaceOPUser(spaceid, username);
    }

    @Override
    public void deleteSpaceRDUser(int spaceid, String username) {
        spaceMapper.deleteSpaceRDUser(spaceid, username);
    }

    @Override
    public List<Cluster> getClusters(int id) {
        return spaceMapper.getClusters(id);
    }

}
