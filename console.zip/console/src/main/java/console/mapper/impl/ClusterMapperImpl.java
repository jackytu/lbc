package console.mapper.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import console.entity.Cluster;
import console.mapper.ClusterMapper;

public class ClusterMapperImpl implements ClusterMapper {
    private ClusterMapper clusterMapper;

    @Override
    public Cluster getClusterById(int id) {
        return clusterMapper.getClusterById(id);
    }

    @Override
    public List<Cluster> getAllClusters() {
        return clusterMapper.getAllClusters();
    }

    @Override
    public void updateCluster(Cluster cluster) {
        clusterMapper.updateCluster(cluster);
    }

    @Override
    public void deleteCluster(int id) {
        clusterMapper.deleteCluster(id);
    }

    @Override
    public void insertCluster(Cluster cluster) {
        clusterMapper.insertCluster(cluster);
    }

    @Override
    public Map<String, Object> getClusterOnoffState() {
        return clusterMapper.getClusterOnoffState();
    }

    @Override
    public void updateClusterOnoffState(String state, String description,
            Date date) {
        clusterMapper.updateClusterOnoffState(state, description, date);
    }

}
