package console.mapper.impl;

import console.entity.AppRegistry;
import console.mapper.AppRegistryMapper;

public class AppRegistryMapperImpl implements AppRegistryMapper {
    private AppRegistryMapper appRegistryMapper;

    @Override
    public AppRegistry getAppRegistryById(int id) {
        return appRegistryMapper.getAppRegistryById(id);
    }

    @Override
    public void insertAppRegistry(AppRegistry appRegistry) {
        appRegistryMapper.insertAppRegistry(appRegistry);
    }

    @Override
    public void updateAppRegistry(AppRegistry appRegistry) {
        appRegistryMapper.updateAppRegistry(appRegistry);
    }

}
