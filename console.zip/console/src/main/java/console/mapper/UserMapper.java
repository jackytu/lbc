package console.mapper;

import java.util.List;

import console.entity.OrgNode;
import console.entity.User;

public interface UserMapper {
    public User getUserById(String username);

    public List<User> getAllUsers();

    public void deleteUser(String username);

    public void updateUser(User user);

    public void insertUser(User user);

    public List<OrgNode> getOrgsByAdmin(String username);

    public List<OrgNode> getOrgsByUser(String username);
}
