package console.mapper;

import java.util.List;

import console.entity.app.App;
import console.entity.app.AppMonitor;

public interface AppMapper {
    public void insertApp(App app);

    public App getAppById(int id);

    public List<App> getAllApps();

    public App getAppByName(String name);

    public App queryAppByName(String name);

    public void updateApp(App app);

    public void deleteApp(int id);

    public AppMonitor getAppMonitorById(int id);

    public List<AppMonitor> searchApp(String name);
}
