package console.service;

import java.util.List;
import java.util.Map;

import console.entity.Cluster;

public interface ClusterService {
    public abstract Cluster queryClusterById(int id);

    public abstract List<Cluster> getAllClusters();

    public abstract void insertCluster(Cluster cluster);

    public abstract void updateCluster(Cluster cluster);

    public abstract void deleteCluster(int id);

    public abstract Map<String, Object> getClusterOnoffState();

    public abstract void updateClusterOnoffState(String state,
            String description);
}
