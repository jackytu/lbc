package console.service;

import console.entity.AppRegistry;

public interface AppRegistryService {
    public abstract AppRegistry getAppRegistryById(int id);

    public abstract void insertAppRegistry(AppRegistry appRegistry);

    public abstract void updateAppRegistry(AppRegistry appRegistry);

}
