package console.service;

import java.util.List;

import console.common.UnauthorizedException;
import console.entity.OrgNode;
import console.entity.User;

public interface UserService {
    public abstract User getUserById(String username);

    public abstract List<User> getAllUsers();

    public abstract void addUser(String username);

    public abstract void deleteUser(String username);

    public abstract void updateUser(User user);

    public abstract boolean isAdmin();

    public abstract boolean isSpaceOP(int spaceid);

    public abstract boolean isSpaceRD(int spaceid);

    public abstract boolean isOrgAdmin(int orgid);

    public abstract String getUsername();

    public abstract List<OrgNode> getOrgsByAdmin(String username);

    public abstract List<OrgNode> getOrgsByUser(String username);

    public abstract void needAdmin() throws UnauthorizedException;

    public abstract void needOrgAdmin(int orgid) throws UnauthorizedException;

    public abstract void needSpaceOP(int spaceid) throws UnauthorizedException;

    public abstract void needSpaceRD(int spaceid) throws UnauthorizedException;
}
