package console.service.impl;

import java.util.List;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import console.common.UnauthorizedException;
import console.entity.OrgNode;
import console.entity.Space;
import console.entity.User;
import console.mapper.OrgMapper;
import console.mapper.SpaceMapper;
import console.mapper.UserMapper;
import console.service.UserService;

@Service(value = "userService")
@Transactional(readOnly = true)
public class UserServiceImpl implements UserService {
    @Value("${admin.users}")
    private String admins;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private SpaceMapper spaceMapper;

    @Autowired
    private OrgMapper orgMapper;

    @Override
    public User getUserById(String username) {
        return userMapper.getUserById(username);
    }

    @Override
    public List<User> getAllUsers() {
        return userMapper.getAllUsers();
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteUser(String username) {
        userMapper.deleteUser(username);
    }

    @Override
    @Transactional(readOnly = false)
    public void updateUser(User user) {
        userMapper.updateUser(user);
    }

    @Override
    @Transactional(readOnly = false)
    public void addUser(String username) {
        User user = new User();
        user.setUsername(username);
        userMapper.insertUser(user);
    }

    @Override
    public boolean isAdmin() {
        String username = getUsername();
        if (admins.contains(username)) {
            return true;
        }
        return false;
    }

    @Override
    public List<OrgNode> getOrgsByAdmin(String username) {
        return userMapper.getOrgsByAdmin(username);
    }

    @Override
    public List<OrgNode> getOrgsByUser(String username) {
        return userMapper.getOrgsByUser(username);
    }

    @Override
    public String getUsername() {
        Subject subject = SecurityUtils.getSubject();
        return (String) subject.getPrincipals().getPrimaryPrincipal();
    }

    @Override
    public boolean isSpaceOP(int spaceid) {
        String username = getUsername() + "@baidu.com";
        List<User> users = spaceMapper.getSpaceOPs(spaceid);
        return users.contains(new User(username));
    }

    @Override
    public boolean isSpaceRD(int spaceid) {
        String username = getUsername() + "@baidu.com";
        List<User> users = spaceMapper.getSpaceRDs(spaceid);
        return users.contains(new User(username));
    }

    @Override
    public boolean isOrgAdmin(int orgid) {
        String username = getUsername() + "@baidu.com";
        List<User> users = orgMapper.getOrgUsers(orgid);
        return users.contains(new User(username));
    }

    @Override
    public void needAdmin() throws UnauthorizedException {
        if (!isAdmin()) {
            throw new UnauthorizedException();
        }
    }

    @Override
    public void needOrgAdmin(int orgid) throws UnauthorizedException {
        if (isAdmin() || isOrgAdmin(orgid)) {
            return;
        }
        throw new UnauthorizedException();
    }

    @Override
    public void needSpaceOP(int spaceid) throws UnauthorizedException {
        if (isAdmin()) {
            return;
        }
        Space space = spaceMapper.getSpaceById(spaceid);
        if (space != null && isOrgAdmin(space.getOrg())) {
            return;
        }
        if (!isSpaceOP(spaceid)) {
            throw new UnauthorizedException();
        }
    }

    @Override
    public void needSpaceRD(int spaceid) throws UnauthorizedException {
        if (isAdmin()) {
            return;
        }
        Space space = spaceMapper.getSpaceById(spaceid);
        if (space != null && isOrgAdmin(space.getOrg())) {
            return;
        }
        if (isSpaceOP(spaceid) || isSpaceRD(spaceid)) {
            return;
        }
        throw new UnauthorizedException();
    }

}
