package console.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import console.entity.Cluster;
import console.mapper.ClusterMapper;
import console.service.ClusterService;

@Service(value = "clusterService")
@Transactional(readOnly = true)
public class ClusterServiceImpl implements ClusterService {
    @Autowired
    private ClusterMapper clusterMapper;

    @Override
    public Cluster queryClusterById(int id) {
        return clusterMapper.getClusterById(id);
    }

    @Override
    public List<Cluster> getAllClusters() {
        return clusterMapper.getAllClusters();
    }

    @Override
    @Transactional(readOnly = false)
    public void updateCluster(Cluster cluster) {
        clusterMapper.updateCluster(cluster);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteCluster(int id) {
        clusterMapper.deleteCluster(id);
    }

    @Override
    @Transactional(readOnly = false)
    public void insertCluster(Cluster cluster) {
        clusterMapper.insertCluster(cluster);
    }

    @Override
    public Map<String, Object> getClusterOnoffState() {
        return clusterMapper.getClusterOnoffState();
    }

    @Override
    @Transactional(readOnly = false)
    public void updateClusterOnoffState(String state, String description) {
        clusterMapper.updateClusterOnoffState(state, description, new Date());
    }

}
