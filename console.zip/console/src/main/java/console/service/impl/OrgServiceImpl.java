package console.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import console.entity.Cluster;
import console.entity.Org;
import console.entity.Space;
import console.entity.User;
import console.mapper.OrgMapper;
import console.service.OrgService;
import console.service.UserService;

@Service(value = "orgService")
@Transactional(readOnly = true)
public class OrgServiceImpl implements OrgService {
    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private UserService userService;

    @Override
    public Org queryOrgById(int id) {
        return orgMapper.getOrgById(id);
    }

    @Override
    public List<Org> getAllOrgs() {
        return orgMapper.getAllOrgs();
    }

    @Override
    @Transactional(readOnly = false)
    public void addOrg(Org org) {
        orgMapper.insertOrg(org);
    }

    @Override
    public List<Space> getOrgSpaces(int id) {
        return orgMapper.getOrgSpaces(id);
    }

    @Override
    public Org getOrgByName(String name) {
        return orgMapper.getOrgByName(name);
    }

    @Override
    @Transactional(readOnly = false)
    public void updateOrg(Org org) {
        orgMapper.updateOrg(org);
    }

    @Override
    @Transactional(readOnly = false)
    public void delOrg(int id) {
        orgMapper.delOrg(id);
    }

    @Override
    public List<User> getOrgUsers(int id) {
        return orgMapper.getOrgUsers(id);
    }

    @Override
    @Transactional(readOnly = false)
    public void insertOrgUser(int orgId, String username) {
        if (userService.getUserById(username) == null) {
            userService.addUser(username);
        }
        orgMapper.insertOrgUser(orgId, username);
    }

    @Override
    @Transactional(readOnly = false)
    public void delOrgUser(int orgId, String username) {
        orgMapper.delOrgUser(orgId, username);
    }

    @Override
    public List<Cluster> getClusters(int orgId) {
        return orgMapper.getClusters(orgId);
    }

}
