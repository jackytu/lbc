package console.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import console.entity.AppRegistry;
import console.mapper.AppRegistryMapper;
import console.service.AppRegistryService;

@Service(value = "appRegistryService")
@Transactional(readOnly = true)
public class AppRegistryServiceImpl implements AppRegistryService {
    @Autowired
    private AppRegistryMapper appRegistryMapper;

    @Override
    public AppRegistry getAppRegistryById(int id) {
        return appRegistryMapper.getAppRegistryById(id);
    }

    @Override
    @Transactional(readOnly = false)
    public void insertAppRegistry(AppRegistry appRegistry) {
        appRegistryMapper.insertAppRegistry(appRegistry);
    }

    @Override
    @Transactional(readOnly = false)
    public void updateAppRegistry(AppRegistry appRegistry) {
        appRegistryMapper.updateAppRegistry(appRegistry);
    }

}
