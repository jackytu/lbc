package console.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import console.common.HttpProxy;
import console.common.RestResponse;
import console.entity.Cluster;
import console.entity.app.App;
import console.entity.app.AppRegistryInfo;
import console.entity.autopush.IcafeProcess;
import console.mapper.Autopush2Mapper;
import console.service.AppService;
import console.service.Autopush2Service;
import console.service.ClusterService;
import console.service.SpaceService;
import console.service.UserService;

@Service(value = "autopush2Service")
@Transactional(readOnly = true)
public class Autopush2ServiceImpl implements Autopush2Service {
    private static Logger log = LoggerFactory
            .getLogger(Autopush2ServiceImpl.class);
    @Value("${autopush.clusterapi}")
    private String clusterApi;
    @Value("${autopush.icaferdapi}")
    private String icafeRdApi;
    @Value("${autopush.icafeciapi}")
    private String icafeCiApi;
    @Value("${autopush.iopapi}")
    private String iopApi;
    private static final String TOKEN = "ibXfcmVxjhy9rfwKjuttLH1VvWsTAymoy3fKYGMd";
    @Autowired
    private AppService appService;

    @Autowired
    private ClusterService clusterService;

    @Autowired
    private SpaceService spaceService;

    @Autowired
    private UserService userService;

    @Autowired
    private Autopush2Mapper autopush2Mapper;

    @Override
    public List<Integer> getConcurrencyList(int instances) {
        List<Integer> concurrencyList = new ArrayList<Integer>();
        for (int i = 2; i < instances / 2 + 1; i++) {
            if (instances % i == 0) {
                concurrencyList.add(i);
            }
        }
        return concurrencyList;
    }

    @Override
    public List<Integer> getTargetIds(int appId) {
        List<Integer> targetIdsList = new ArrayList<Integer>();
        try {
            List<Cluster> clusters = clusterService.getAllClusters();
            AppRegistryInfo appInfo = appService.getAppRegistryInfo(appId);
            String[] targets = appInfo.getTarget().split(",");
            for (Cluster cluster : clusters) {
                for (String target : targets) {
                    if (target.contains(cluster.getShortname())) {
                        targetIdsList.add(cluster.getId());
                    }
                }
            }
        } catch (Exception e) {
            log.error("[autopush2][getTargetIds][error=" + e.getMessage() + "]");
        }
        return targetIdsList;
    }

    @Override
    public List<Integer> getTargetIds(String targets) {
        List<Integer> targetIdsList = new ArrayList<Integer>();
        try {
            List<Cluster> clusters = clusterService.getAllClusters();
            String[] targetsArray = targets.split(",");
            for (Cluster cluster : clusters) {
                for (String target : targetsArray) {
                    if (target.contains(cluster.getShortname())) {
                        targetIdsList.add(cluster.getId());
                    }
                }
            }
        } catch (Exception e) {
            log.error("[autopush2][getTargetIds][error=" + e.getMessage() + "]");
        }
        return targetIdsList;
    }

    @Override
    public String getHost(int appId, String type, String protocol) {
        String host = "";
        try {
            App app = appService.getAppById(appId);
            if (app != null) {
                List<Cluster> clusterIds = spaceService.getSpaceClusters(app
                        .getSpace());
                if (protocol == null) {
                    host = "http://" + clusterIds.get(0).getPushmanager();
                }
                else if (protocol.equals("ws")) {
                    host = "ws://" + clusterIds.get(0).getPushmanager();
                }
            }
        } catch (Exception e) {
            log.error("[autopush2][get_host][error=" + e.getMessage() + "]");
        }
        return host;
    }

    @Override
    public int getAppIdFromProcess(int processId) {
        int result = 0;
        Gson gson = new Gson();
        String appStatusResponse = getStatusByProcessid(processId);
        Map<String, Object> response = gson.fromJson(appStatusResponse,
                new TypeToken<Map<String, Object>>() {
                }.getType());
        if (!"fail".equals(String.valueOf(response.get("State")))) {
            result = ((Double) response.get("app_id")).intValue();
        }
        return result;
    }

    @Override
    public RestResponse<String> icafeRd(String appointOperationTime,
            String rdOperationTargetDesc, String userName, String rdManager,
            String orgSvn) {
        Gson gson = new Gson();
        RestResponse<String> result = new RestResponse<String>();
        Map<String, Object> autoProcessData = new HashMap<String, Object>();
        Map<String, Object> onlineForm = new HashMap<String, Object>();
        Map<String, Object> processParticipantList = new HashMap<String, Object>();
        autoProcessData.put("group", orgSvn);
        autoProcessData.put("icafe_Data_ModelAppDefine",
                "icafe_pkg_8488,baidu_ITE_pkg_7469_prs1");
        autoProcessData.put("needSsl", 0);
        autoProcessData.put("process_starter", userName);
        autoProcessData.put("process_title", "jpaas rd自主上线流程");
        autoProcessData.put("online_form", onlineForm);
        autoProcessData.put("participant_list", processParticipantList);

        onlineForm.put("rdOperationSystem", "jpaas");
        onlineForm.put("rdOperationTargetDesc", rdOperationTargetDesc);
        onlineForm.put("rdOperationStepDesc", "使用jpaas上线系统完成");
        onlineForm.put("rdOperationRollBack", "使用jpaas上线系统回滚");
        onlineForm.put("appointOperationTime", appointOperationTime);
        onlineForm.put("effectDataBase", "");
        onlineForm.put("BPM_ACT_COMPLETE_MAIL_CC", "");

        processParticipantList.put("yanfaxiangmujingli", rdManager);
        processParticipantList.put("opxiangmujingli", "");
        processParticipantList.put("baidu_ITE_pkg_7469_prs1_p2", userName);
        processParticipantList.put("baidu_ITE_pkg_7469_prs1_p3", "");

        try {
            String response = HttpProxy.getHttpPost(icafeRdApi,
                    gson.toJson(autoProcessData));
            result.setCode(HttpStatus.OK.value());
            result.setData(response);
        } catch (Exception e) {
            result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            result.setMessage(e.getMessage());
        }

        return result;
    }

    @Override
    public RestResponse<String> icafeCi(String appointOperationTime,
            String rdOperationTargetDesc, String userName, String rdManager,
            String qaManager, String orgSvn, String appSvn) {
        Gson gson = new Gson();
        RestResponse<String> result = new RestResponse<String>();
        Map<String, Object> autoProcessData = new HashMap<String, Object>();
        Map<String, Object> onlineForm = new HashMap<String, Object>();
        List<Map<String, Object>> moduleList = new ArrayList<Map<String, Object>>();
        Map<String, Object> processParticipantList = new HashMap<String, Object>();
        Map<String, Object> module = new HashMap<String, Object>();

        autoProcessData.put("group", orgSvn);
        autoProcessData.put("cafe_Data_ModelAppDefine",
                "icafe_pkg_9400,baidu_ITE_pkg_7469_prs1");
        autoProcessData.put("needSsl", 0);
        autoProcessData.put("sslReason", "test");
        autoProcessData.put("online_form", onlineForm);
        autoProcessData.put("module_list", moduleList);
        autoProcessData.put("participant_list", processParticipantList);
        autoProcessData.put("process_starter", userName);

        onlineForm.put("rdOperationSystem", "jpaas");
        onlineForm.put("rdOperationTargetDesc", rdOperationTargetDesc);
        onlineForm.put("rdOperationStepDesc", "使用jpaas上线系统完成");
        onlineForm.put("rdOperationRollBack", "使用jpaas上线系统回滚");
        onlineForm.put("appointOperationTime", appointOperationTime);

        module.put("module", appSvn);
        moduleList.add(module);

        processParticipantList.put("yanfaxiangmujingli", rdManager);
        processParticipantList.put("ceshixiangmujingli", qaManager);
        processParticipantList.put("opxiangmujingli", "");
        processParticipantList.put("baidu_ITE_pkg_7469_prs1_p2", userName);

        try {
            String response = HttpProxy.getHttpPost(icafeCiApi,
                    gson.toJson(autoProcessData));
            result.setCode(HttpStatus.OK.value());
            result.setData(response);
        } catch (Exception e) {
            result.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            result.setMessage(e.getMessage());
        }
        return result;
    }

    @Override
    public String getLatestScm(String appSvn) {
        return HttpProxy.getHttpGet(iopApi + "?app_svn=" + appSvn);
    }

    @Override
    public String getStatusByProcessid(int processId) {
        String appStatusResponse = HttpProxy.getHttpGet(clusterApi
                + "/autopush/api2/operation/operation_id/" + processId, TOKEN);
        return appStatusResponse;
    }

    @Override
    public String checkMd5(String name, String ftp) {
        String api = String.format("%s/autopush/api2/md5?app_name=%s&ftp=%s",
                clusterApi, name, ftp);
        String result = HttpProxy.getHttpGet(api, TOKEN);
        return result;
    }

    @Override
    public String getAutopushState() {
        String url = String.format("%s/api/cluster/onoff", clusterApi);
        log.info("[get_autopush_state][url]" + url);
        String result = HttpProxy.getHttpGet(url);
        return result;
    }

    @Override
    public IcafeProcess getProcessByAppid(int appId) {
        return autopush2Mapper.getProcessByAppid(appId);
    }

    @Override
    public String addIcafeProcess(IcafeProcess process) {
        String result = "";
        try {
            autopush2Mapper.addIcafeProcess(process);
            result = "success";
        } catch (Exception e) {
            log.error("[autopush][insert icafe process][msg:" + e.getMessage()
                    + "]");
            result = null;
        }

        return result;
    }
}
