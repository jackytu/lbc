package console.service.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import console.common.HttpProxy;
import console.entity.User;
import console.entity.app.App;
import console.entity.app.AppMonitor;
import console.entity.app.AppRegistryInfo;
import console.mapper.AppMapper;
import console.mapper.OrgMapper;
import console.mapper.SpaceMapper;
import console.service.AppService;

@Service(value = "appService")
@Transactional(readOnly = true)
public class AppServiceImpl implements AppService {
    private static Logger log = LoggerFactory.getLogger(AppServiceImpl.class);
    // 加到配置
    @Value("${autopush.scmapi}")
    private String scmApi = "http://scm.baidu.com";
    @Value("${autopush.clusterapi}")
    private String clusterApi;
    @Autowired
    private AppMapper appMapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private SpaceMapper spaceMapper;

    @Override
    public App getAppById(int id) {
        return appMapper.getAppById(id);
    }

    @Override
    public App getAppByName(String name) {
        return appMapper.getAppByName(name);
    }

    @Override
    public List<App> getAllApps() {
        return appMapper.getAllApps();
    }

    @Override
    public List<User> getAppUsersById(int id) {
        App app = appMapper.getAppById(id);
        if (app == null) {
            return null;
        }
        return spaceMapper.getSpaceUsers(app.getSpace());
    }

    @Override
    @Transactional(readOnly = false)
    public void insertApp(App app) {
        appMapper.insertApp(app);
    }

    @Override
    @Transactional(readOnly = false)
    public void updateApp(App app) {
        appMapper.updateApp(app);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteApp(int id) {
        appMapper.deleteApp(id);
    }

    @Override
    public AppMonitor getAppMonitorById(int id) {
        return appMapper.getAppMonitorById(id);
    }

    @Override
    public List<AppMonitor> searchApp(String name) {
        if (name.length() < MIN_SEARCH_LEN) {
            return null;
        }
        return appMapper.searchApp(name);
    }

    @Override
    public String getScmSvn(App app) {
        Gson gson = new Gson();

        String result = "";
        String appSvn = app.getSvn();
        log.info("[appservice][appsvn]" + appSvn);
        String scmSvn = HttpProxy.getHttpGet(scmApi
                + "/http/getProductPathOfLeastCiVersion.action?cvspath="
                + appSvn);
        log.info("[appservice][scmsvn]" + scmSvn);
        if (scmSvn != null) {
            Map<String, Object> scmMap = gson.fromJson(scmSvn,
                    new TypeToken<Map<String, Object>>() {
                    }.getType());
            if ((double) scmMap.get("errno") == 0) {
                result = String.valueOf(scmMap.get("result"));
            }
        }
        return result;
    }

    @Override
    public AppRegistryInfo getAppRegistryInfo(int id) {
        Gson gson = new Gson();
        AppRegistryInfo result = new AppRegistryInfo();
        String appInfoResponse = HttpProxy.getHttpGet(clusterApi
                + "/autopush/api/app_registry/" + id);
        if (!appInfoResponse.equals("null")) {
            try {
                result = gson.fromJson(appInfoResponse,
                        new TypeToken<AppRegistryInfo>() {
                        }.getType());
            } catch (Exception e) {
                log.error("[AppService][getAppRegistryInfo][fail transform response][message]"
                        + e.getMessage());
            }
        }
        return result;
    }
}
