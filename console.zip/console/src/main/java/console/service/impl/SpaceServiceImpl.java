package console.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import console.common.HttpProxy;
import console.entity.Cluster;
import console.entity.Org;
import console.entity.Space;
import console.entity.User;
import console.entity.app.App;
import console.mapper.ClusterMapper;
import console.mapper.OrgMapper;
import console.mapper.SpaceMapper;
import console.service.AppService;
import console.service.SpaceService;

@Service(value = "spaceService")
@Transactional(readOnly = true)
public class SpaceServiceImpl implements SpaceService {
    private static Logger log = LoggerFactory.getLogger(SpaceServiceImpl.class);

    private static final String SPACEURI = "http://jpaas.baidu.com/api2/spaces";
    @Autowired
    private SpaceMapper spaceMapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private AppService appService;

    @Autowired
    private ClusterMapper clusterMapper;

    @Override
    public Space querySpaceById(int id) {
        return spaceMapper.getSpaceById(id);
    }

    @Override
    public List<User> querySpaceUsers(int id) {
        return spaceMapper.getSpaceUsers(id);
    }

    @Override
    @Transactional(readOnly = false)
    public void addSpace(Space space) {
        spaceMapper.insertSpace(space);
    }

    @Override
    @Transactional(readOnly = false)
    public void insertSpaceUser(int spaceid, String username) {
        spaceMapper.insertSpaceUser(spaceid, username);
    }

    @Override
    @Transactional(readOnly = false)
    public void insertSpaceCluster(int spaceid, int clusterid) {
        spaceMapper.insertSpaceCluster(spaceid, clusterid);
    }

    @Override
    public Space getSpaceByName(int orgid, String name) {
        return spaceMapper.getSpaceByName(orgid, name);
    }

    @Override
    public List<User> getSpaceUsers(int spaceId) {
        return spaceMapper.getSpaceUsers(spaceId);
    }

    @Override
    public List<User> getSpaceOPs(int spaceId) {
        return spaceMapper.getSpaceOPs(spaceId);
    }

    @Override
    public List<User> getSpaceRDs(int spaceId) {
        return spaceMapper.getSpaceRDs(spaceId);
    }

    @Override
    @Transactional(readOnly = false)
    public void addSpaceOPUser(int spaceid, String username) {
        spaceMapper.addSpaceOPUser(spaceid, username);
    }

    @Override
    @Transactional(readOnly = false)
    public void addSpaceRDUser(int spaceid, String username) {
        spaceMapper.addSpaceRDUser(spaceid, username);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteSpace(int spaceId) {
        // delete space in cluster
        Space space = spaceMapper.getSpaceById(spaceId);
        List<Cluster> clusters = spaceMapper.getClusters(spaceId);
        Org org = orgMapper.getOrgById(space.getOrg());
        for (Cluster cluster : clusters) {
            String params = "org=" + org.getName() + "&space="
                    + space.getName() + "&target="
                    + cluster.getShortTarget();
            HttpProxy.getHttpDel(SPACEURI, params);
        }
        // delete space in console
        spaceMapper.deleteSpace(spaceId);
    }

    @Override
    public List<App> getApps(int id) {
        return spaceMapper.getApps(id);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteSpaceOPUser(int spaceid, String username) {
        spaceMapper.deleteSpaceOPUser(spaceid, username);
    }

    @Override
    @Transactional(readOnly = false)
    public void deleteSpaceRDUser(int spaceid, String username) {
        spaceMapper.deleteSpaceRDUser(spaceid, username);
    }

    @Override
    public List<Space> getAllSpaces() {
        return spaceMapper.getAllSpaces();
    }

    @Override
    @Transactional(readOnly = false)
    public void addSpace(Space space, int clusterId) {
        // add space
        spaceMapper.insertSpace(space);
        // add space cluster info
        spaceMapper.insertSpaceCluster(space.getId(), clusterId);

        // create space in cluster
        Org org = orgMapper.getOrgById(space.getOrg());
        Cluster cluster = clusterMapper.getClusterById(clusterId);
        String body = "{\"target\":\"" + cluster.getShortTarget()
                + "\",\"space\":\"" + space.getName() + "\",\"org\":\""
                + org.getName() + "\"}";
        String result = HttpProxy.getHttpPost(SPACEURI, body);
        if (result.isEmpty() || !result.contains("\"ok")) {
            log.error("create space in cluster failed,return is: " + result);
            throw new RuntimeException();
        }

        // create space bns in giano
    }

    @Override
    public List<Cluster> getSpaceClusters(int id) {
        return spaceMapper.getClusters(id);
    }

}
