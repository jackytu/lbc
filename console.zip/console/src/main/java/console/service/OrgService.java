package console.service;

import java.util.List;

import console.entity.Cluster;
import console.entity.Org;
import console.entity.Space;
import console.entity.User;

public interface OrgService {
    public abstract Org queryOrgById(int id);

    public abstract Org getOrgByName(String name);

    public abstract List<Org> getAllOrgs();

    public abstract void addOrg(Org org);

    public abstract List<Space> getOrgSpaces(int id);

    public abstract void updateOrg(Org org);

    public abstract void delOrg(int id);

    public abstract List<User> getOrgUsers(int id);

    public abstract void insertOrgUser(int orgId, String username);

    public abstract void delOrgUser(int orgId, String username);

    public abstract List<Cluster> getClusters(int orgId);
}
