package console.service;

import java.util.List;

import console.common.RestResponse;
import console.entity.autopush.IcafeProcess;

public interface Autopush2Service {
    public List<Integer> getConcurrencyList(int instances);

    public List<Integer> getTargetIds(int appId);

    public List<Integer> getTargetIds(String targets);

    public String getHost(int appId, String type, String protocol);

    public int getAppIdFromProcess(int processId);

    public RestResponse<String> icafeRd(String appointOperationTime,
            String rdOperationTargetDesc, String userName, String rdManager,
            String orgSvn);

    public RestResponse<String> icafeCi(String appointOperationTime,
            String rdOperationTargetDesc, String userName, String rdManager,
            String qaManager, String orgSvn, String appSvn);

    public String getLatestScm(String appSvn);

    public String getStatusByProcessid(int processId);

    public String checkMd5(String name, String ftp);

    public String getAutopushState();

    public IcafeProcess getProcessByAppid(int appId);

    public String addIcafeProcess(IcafeProcess process);

}
