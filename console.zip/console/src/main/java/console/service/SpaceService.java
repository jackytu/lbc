package console.service;

import java.util.List;

import console.entity.Cluster;
import console.entity.Space;
import console.entity.User;
import console.entity.app.App;

public interface SpaceService {
    public abstract void addSpace(Space space);

    public abstract void addSpace(Space space, int clusterId);

    public abstract Space querySpaceById(int id);

    public abstract List<User> querySpaceUsers(int id);

    public abstract Space getSpaceByName(int orgid, String name);

    public abstract List<User> getSpaceOPs(int spaceId);

    public abstract List<User> getSpaceRDs(int spaceId);

    public abstract void insertSpaceUser(int spaceid, String username);

    public abstract void insertSpaceCluster(int spaceid, int clusterid);

    public abstract List<User> getSpaceUsers(int spaceId);

    public abstract void addSpaceOPUser(int spaceid, String username);

    public abstract void deleteSpaceOPUser(int spaceid, String username);

    public abstract void addSpaceRDUser(int spaceid, String username);

    public abstract void deleteSpaceRDUser(int spaceid, String username);

    public abstract void deleteSpace(int spaceId);

    public abstract List<App> getApps(int id);

    public abstract List<Space> getAllSpaces();

    public abstract List<Cluster> getSpaceClusters(int id);

}
