package console.service;

import java.util.List;

import console.entity.User;
import console.entity.app.App;
import console.entity.app.AppMonitor;
import console.entity.app.AppRegistryInfo;

public interface AppService {
    public static final int MIN_SEARCH_LEN = 2;

    public abstract void insertApp(App app);

    public abstract void updateApp(App app);

    public abstract App getAppById(int id);

    public abstract App getAppByName(String name);

    public abstract List<App> getAllApps();

    public abstract List<User> getAppUsersById(int id);

    public abstract AppMonitor getAppMonitorById(int id);

    public abstract List<AppMonitor> searchApp(String name);

    public abstract void deleteApp(int id);

    public abstract String getScmSvn(App app);

    public abstract AppRegistryInfo getAppRegistryInfo(int id);

}
