package console.controller;

import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import console.common.BabelClient;
import console.common.RestResponse;
import console.entity.OrgNode;
import console.entity.User;
import console.service.UserService;

/**
 * 用户API
 * 
 * @author wuwei03
 * 
 */
@Controller
@RequestMapping("api/users")
public class UserController {
    @Autowired
    private BabelClient babelClient;

    private static Logger log = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/tree", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RestResponse<List<OrgNode>> treeView() {
        RestResponse<List<OrgNode>> result = new RestResponse<List<OrgNode>>();
        result.setCode(HttpStatus.SC_OK);
        String username = userService.getUsername();
        List<OrgNode> nodes = userService.getOrgsByAdmin(username + "@baidu.com");
        nodes.addAll(userService.getOrgsByUser(username + "@baidu.com"));
        result.setData(nodes);
        return result;
    }

    /**
     * 获取用户详情
     * 
     * @param username
     * @return
     */
    @RequestMapping(value = "/{username:.+}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RestResponse<User> userInfo(@PathVariable String username) {
        RestResponse<User> result = new RestResponse<User>();
        User user = userService.getUserById(username);
        result.setCode(HttpStatus.SC_OK);
        result.setData(user);
        return result;
    }

    /**
     * 删除用户
     * 
     * @param username
     */
    @RequestMapping(value = "/{username:.+}", method = RequestMethod.DELETE, produces = "application/json")
    @ResponseBody
    public void delUser(@PathVariable String username) {
        userService.deleteUser(username);
    }

    @RequestMapping(value = "/query", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RestResponse<List<Map<String, String>>> queryUserInfo(@RequestParam String keyword) {
        return babelClient.getUserInfo(keyword);
    }
}
