package console.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import console.common.HttpProxy;
import console.common.RestResponse;
import console.common.UnauthorizedException;
import console.entity.Cluster;
import console.entity.Org;
import console.entity.app.App;
import console.entity.app.AppRegistryInfo;
import console.entity.autopush.IcafeProcess;
import console.service.AppService;
import console.service.Autopush2Service;
import console.service.ClusterService;
import console.service.OrgService;
import console.service.SpaceService;
import console.service.UserService;

/**
 * Autopush2操作相关API
 * 
 * @author handing
 * 
 */
@Controller
@RequestMapping("api/autopush2")
public class Autopush2Controller {
    private static Logger log = LoggerFactory
            .getLogger(Autopush2Controller.class);
    @Value("${autopush.clusterapi}")
    private String clusterApi;
    @Value("${autopush.log}")
    private String autopushLog2;
    @Value("${autopush.staticversion}")
    private String staticVersion;
    @Value("${autopush.env}")
    private String env;
    @Value("${autopush.icaferdapi}")
    private String icafeRdApi;
    @Value("${autopush.icafeciapi}")
    private String icafeCiApi;
    @Value("${autopush.icafeprocessapi}")
    private String icafeProcessApi;
    @Value("${autopush.icafecompleteapi}")
    private String icafeCompleteApi;

    private static final String TOKEN = "ibXfcmVxjhy9rfwKjuttLH1VvWsTAymoy3fKYGMd";

    @Autowired
    private Autopush2Service autopush2Service;

    @Autowired
    private AppService appService;

    @Autowired
    private UserService userService;

    @Autowired
    private SpaceService spaceService;

    @Autowired
    private OrgService orgService;

    @Autowired
    private ClusterService clusterService;

    @RequestMapping(value = "/index", method = RequestMethod.GET, produces = "application/json")
    public String index(ModelMap model, @RequestParam("app_id") int appId) {
        Gson gson = new Gson();

        // 获取app信息
        App app = appService.getAppById(appId);
        AppRegistryInfo appInfo = appService.getAppRegistryInfo(appId);
        // 获取scm svn信息
        String scmSvn = "";
        if (app != null) {
            scmSvn = appService.getScmSvn(app);
        }
        model.addAttribute("scm_svn", scmSvn);

        // 判断是否申请了上线资源
        if (appInfo.getApp_id() != 0) {
            // 并发度列表
            List<Integer> unitsList = autopush2Service
                    .getConcurrencyList(appInfo.getInstances());
            List<Integer> targetIdsList = autopush2Service.getTargetIds(appInfo
                    .getTarget());
            appInfo.setTarget_ids(targetIdsList);
            appInfo.setUnits(unitsList);
        }
        else {
            model.addAttribute("error", true);
            model.addAttribute("msg", "请先在'配置'申请JPaaS资源");
            appInfo.setTarget("");
        }

        String host = "";
        if (app != null) {
            Org org = orgService.queryOrgById(app.getOrg());
            model.addAttribute("org", org);
            model.addAttribute("org_json", gson.toJson(org));
            app.setInfo(appInfo);
            // 判断用户权限
            String role = "";
            if (userService.isAdmin()) {
                role = "admin";
            }
            else if (userService.isOrgAdmin(app.getOrg())) {
                role = "org_developer";
            }
            model.addAttribute("is_org_developer", role);
            model.addAttribute("app", app);
            model.addAttribute("app_json", gson.toJson(app));

            host = autopush2Service.getHost(appId, null, "ws");
        }
        if (host.equals("")) {
            host = autopushLog2;
        }
        model.addAttribute("autopush_log", host);

        model.addAttribute("app_id", appId);
        model.addAttribute("app_info", appInfo);
        model.addAttribute("app_info_json", gson.toJson(appInfo));
        model.addAttribute("xusers_api_cluster", clusterApi);
        model.addAttribute("static_version", staticVersion);
        model.addAttribute("env", env);
        model.addAttribute("user_name", userService.getUsername());

        return "autopush2index";
    }

    @RequestMapping(value = "/form", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String form(Model model, @RequestParam("process_id") int processId) {
        String host = "";
        int appId = autopush2Service.getAppIdFromProcess(processId);
        if (appId != 0) {
            App app = appService.getAppById(appId);
            try {
                List<Cluster> clusterIds = spaceService.getSpaceClusters(app
                        .getSpace());
                host = "ws://" + clusterIds.get(0).getPushmanager() + "/";
            } catch (Exception e) {
                log.error("[autopush2][get_host][error=" + e.getMessage() + "]");
            }
            if (host.equals("")) {
                host = autopushLog2;
            }

        }
        model.addAttribute("autopush_log", host);
        model.addAttribute("app_id", appId);
        model.addAttribute("process_id", processId);
        model.addAttribute("env", env);
        return "autopush2form";
    }

    @RequestMapping(value = "/api_icafe_ci", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<String> icafeCi(
            @RequestParam("app_id") int appId,
            @RequestParam("time") String appointOperationTime,
            @RequestParam(value = "desc", defaultValue = "无") String rdOperationTargetDesc,
            @RequestParam("org_svn") String orgSvn,
            @RequestParam("app_svn") String appSvn,
            @RequestParam(value = "rd_manager", defaultValue = "") String rdManager,
            @RequestParam(value = "qa_manager", defaultValue = "") String qaManager)
            throws UnauthorizedException {
        RestResponse<String> result = new RestResponse<String>();

        App app = appService.getAppById(appId);
        userService.needSpaceRD(app.getSpace());

        String userName = userService.getUsername() + "@baidu.com";
        String version = autopush2Service.getLatestScm(appSvn);
        result = autopush2Service.icafeCi(
                appointOperationTime, rdOperationTargetDesc, userName,
                rdManager, qaManager, orgSvn, appSvn);
        if (result.getCode() == 1) {
            IcafeProcess process = new IcafeProcess(1, userName, orgSvn,
                    appSvn, version, appointOperationTime, rdManager,
                    qaManager, new Date(), appId, rdOperationTargetDesc);
            String insertResult = autopush2Service.addIcafeProcess(process);
            if (insertResult == null) {
                result = null;
            }
        }
        return result;
    }

    @RequestMapping(value = "/api_icafe_rd", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<String> icafeRd(
            @RequestParam("app_id") int appId,
            @RequestParam("time") String appointOperationTime,
            @RequestParam(value = "desc", defaultValue = "无") String rdOperationTargetDesc,
            @RequestParam("org_svn") String orgSvn,
            @RequestParam("app_svn") String appSvn,
            @RequestParam(value = "rd_manager", defaultValue = "") String rdManager)
            throws UnauthorizedException {
        RestResponse<String> result = new RestResponse<String>();

        App app = appService.getAppById(appId);
        userService.needSpaceRD(app.getSpace());

        String userName = userService.getUsername() + "@baidu.com";
        String version = autopush2Service.getLatestScm(appSvn);
        result = autopush2Service.icafeRd(
                appointOperationTime, rdOperationTargetDesc, userName,
                rdManager, orgSvn);
        if (result.getCode() == 1) {
            IcafeProcess process = new IcafeProcess(1, userName, orgSvn,
                    appSvn, version, appointOperationTime, rdManager,
                    "", new Date(), appId, rdOperationTargetDesc);
            String insertResult = autopush2Service.addIcafeProcess(process);
            if (insertResult == null) {
                result = null;
            }
        }
        return result;
    }

    @RequestMapping(value = "/api_deploy_autopush", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String apiDeployAutopush(
            @RequestParam("app_id") int appId,
            @RequestParam("app_name") String appName,
            @RequestParam String version,
            @RequestParam("scm_path") String scmPath,
            @RequestParam int unit,
            @RequestParam(value = "last_version", defaultValue = "V2_icafeId") String lastVersion,
            @RequestParam(value = "icafe_id", defaultValue = "") String icafeId,
            @RequestParam(defaultValue = "") String plan,
            @RequestParam(value = "target_dir", defaultValue = "") String targetDir,
            @RequestParam int interval) throws UnauthorizedException {
        Gson gson = new Gson();

        App app = appService.getAppById(appId);
        userService.needSpaceRD(app.getSpace());

        Map<String, Object> postData = new HashMap<String, Object>();
        postData.put("app_id", appId);
        postData.put("app_name", appName);
        postData.put("version", version);
        postData.put("scm_path", scmPath.equals("") ? "None" : scmPath);
        postData.put("last_version", lastVersion);
        postData.put("unit", unit);
        postData.put("icafe_id", icafeId);
        postData.put("plan", plan);
        postData.put("target_dir", targetDir);
        postData.put("interval", interval);
        postData.put("operator", userService.getUsername());
        String host = autopush2Service.getHost(appId, null, null);
        String api = String.format("%s/autopush/api2/operation",
                host.equals("") ? clusterApi : host);
        String response = HttpProxy.getHttpPost(api, gson.toJson(postData),
                TOKEN);
        return response;
    }

    @RequestMapping(value = "/api_icafe_process", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public Map<String, Object> apiIcafeProcess(
            @RequestParam("app_id") int appId,
            @RequestParam(value = "page_size", defaultValue = "1") String pageSize,
            @RequestParam(value = "app_num", defaultValue = "1") String pageNum,
            @RequestParam(value = "process_id", defaultValue = "0") String processId)
            throws UnauthorizedException {
        App app = appService.getAppById(appId);
        userService.needSpaceRD(app.getSpace());

        Map<String, Object> result = new HashMap<String, Object>();
        IcafeProcess process = autopush2Service.getProcessByAppid(appId);
        if (process == null) {
            result.put("state", "false");
            return result;
        }
        processId = processId.equals("0") ? "1" : processId;

        String api = String.format(
                "%s&p.processId=%s&p.pagesize=%s&p.pagenum=%s",
                icafeProcessApi, processId, pageSize, pageNum);
        try {
            String response = HttpProxy.getHttpGet(api);
            result.put("icafe", response);
            result.put("version", "");
        } catch (Exception e) {
            log.error(String.format(
                    "[autopush2.py][api_icafe_process error][e=%s][api=%s]",
                    e.getMessage(), api));
        }
        return result;
    }

    @RequestMapping(value = "/api_get_status", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String apiGetStatus(@RequestParam("process_id") int processId,
            @RequestParam("app_id") int appId) {
        String status = autopush2Service.getStatusByProcessid(processId);
        return status;
    }

    @RequestMapping(value = "/api_md5_check", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String apiMd5Check(@RequestParam("app_id") int appId,
            @RequestParam String ftp) {
        App app = new App();
        app = appService.getAppById(appId);
        String result = autopush2Service.checkMd5(app.getName(), ftp);
        return result;
    }

    @RequestMapping(value = "/api_deploy_status", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String apiDeployStatus(
            @RequestParam(value = "target_index", defaultValue = "0") int targetIndex,
            @RequestParam String start,
            @RequestParam String end,
            @RequestParam("process_id") int processId,
            @RequestParam(value = "icafe_process_id", defaultValue = "") String icafeProcessId,
            @RequestParam("app_id") int appId) throws UnauthorizedException {
        App app = appService.getAppById(appId);
        userService.needSpaceRD(app.getSpace());

        Gson gson = new Gson();
        Map<String, Object> data = new HashMap<String, Object>();
        data.put("target_index", targetIndex);
        data.put("start", start);
        data.put("end", end);
        String userName = userService.getUsername();
        String host = "";
        host = autopush2Service.getHost(appId, null, null);
        String url = "";
        if (!host.equals("")) {
            url = String.format("%s/autopush/api2/operation/operation_id/%s",
                    host, processId);
        }
        else {
            url = String.format("%s/autopush/api2/operation/operation_id/%s",
                    clusterApi, processId);
        }
        // TODO
        String response = HttpProxy.getHttpPut(url, gson.toJson(data), TOKEN);
        if ("done".equals(end) && !"V2_icafeId".equals(icafeProcessId)
                && response != null) {
            Map<String, Object> responseMap = gson.fromJson(response,
                    new TypeToken<Map<String, Object>>() {
                    }.getType());
            if ("ok".equals(String.valueOf(responseMap.get("State")))) {
                String icafeUrl =
                        String.format(
                                "%s&processId=%s&userName=%s&opFlag=%s&onlineManner=%s&opEndState=%s",
                                icafeCompleteApi, icafeProcessId,
                                userName, 1,
                                15, 1);
                String icafeResponse = HttpProxy.getHttpGet(icafeUrl, TOKEN);
            }
        }
        return response;
    }

    @RequestMapping(value = "/get_autopush_state", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String getAutopushState() {
        String result = autopush2Service.getAutopushState();
        return result;
    }
}
