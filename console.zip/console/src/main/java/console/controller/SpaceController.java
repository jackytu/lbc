package console.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import console.common.RestResponse;
import console.common.UnauthorizedException;
import console.entity.Org;
import console.entity.Space;
import console.entity.SpaceView;
import console.entity.User;
import console.entity.app.App;
import console.service.AppService;
import console.service.OrgService;
import console.service.SpaceService;
import console.service.UserService;

/**
 * 空间API
 * 
 * @author wuwei03
 * 
 */
@Controller
@RequestMapping("api/spaces")
public class SpaceController {
    @Autowired
    private OrgService orgService;

    @Autowired
    private SpaceService spaceService;

    @Autowired
    private UserService userService;

    @Autowired
    private AppService appService;

    /**
     * 获取space详情
     * 
     * @param id
     *            :space id
     * @return
     * @throws UnauthorizedException
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<SpaceView> spaceInfo(@PathVariable int id) {
        Space space = spaceService.querySpaceById(id);
        RestResponse<SpaceView> result = new RestResponse<SpaceView>();
        if (space == null) {
            result.setCode(HttpStatus.SC_NOT_FOUND);
            return result;
        }
        Org org = orgService.queryOrgById(space.getOrg());
        SpaceView spaceView = new SpaceView();
        spaceView.setId(id);
        spaceView.setName(space.getName());
        spaceView.setOrgId(org.getId());
        spaceView.setOrgName(org.getName());
        spaceView.setApps(spaceService.getApps(id));
        // get space users
        spaceView.setOps(spaceService.getSpaceOPs(id));
        spaceView.setRds(spaceService.getSpaceRDs(id));
        result.setData(spaceView);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    /**
     * 删除space
     * 
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/{id}/delete", method = RequestMethod.POST, consumes = "application/*", produces = "application/json")
    @ResponseBody
    public RestResponse<String> delSpace(@PathVariable int id) throws Exception {
        Space space = spaceService.querySpaceById(id);
        userService.needOrgAdmin(space.getOrg());

        RestResponse<String> result = new RestResponse<String>();
        List<App> apps = spaceService.getApps(id);
        if (apps.size() != 0) {
            result.setCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            result.setMessage("space is not null!");
            return result;
        }
        spaceService.deleteSpace(id);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    /**
     * 新增space
     * 
     * @param name
     * @param orgId
     * @param version
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<Integer> addSpace(@RequestParam("clusters") String clusters, @RequestBody Space space)
            throws Exception {
        userService.needOrgAdmin(space.getOrg());

        RestResponse<Integer> result = new RestResponse<Integer>();
        for (String clusterId : clusters.split(",")) {
            spaceService.addSpace(space, Integer.parseInt(clusterId));
        }

        result.setCode(HttpStatus.SC_OK);
        result.setData(space.getId());
        return result;
    }

    @RequestMapping(value = "/{id}/apps", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<List<App>> getApps(@PathVariable int id) {
        List<App> apps = spaceService.getApps(id);
        RestResponse<List<App>> result = new RestResponse<List<App>>();
        result.setCode(HttpStatus.SC_OK);
        result.setData(apps);
        return result;
    }

    @RequestMapping(value = "/{id}/ops", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<Set<User>> getAdmins(@PathVariable int id) {
        RestResponse<Set<User>> result = new RestResponse<Set<User>>();
        Set<User> users = new HashSet<User>(spaceService.getSpaceOPs(id));
        result.setData(users);
        return result;
    }

    @RequestMapping(value = "/{id}/rds", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RestResponse<Set<User>> getSpaceUsers(@PathVariable int id) {
        RestResponse<Set<User>> result = new RestResponse<Set<User>>();
        Set<User> users = new HashSet<User>(spaceService.getSpaceRDs(id));
        result.setData(users);
        return result;
    }

    @RequestMapping(value = "/{id}/users/add", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> addSpaceUser(@PathVariable int id, @RequestBody Map<String, String> data)
            throws UnauthorizedException {
        RestResponse<String> result = new RestResponse<String>();
        // check param is valid
        if (!data.containsKey("username") || !data.containsKey("role")) {
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }

        // check user is exist
        String username = data.get("username");
        User user = userService.getUserById(username);
        if (user == null) {
            userService.addUser(username);
        }
        // add auth to user table
        String role = data.get("role");
        switch (role) {
        case "op":
            userService.needSpaceOP(id);
            spaceService.addSpaceOPUser(id, username);
            break;
        case "rd":
            userService.needSpaceRD(id);
            spaceService.addSpaceRDUser(id, username);
            break;
        default:
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    @RequestMapping(value = "/{id}/users/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> delSpaceUser(@PathVariable int id, @RequestBody Map<String, String> data)
            throws UnauthorizedException {
        RestResponse<String> result = new RestResponse<String>();
        // check param is valid
        if (!data.containsKey("username") || !data.containsKey("role")) {
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }
        String username = data.get("username");
        String role = data.get("role");
        switch (role) {
        case "op":
            userService.needSpaceOP(id);
            spaceService.deleteSpaceOPUser(id, username);
            break;
        case "rd":
            userService.needSpaceRD(id);
            spaceService.deleteSpaceRDUser(id, username);
            break;
        default:
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }
        result.setCode(HttpStatus.SC_OK);
        return result;
    }
}
