package console.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import console.common.HttpProxy;

/**
 * Docker Image操作相关API
 * 
 * @author wuwei03
 * 
 */
@RestController
@RequestMapping("api/dockers")
public class DockerController {
    private static final String API = "http://10.57.170.39:8868";

    @RequestMapping(value = "/public", method = RequestMethod.GET, produces = "application/json")
    public String getPublicImages() {
        return HttpProxy.getHttpGet(API + "/v1/search?q=LIBRARY");
    }

    @RequestMapping(value = "/private", method = RequestMethod.GET, produces = "application/json")
    public String getPrivateImages(
            @RequestParam String name) {
        return HttpProxy.getHttpGet(API + "/v1/search?q=" + name);
    }
}
