package console.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import console.common.DateTools;
import console.common.HttpProxy;
import console.common.RestResponse;
import console.common.UnauthorizedException;
import console.entity.Cluster;
import console.entity.Space;
import console.entity.User;
import console.entity.app.App;
import console.entity.app.AppMonitor;
import console.entity.app.AppQuality;
import console.entity.app.AppView;
import console.service.AppService;
import console.service.OrgService;
import console.service.SpaceService;
import console.service.UserService;

/**
 * APP操作相关API
 * 
 * @author wuwei03
 * 
 */
@RestController
@RequestMapping("api/apps")
public class AppController {
    private static final String API = "http://jpaas.baidu.com";
    private static Logger log = LoggerFactory.getLogger(AppController.class);

    @Autowired
    private AppService appService;

    @Autowired
    private SpaceService spaceService;

    @Autowired
    private OrgService orgService;

    @Autowired
    private UserService userService;

    @RequestMapping(value = "/search", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<List<AppMonitor>> searchAppInfo(
            @RequestParam String name) {
        RestResponse<List<AppMonitor>> result = new RestResponse<List<AppMonitor>>();
        log.info("start search key:" + name);
        result.setMessage(name);
        List<AppMonitor> appMonitors = appService.searchApp(name);
        result.setCode(HttpStatus.OK.value());
        result.setData(appMonitors);
        return result;
    }

    /**
     * 获取app信息
     * 
     * @param id
     *            ：app id
     * @return
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<AppMonitor> appInfo(@PathVariable int id) {
        RestResponse<AppMonitor> result = new RestResponse<AppMonitor>();
        AppMonitor app = appService.getAppMonitorById(id);
        result.setData(app);
        result.setCode(HttpStatus.OK.value());
        return result;
    }

    @RequestMapping(value = "/{id}/baseinfo", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<AppView> appBaseInfo(@PathVariable int id) {
        RestResponse<AppView> result = new RestResponse<AppView>();
        App app = appService.getAppById(id);
        List<Cluster> clusters = spaceService.getSpaceClusters(app.getSpace());
        String yesterday = DateTools.yesterday("yyyyMMdd");
        String content = HttpProxy
                .getHttpGet(API + "/api/app/performance?appId=" + app.getId()
                        + "&date=" + yesterday);
        Gson gson = new Gson();
        AppQuality appQuality = gson.fromJson(content, AppQuality.class);
        result.setData(new AppView(app, clusters, appQuality));
        result.setCode(HttpStatus.OK.value());
        return result;
    }

    @RequestMapping(value = "/{id}/users", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<Set<User>> getAppUsersInfo(@PathVariable int id) {
        RestResponse<Set<User>> result = new RestResponse<Set<User>>();
        App app = appService.getAppById(id);
        Set<User> users = new HashSet<User>();
        if (app != null) {
            Space space = spaceService.querySpaceById(app.getSpace());
            users.addAll(spaceService.getSpaceOPs(space.getId()));
            users.addAll(spaceService.getSpaceRDs(space.getId()));
        }
        if (users.size() == 0) {
            result.setCode(HttpStatus.NOT_FOUND.value());
        } else {
            result.setCode(HttpStatus.OK.value());
        }
        result.setData(users);
        return result;
    }

    @RequestMapping(value = "/users", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<Set<User>> getUsersInfoForMonitor(
            @RequestParam("org") String orgName,
            @RequestParam("space") String spaceName,
            @RequestParam("app") String appName) {
        RestResponse<Set<User>> result = new RestResponse<Set<User>>();
        App app = appService.getAppByName(appName);
        if (app == null) {
            return null;
        }
        Space space = spaceService.querySpaceById(app.getId());
        if (space == null) {
            return null;
        }
        Set<User> users = new HashSet<User>();
        users.addAll(spaceService.getSpaceOPs(space.getId()));
        users.addAll(spaceService.getSpaceRDs(space.getId()));
        if (users.size() == 0) {
            result.setCode(HttpStatus.NOT_FOUND.value());
        } else {
            result.setCode(HttpStatus.OK.value());
        }
        result.setData(users);
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    public RestResponse<String> getAppByName(
            @RequestParam("org") String orgName,
            @RequestParam("space") String spaceName,
            @RequestParam("app") String appName) {
        RestResponse<String> result = new RestResponse<String>();
        App app = appService.getAppByName(appName);
        if (app == null) {
            result.setCode(HttpStatus.NOT_FOUND.value());
        } else {
            result.setCode(HttpStatus.OK.value());
        }
        return result;
    }

    @RequestMapping(value = "/{id}/delete", method = RequestMethod.POST, produces = "application/json")
    public RestResponse<String> delApp(@PathVariable int id)
            throws UnauthorizedException {
        App app = appService.getAppById(id);
        userService.needOrgAdmin(app.getOrg());
        RestResponse<String> result = new RestResponse<String>();
        appService.deleteApp(id);
        result.setCode(HttpStatus.OK.value());
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.POST, produces = "application/json")
    public RestResponse<String> addApp(@RequestBody App app) throws Exception {
        userService.needOrgAdmin(app.getOrg());
        RestResponse<String> result = new RestResponse<String>();
        appService.insertApp(app);
        result.setCode(HttpStatus.OK.value());
        return result;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.POST, produces = "application/json")
    public RestResponse<String> editApp(@RequestBody App app) throws Exception {
        userService.needSpaceOP(app.getSpace());
        RestResponse<String> result = new RestResponse<String>();
        appService.updateApp(app);
        result.setCode(HttpStatus.OK.value());
        return result;
    }

    @RequestMapping(value = "/modules", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String getAllModules(@RequestParam String query) {
        return HttpProxy
                .getHttpGet("http://jpaas.baidu.com/api/apply/modules?query="
                        + query);
    }

    @RequestMapping(value = "/instance", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String getAppIns(@RequestParam String appName,
            @RequestParam String status, @RequestParam String cluster,
            @RequestParam String clustername) {
        return HttpProxy.getHttpGet(API + "/api/apps/instance?appName="
                + appName
                + "&status=" + status + "&cluster=" + cluster + "&clustername="
                + clustername);
    }

    @RequestMapping(value = "/instance/status", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public String getStopAppIns(@RequestParam String appName,
            @RequestParam String status, String cluster,
            @RequestParam int page, @RequestParam int size) {
        return HttpProxy.getHttpGet(API + "/api/apps/instance/status?appName="
                + appName
                + "&status=" + status + "&cluster=" + cluster + "&page=" + page
                + "&size=" + size);
    }
}
