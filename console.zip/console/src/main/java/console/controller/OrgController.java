package console.controller;

import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import console.common.RestResponse;
import console.entity.Cluster;
import console.entity.Org;
import console.entity.OrgView;
import console.entity.Space;
import console.entity.User;
import console.service.OrgService;
import console.service.UserService;

/**
 * org api
 * 
 * @author wuwei03
 * 
 */
@Controller
@RequestMapping("api/orgs")
public class OrgController {
    @Autowired
    private OrgService orgService;

    @Autowired
    private UserService userService;

    /**
     * 获取所有产品线列表
     * 
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<List<Org>> getOrgs() {
        RestResponse<List<Org>> result = new RestResponse<List<Org>>();
        List<Org> orgs = orgService.getAllOrgs();
        result.setData(orgs);
        return result;
    }

    @RequestMapping(value = "", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public RestResponse<String> addOrg(@RequestBody Org org) throws Exception {
        userService.needAdmin();
        RestResponse<String> result = new RestResponse<String>();
        orgService.addOrg(org);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    /**
     * 获取org信息
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<OrgView> orgInfo(@PathVariable int id) {
        Org org = orgService.queryOrgById(id);
        RestResponse<OrgView> result = new RestResponse<OrgView>();
        OrgView orgView = new OrgView();
        orgView.setId(org.getId());
        orgView.setName(org.getName());
        orgView.setCnName(org.getCnName());
        // set spaces
        orgView.setSpaces(orgService.getOrgSpaces(id));
        // set users
        orgView.setUsers(orgService.getOrgUsers(id));
        result.setCode(HttpStatus.SC_OK);
        result.setData(orgView);
        return result;
    }

    @RequestMapping(value = "/{id}/clusters", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<List<Cluster>> orgClusterInfo(@PathVariable int id) {
        RestResponse<List<Cluster>> result = new RestResponse<List<Cluster>>();
        List<Cluster> clusters = orgService.getClusters(id);
        result.setCode(HttpStatus.SC_OK);
        result.setData(clusters);
        return result;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> updateOrgInfoById(@RequestBody Org org) throws Exception {
        userService.needAdmin();
        RestResponse<String> result = new RestResponse<String>();
        orgService.updateOrg(org);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    @RequestMapping(value = "/{id}/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> delOrgById(@PathVariable int id) throws Exception {
        userService.needAdmin();
        RestResponse<String> result = new RestResponse<String>();
        List<Space> spaces = orgService.getOrgSpaces(id);
        if (spaces.size() != 0) {
            result.setCode(HttpStatus.SC_INTERNAL_SERVER_ERROR);
            result.setMessage("org already has spaces");
            return result;
        }
        orgService.delOrg(id);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    /**
     * 获取org下的space列表
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}/spaces", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<List<Space>> getSpaceListByOrgId(@PathVariable int id) {
        RestResponse<List<Space>> result = new RestResponse<List<Space>>();
        List<Space> spaces = orgService.getOrgSpaces(id);
        if (spaces == null || spaces.size() == 0) {
            result.setCode(HttpStatus.SC_NOT_FOUND);
        } else {
            result.setCode(HttpStatus.SC_OK);
        }
        result.setData(spaces);
        return result;
    }

    @RequestMapping(value = "/{id}/users", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public RestResponse<List<User>> getUsers(@PathVariable int id) {
        RestResponse<List<User>> result = new RestResponse<List<User>>();
        List<User> users = orgService.getOrgUsers(id);
        if (users.size() == 0) {
            result.setCode(HttpStatus.SC_NOT_FOUND);
        } else {
            result.setCode(HttpStatus.SC_OK);
        }
        result.setData(users);
        return result;
    }

    @RequestMapping(value = "/{id}/users/add", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> addOrgAuth(@PathVariable int id, @RequestBody Map<String, String> data)
            throws Exception {
        userService.needOrgAdmin(id);
        RestResponse<String> result = new RestResponse<String>();
        // check param is valid
        if (!data.containsKey("username")) {
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }
        orgService.insertOrgUser(id, data.get("username"));
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    @RequestMapping(value = "/{id}/users/delete", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public RestResponse<String> delOrgAuth(@PathVariable int id,
            @RequestBody Map<String, String> data) throws Exception {
        userService.needOrgAdmin(id);
        RestResponse<String> result = new RestResponse<String>();
        // check param is valid
        if (!data.containsKey("username")) {
            result.setCode(HttpStatus.SC_BAD_REQUEST);
            return result;
        }
        orgService.delOrgUser(id, data.get("username"));
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

}
