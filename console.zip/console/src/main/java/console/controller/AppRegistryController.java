package console.controller;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import console.common.RestResponse;
import console.entity.AppRegistry;
import console.service.AppRegistryService;

@RestController
@RequestMapping("api/appregistry")
public class AppRegistryController {
    @Autowired
    private AppRegistryService appRegistryService;

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public RestResponse<String> addAppRegistry(@RequestBody AppRegistry appRegistry) {
        RestResponse<String> result = new RestResponse<String>();
        appRegistryService.insertAppRegistry(appRegistry);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    public RestResponse<String> editAppRegistry(@RequestBody AppRegistry appRegistry) {
        RestResponse<String> result = new RestResponse<String>();
        appRegistryService.updateAppRegistry(appRegistry);
        result.setCode(HttpStatus.SC_OK);
        return result;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public RestResponse<AppRegistry> findAppRegistry(@PathVariable Integer id) {
        RestResponse<AppRegistry> result = new RestResponse<AppRegistry>();
        AppRegistry appRegistry = appRegistryService.getAppRegistryById(id);
        result.setCode(HttpStatus.SC_OK);
        result.setData(appRegistry);
        return result;
    }

}
