#! /bin/bash
JAVA_HOME=$BUILD_KIT_PATH/java/jdk-1.7u60
export JAVA_HOME
echo $JAVA_HOME
NODEJS_HOME=$BUILD_KIT_PATH/nodejs/nodejs-0.12.4
PATH=$NODEJS_HOME/bin:$M3_HOME/bin:$JAVA_HOME/bin:$PATH
export PATH

# build ui
cd ui && sh install.sh && cd output
# replace "/*[[${username}]]*/" to /*[[${username}]]*/
sed -ig "s/\"\/\[\[/\/\[\[/" index.html
sed -ig "s/\/\"/\//" index.html
echo `pwd`
mv index.html ../../src/main/webapp/WEB-INF/views/
mv dist ../../src/main/webapp/WEB-INF/resources/
cd ../../

mvn clean
mvn -Dmaven.test.skip=true package

rm -rf output
mkdir output
mv target/console.war output/console.war
